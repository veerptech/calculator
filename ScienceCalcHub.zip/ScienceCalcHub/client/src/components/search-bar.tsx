import { useState, useCallback, useRef, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { Calculator } from "@shared/schema";
import { cn } from "@/lib/utils";

interface SearchBarProps {
  onSearch: (query: string) => void;
  onSelectCalculator: (calculator: Calculator) => void;
  className?: string;
}

export function SearchBar({ onSearch, onSelectCalculator, className }: SearchBarProps) {
  const [query, setQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  const { data: suggestions = [] } = useQuery<Calculator[]>({
    queryKey: ["/api/calculators/search", query],
    enabled: query.length > 2,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const handleSearch = useCallback((searchQuery: string) => {
    setQuery(searchQuery);
    onSearch(searchQuery);
    if (searchQuery.length > 2) {
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  }, [onSearch]);

  const handleSelectSuggestion = (calculator: Calculator) => {
    setQuery(calculator.title);
    setShowSuggestions(false);
    onSelectCalculator(calculator);
  };

  const clearSearch = () => {
    setQuery("");
    setShowSuggestions(false);
    onSearch("");
  };

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div ref={searchRef} className={cn("relative max-w-2xl mx-auto", className)}>
      <div className="relative">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
        <Input
          type="text"
          placeholder="Search calculators (e.g., molarity, kinematic equations, derivatives...)"
          value={query}
          onChange={(e) => handleSearch(e.target.value)}
          onFocus={() => query.length > 2 && setShowSuggestions(true)}
          className="w-full pl-12 pr-12 py-4 text-lg rounded-lg border border-border bg-background"
          data-testid="search-input"
        />
        {query && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearSearch}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
            data-testid="clear-search"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Search Suggestions */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-background border border-border rounded-lg shadow-lg z-50 max-h-96 overflow-y-auto">
          {suggestions.slice(0, 8).map((calculator) => (
            <button
              key={calculator.id}
              onClick={() => handleSelectSuggestion(calculator)}
              className="w-full px-4 py-3 text-left hover:bg-muted transition-colors border-b border-border last:border-b-0"
              data-testid={`suggestion-${calculator.id}`}
            >
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center bg-${calculator.category === 'physics' ? 'primary' : calculator.category === 'chemistry' ? 'secondary' : calculator.category === 'math' ? 'accent' : 'primary'}/10`}>
                  <i className={`fas fa-${calculator.icon} text-${calculator.category === 'physics' ? 'primary' : calculator.category === 'chemistry' ? 'secondary' : calculator.category === 'math' ? 'accent' : 'primary'}`}></i>
                </div>
                <div className="flex-1">
                  <div className="font-medium text-foreground">{calculator.title}</div>
                  <div className="text-sm text-muted-foreground">{calculator.description}</div>
                </div>
                <div className="text-xs text-muted-foreground capitalize">
                  {calculator.category}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
