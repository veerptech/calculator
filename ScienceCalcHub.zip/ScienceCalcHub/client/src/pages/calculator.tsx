import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Calculator, CalculatorResult } from "@shared/schema";
import { SEOHead } from "@/components/seo-head";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Calculator as CalculatorIcon, BookOpen, Copy } from "lucide-react";
import { CalculatorEngine, CalculationInput } from "@/lib/calculator-engine";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function CalculatorPage() {
  const { id } = useParams<{ id: string }>();
  const [inputs, setInputs] = useState<CalculationInput>({});
  const [results, setResults] = useState<any>(null);
  const [steps, setSteps] = useState<any[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: calculator, isLoading } = useQuery<Calculator>({
    queryKey: ["/api/calculators", id],
    enabled: !!id,
  });

  const calculateMutation = useMutation({
    mutationFn: async (calculationData: { inputs: CalculationInput; results: any; steps: any[] }) => {
      return await apiRequest("POST", `/api/calculators/${id}/calculate`, calculationData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/calculators", id] });
    },
  });

  useEffect(() => {
    if (calculator?.variables && 'inputs' in calculator.variables && Array.isArray(calculator.variables.inputs)) {
      const defaultInputs: CalculationInput = {};
      calculator.variables.inputs.forEach((input: any) => {
        if (input.default !== undefined) {
          defaultInputs[input.name] = input.default;
        }
      });
      setInputs(defaultInputs);
    }
  }, [calculator]);

  const handleInputChange = (name: string, value: string | number) => {
    setInputs(prev => ({ ...prev, [name]: value }));
    // Clear errors for this field and general error
    if (errors[name] || errors._general) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        delete newErrors._general;
        return newErrors;
      });
    }
  };

  const validateInputs = (): boolean => {
    const newErrors: Record<string, string> = {};
    let isValid = true;

    if (!calculator?.variables || !('inputs' in calculator.variables) || !Array.isArray(calculator.variables.inputs)) return false;

    // Check individual field validation
    calculator.variables.inputs.forEach((input: any) => {
      const value = inputs[input.name];
      
      if (input.required && (value === undefined || value === "" || value === null)) {
        newErrors[input.name] = "This field is required";
        isValid = false;
      } else if (input.type === "number" && value !== undefined && value !== "" && value !== null) {
        const numValue = Number(value);
        if (isNaN(numValue)) {
          newErrors[input.name] = "Please enter a valid number";
          isValid = false;
        } else if (input.min !== undefined && numValue < input.min) {
          newErrors[input.name] = `Value must be at least ${input.min}`;
          isValid = false;
        } else if (input.max !== undefined && numValue > input.max) {
          newErrors[input.name] = `Value must be at most ${input.max}`;
          isValid = false;
        }
      } else if (input.type === "text" && input.required && (!value || value.toString().trim() === "")) {
        newErrors[input.name] = "This field is required";
        isValid = false;
      }
    });

    // Check minimum fields requirement if specified
    if (calculator.variables.validationRules && 'minimumFields' in calculator.variables.validationRules) {
      const filledFieldsCount = calculator.variables.inputs.filter((input: any) => {
        const value = inputs[input.name];
        return value !== undefined && value !== "" && value !== null && value.toString().trim() !== "";
      }).length;

      const minimumFields = (calculator.variables.validationRules as any).minimumFields;
      if (filledFieldsCount < minimumFields) {
        const description = (calculator.variables.validationRules as any).description || `Please fill at least ${minimumFields} fields`;
        // Add a general error message
        newErrors._general = description;
        isValid = false;
      }
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleCalculate = async () => {
    if (!validateInputs() || !calculator) return;

    try {
      const calculation = CalculatorEngine.calculate(calculator.id, inputs);
      setResults(calculation.results);
      setSteps(calculation.steps);

      // Save calculation to backend
      await calculateMutation.mutateAsync({
        inputs,
        results: calculation.results,
        steps: calculation.steps,
      });

      toast({
        title: "Calculation completed",
        description: "Results and steps have been generated successfully.",
      });
    } catch (error) {
      toast({
        title: "Calculation error",
        description: error instanceof Error ? error.message : "An error occurred during calculation",
        variant: "destructive",
      });
    }
  };

  const handleClear = () => {
    const defaultInputs: CalculationInput = {};
    if (calculator?.variables && 'inputs' in calculator.variables && Array.isArray(calculator.variables.inputs)) {
      calculator.variables.inputs.forEach((input: any) => {
        if (input.default !== undefined) {
          defaultInputs[input.name] = input.default;
        }
      });
    }
    setInputs(defaultInputs);
    setResults(null);
    setSteps([]);
    setErrors({});
  };

  const copyResults = () => {
    if (!results) return;
    
    const resultsText = Object.entries(results)
      .map(([key, value]) => `${key}: ${value}`)
      .join('\n');
    
    navigator.clipboard.writeText(resultsText);
    toast({
      title: "Copied to clipboard",
      description: "Results have been copied to your clipboard.",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading calculator...</p>
        </div>
      </div>
    );
  }

  if (!calculator) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6 text-center">
            <CalculatorIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-foreground mb-2">Calculator Not Found</h1>
            <p className="text-muted-foreground mb-4">
              The calculator you're looking for doesn't exist or has been removed.
            </p>
            <Button asChild>
              <a href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const categoryColor = calculator.category === 'physics' ? 'primary' : 
                      calculator.category === 'chemistry' ? 'secondary' : 
                      calculator.category === 'math' ? 'accent' : 'primary';

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title={`${calculator.title} - Free Online Calculator | Science Calculators Hub`}
        description={`${calculator.description}. Step-by-step solutions included. Free online ${calculator.category} calculator.`}
        keywords={calculator.keywords?.join(', ')}
        canonicalUrl={`${window.location.origin}/calculator/${calculator.id}`}
        structuredData={{
          "@context": "https://schema.org",
          "@type": "WebApplication",
          "name": calculator.title,
          "description": calculator.description,
          "applicationCategory": "EducationalApplication",
          "url": `${window.location.origin}/calculator/${calculator.id}`,
          "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD"
          }
        }}
      />

      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="flex h-16 items-center justify-between">
            <Button variant="ghost" asChild>
              <a href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Calculators
              </a>
            </Button>
            
            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className={`bg-${categoryColor}/10 text-${categoryColor}`}>
                {calculator.category}
              </Badge>
              <span className="text-sm text-muted-foreground">
                {calculator.usageCount?.toLocaleString()} uses
              </span>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 lg:px-8 max-w-7xl py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calculator Input */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-2xl mb-2">{calculator.title}</CardTitle>
                    <p className="text-muted-foreground">{calculator.description}</p>
                  </div>
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${categoryColor}/10`}>
                    <i className={`fas fa-${calculator.icon} text-2xl text-${categoryColor}`}></i>
                  </div>
                </div>
                
                {calculator.formula && (
                  <div className="bg-muted/50 rounded-lg p-4 mt-4">
                    <div className="flex items-center mb-2">
                      <BookOpen className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span className="text-sm font-medium text-muted-foreground">Formula</span>
                    </div>
                    <code className="text-sm">{calculator.formula}</code>
                  </div>
                )}
              </CardHeader>
              
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {calculator.variables && 'inputs' in calculator.variables && Array.isArray(calculator.variables.inputs) && calculator.variables.inputs.map((input: any, index: number) => (
                    <div key={input.name} className="space-y-2">
                      <Label htmlFor={input.name} className="text-sm font-medium">
                        {input.label}
                        {input.unit && <span className="text-muted-foreground ml-1">({input.unit})</span>}
                      </Label>
                      
                      {input.type === "select" ? (
                        <Select 
                          value={inputs[input.name] as string || ""} 
                          onValueChange={(value) => handleInputChange(input.name, value)}
                        >
                          <SelectTrigger id={input.name} data-testid={`input-${input.name}`}>
                            <SelectValue placeholder={`Select ${input.label.toLowerCase()}`} />
                          </SelectTrigger>
                          <SelectContent>
                            {input.options?.map((option: string) => (
                              <SelectItem key={option} value={option}>
                                {option.charAt(0).toUpperCase() + option.slice(1)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          id={input.name}
                          type={input.type}
                          placeholder={input.placeholder || `Enter ${input.label.toLowerCase()}`}
                          value={inputs[input.name] || ""}
                          onChange={(e) => {
                            const rawValue = e.target.value;
                            if (input.type === "number") {
                              // Handle number input validation
                              if (rawValue === "") {
                                handleInputChange(input.name, "");
                              } else {
                                const numValue = parseFloat(rawValue);
                                if (isNaN(numValue)) {
                                  // Store the invalid value temporarily to show validation error
                                  handleInputChange(input.name, rawValue);
                                } else {
                                  handleInputChange(input.name, numValue);
                                }
                              }
                            } else {
                              handleInputChange(input.name, rawValue);
                            }
                          }}
                          className={cn(errors[input.name] && "border-destructive")}
                          data-testid={`input-${input.name}`}
                        />
                      )}
                      
                      {errors[input.name] && (
                        <p className="text-sm text-destructive">{errors[input.name]}</p>
                      )}
                    </div>
                  ))}
                </div>

                {/* General error message */}
                {errors._general && (
                  <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
                    <p className="text-sm text-destructive font-medium">{errors._general}</p>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-3">
                  <Button 
                    onClick={handleCalculate} 
                    className="flex-1"
                    disabled={calculateMutation.isPending}
                    data-testid="calculate-button"
                  >
                    {calculateMutation.isPending ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Calculating...
                      </>
                    ) : (
                      <>
                        <CalculatorIcon className="mr-2 h-4 w-4" />
                        Calculate
                      </>
                    )}
                  </Button>
                  <Button variant="outline" onClick={handleClear} data-testid="clear-button">
                    Clear
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results and Steps */}
          <div className="space-y-6">
            {/* Results */}
            {results && (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">Results</CardTitle>
                    <Button variant="ghost" size="sm" onClick={copyResults} data-testid="copy-results">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(results).map(([key, value]) => (
                      <div key={key} className="flex justify-between items-center">
                        <span className="text-sm font-medium capitalize">
                          {key.replace(/([A-Z])/g, ' $1').trim()}:
                        </span>
                        <span className="text-sm font-mono bg-muted px-2 py-1 rounded">
                          {typeof value === 'number' ? 
                            (Math.abs(value) < 0.001 && value !== 0 ? 
                              value.toExponential(2) : 
                              value.toLocaleString()
                            ) : 
                            String(value)
                          }
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Steps */}
            {steps && steps.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Step-by-Step Solution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {steps.map((step, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center space-x-2">
                          <div className={`w-6 h-6 rounded-full bg-${categoryColor} text-primary-foreground text-xs flex items-center justify-center font-medium`}>
                            {step.step}
                          </div>
                          <span className="text-sm font-medium">{step.description}</span>
                        </div>
                        
                        {step.formula && (
                          <div className="ml-8 text-sm">
                            <div className="text-muted-foreground">Formula:</div>
                            <code className="bg-muted px-2 py-1 rounded text-xs">{step.formula}</code>
                          </div>
                        )}
                        
                        {step.substitution && (
                          <div className="ml-8 text-sm">
                            <div className="text-muted-foreground">Substitution:</div>
                            <code className="bg-muted px-2 py-1 rounded text-xs">{step.substitution}</code>
                          </div>
                        )}
                        
                        <div className="ml-8 text-sm">
                          <div className="text-muted-foreground">Result:</div>
                          <code className="bg-accent/10 text-accent px-2 py-1 rounded text-xs font-medium">
                            {step.result}
                          </code>
                        </div>
                        
                        {index < steps.length - 1 && <Separator className="ml-8" />}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Usage Instructions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">How to Use</CardTitle>
              </CardHeader>
              <CardContent>
                <ol className="list-decimal list-inside space-y-2 text-sm text-muted-foreground">
                  <li>Enter the known values in the input fields</li>
                  <li>Leave unknown values empty - they will be calculated</li>
                  <li>Click "Calculate" to get your results</li>
                  <li>View step-by-step solutions to understand the process</li>
                  <li>Use "Clear" to reset all fields and start over</li>
                </ol>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
