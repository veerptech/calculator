import { Router } from "express";
import { aiService } from "./ai-service";
import { z } from "zod";

const router = Router();

// Schema for validation
const explainCalculationSchema = z.object({
  calculatorType: z.string(),
  formula: z.string(),
  inputs: z.record(z.any()),
  result: z.any(),
});

const solveProblemSchema = z.object({
  problem: z.string(),
  category: z.string(),
  subcategory: z.string(),
});

const suggestCalculatorsSchema = z.object({
  currentCalculator: z.string(),
  category: z.string(),
  inputs: z.record(z.any()).optional(),
});

const studyTipSchema = z.object({
  calculatorType: z.string(),
  category: z.string(),
});

// POST /api/ai/explain-calculation
router.post("/explain-calculation", async (req, res) => {
  try {
    const { calculatorType, formula, inputs, result } = explainCalculationSchema.parse(req.body);
    
    const explanation = await aiService.explainCalculation(
      calculatorType,
      formula,
      inputs,
      result
    );
    
    res.json({ success: true, explanation });
  } catch (error) {
    console.error("AI explanation error:", error);
    res.status(500).json({ 
      success: false, 
      error: "Failed to generate explanation" 
    });
  }
});

// POST /api/ai/solve-problem
router.post("/solve-problem", async (req, res) => {
  try {
    const { problem, category, subcategory } = solveProblemSchema.parse(req.body);
    
    const solution = await aiService.solveProblem(problem, category, subcategory);
    
    res.json({ success: true, solution });
  } catch (error) {
    console.error("AI problem solving error:", error);
    res.status(500).json({ 
      success: false, 
      error: "Failed to solve problem" 
    });
  }
});

// POST /api/ai/suggest-calculators
router.post("/suggest-calculators", async (req, res) => {
  try {
    const { currentCalculator, category, inputs } = suggestCalculatorsSchema.parse(req.body);
    
    const suggestions = await aiService.suggestRelatedCalculators(
      currentCalculator,
      category,
      inputs
    );
    
    res.json({ success: true, suggestions });
  } catch (error) {
    console.error("AI suggestion error:", error);
    res.status(500).json({ 
      success: false, 
      error: "Failed to generate suggestions" 
    });
  }
});

// POST /api/ai/study-tip
router.post("/study-tip", async (req, res) => {
  try {
    const { calculatorType, category } = studyTipSchema.parse(req.body);
    
    const tip = await aiService.generateStudyTip(calculatorType, category);
    
    res.json({ success: true, tip });
  } catch (error) {
    console.error("AI study tip error:", error);
    res.status(500).json({ 
      success: false, 
      error: "Failed to generate study tip" 
    });
  }
});

export { router as aiRoutes };