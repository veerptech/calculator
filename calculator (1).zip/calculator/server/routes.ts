import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCalculatorResultSchema } from "@shared/schema";
import { z } from "zod";
import { aiRoutes } from "./ai-routes";
import { setupChatbotRoutes } from "./chatbot-routes";

export async function registerRoutes(app: Express): Promise<Server> {
  // AI-powered features
  app.use("/api/ai", aiRoutes);
  
  // Chatbot for calculator assistance
  setupChatbotRoutes(app);

  // Get all calculators or by category
  app.get("/api/calculators", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      const calculators = await storage.getCalculators(category);
      res.json(calculators);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calculators" });
    }
  });

  // Get specific calculator
  app.get("/api/calculators/:id", async (req, res) => {
    try {
      const calculator = await storage.getCalculator(req.params.id);
      if (!calculator) {
        return res.status(404).json({ message: "Calculator not found" });
      }
      res.json(calculator);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch calculator" });
    }
  });

  // Search calculators
  app.get("/api/calculators/search/:query", async (req, res) => {
    try {
      const results = await storage.searchCalculators(req.params.query);
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Search failed" });
    }
  });

  // Update calculator usage
  app.post("/api/calculators/:id/usage", async (req, res) => {
    try {
      await storage.updateCalculatorUsage(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to update usage" });
    }
  });

  // Save calculation result
  app.post("/api/calculators/:id/calculate", async (req, res) => {
    try {
      const resultData = {
        calculatorId: req.params.id,
        inputs: req.body.inputs,
        results: req.body.results,
        steps: req.body.steps
      };

      const validatedData = insertCalculatorResultSchema.parse(resultData);
      const result = await storage.createCalculatorResult(validatedData);
      
      // Update usage count
      await storage.updateCalculatorUsage(req.params.id);
      
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid calculation data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to save calculation" });
      }
    }
  });

  // Generate sitemap
  app.get("/sitemap.xml", async (req, res) => {
    try {
      const calculators = await storage.getCalculators();
      const baseUrl = req.protocol + "://" + req.get("host");
      
      let sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>${baseUrl}/</loc>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>`;

      calculators.forEach(calc => {
        sitemap += `
  <url>
    <loc>${baseUrl}/calculator/${calc.id}</loc>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>`;
      });

      sitemap += `
</urlset>`;

      res.set("Content-Type", "application/xml");
      res.send(sitemap);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate sitemap" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
