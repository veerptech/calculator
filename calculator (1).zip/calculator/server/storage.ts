import { type Calculator, type InsertCalculator, type CalculatorResult, type InsertCalculatorResult, type User, type InsertUser } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getCalculators(category?: string): Promise<Calculator[]>;
  getCalculator(id: string): Promise<Calculator | undefined>;
  createCalculator(calculator: InsertCalculator): Promise<Calculator>;
  updateCalculatorUsage(id: string): Promise<void>;
  searchCalculators(query: string): Promise<Calculator[]>;
  
  createCalculatorResult(result: InsertCalculatorResult): Promise<CalculatorResult>;
  getCalculatorResults(calculatorId: string): Promise<CalculatorResult[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private calculators: Map<string, Calculator>;
  private calculatorResults: Map<string, CalculatorResult>;

  constructor() {
    this.users = new Map();
    this.calculators = new Map();
    this.calculatorResults = new Map();
    this.initializeCalculators();
  }

  private initializeCalculators() {
    const sampleCalculators: Calculator[] = [
      // Physics Calculators
      {
        id: "kinematic-equations",
        title: "Kinematic Equations Calculator",
        description: "Calculate displacement, velocity, acceleration, and time using kinematic equations",
        category: "physics",
        subcategory: "mechanics",
        icon: "rocket",
        formula: "v = u + at, s = ut + ½at², v² = u² + 2as",
        variables: {
          inputs: [
            { name: "initialVelocity", label: "Initial Velocity (u)", unit: "m/s", type: "number", required: true },
            { name: "finalVelocity", label: "Final Velocity (v)", unit: "m/s", type: "number" },
            { name: "acceleration", label: "Acceleration (a)", unit: "m/s²", type: "number", required: true },
            { name: "time", label: "Time (t)", unit: "s", type: "number", required: true },
            { name: "displacement", label: "Displacement (s)", unit: "m", type: "number" }
          ],
          outputs: ["displacement", "velocity", "acceleration", "time"],
          validationRules: {
            minimumFields: 3,
            description: "Enter at least 3 known values to calculate the unknowns"
          }
        },
        usageCount: 12500,
        isActive: true,
        keywords: ["kinematics", "motion", "velocity", "acceleration", "displacement"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "projectile-motion",
        title: "Projectile Motion Calculator",
        description: "Calculate range, maximum height, time of flight, and trajectory for projectile motion",
        category: "physics",
        subcategory: "mechanics",
        icon: "target",
        formula: "R = (v₀²sin(2θ))/g, H = (v₀²sin²(θ))/(2g), T = (2v₀sin(θ))/g",
        variables: {
          inputs: [
            { name: "initialVelocity", label: "Initial Velocity (v₀)", unit: "m/s", type: "number", required: true, min: 0 },
            { name: "angle", label: "Launch Angle (θ)", unit: "degrees", type: "number", required: true, min: 0, max: 90 },
            { name: "gravity", label: "Gravity (g)", unit: "m/s²", type: "number", default: 9.81, min: 0 },
            { name: "initialHeight", label: "Initial Height (h₀)", unit: "m", type: "number", default: 0, min: 0 }
          ],
          outputs: ["range", "maxHeight", "timeOfFlight", "velocityAtImpact"],
          validationRules: {
            minimumFields: 3,
            description: "Enter initial velocity, angle, and gravity to calculate projectile motion"
          }
        },
        usageCount: 8900,
        isActive: true,
        keywords: ["projectile", "trajectory", "range", "ballistics", "motion"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "newtons-laws",
        title: "Newton's Laws Calculator",
        description: "Calculate force, mass, and acceleration using Newton's second law (F = ma)",
        category: "physics",
        subcategory: "mechanics",
        icon: "weight",
        formula: "F = ma, ΣF = ma",
        variables: {
          inputs: [
            { name: "force", label: "Force (F)", unit: "N", type: "number", min: 0 },
            { name: "mass", label: "Mass (m)", unit: "kg", type: "number", min: 0 },
            { name: "acceleration", label: "Acceleration (a)", unit: "m/s²", type: "number" }
          ],
          outputs: ["force", "mass", "acceleration"],
          validationRules: {
            minimumFields: 2,
            description: "Enter at least 2 known values to calculate the third using F = ma"
          }
        },
        usageCount: 11200,
        isActive: true,
        keywords: ["newton", "force", "mass", "acceleration", "dynamics"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "work-energy",
        title: "Work and Energy Calculator",
        description: "Calculate work done, kinetic energy, potential energy, and power",
        category: "physics",
        subcategory: "mechanics",
        icon: "battery",
        formula: "W = Fd, KE = ½mv², PE = mgh, P = W/t",
        variables: {
          inputs: [
            { name: "force", label: "Force (F)", unit: "N", type: "number", min: 0 },
            { name: "distance", label: "Distance (d)", unit: "m", type: "number", min: 0 },
            { name: "mass", label: "Mass (m)", unit: "kg", type: "number", min: 0 },
            { name: "velocity", label: "Velocity (v)", unit: "m/s", type: "number", min: 0 },
            { name: "height", label: "Height (h)", unit: "m", type: "number", min: 0 },
            { name: "gravity", label: "Gravity (g)", unit: "m/s²", type: "number", default: 9.81, min: 0 },
            { name: "time", label: "Time (t)", unit: "s", type: "number", min: 0 }
          ],
          outputs: ["work", "kineticEnergy", "potentialEnergy", "power"],
          validationRules: {
            minimumFields: 2,
            description: "Enter values to calculate work, energy, or power"
          }
        },
        usageCount: 9800,
        isActive: true,
        keywords: ["work", "energy", "kinetic", "potential", "power", "conservation"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "momentum-calculator",
        title: "Momentum Calculator",
        description: "Calculate linear momentum, impulse, and analyze collisions",
        category: "physics",
        subcategory: "mechanics",
        icon: "move",
        formula: "p = mv, J = Δp = FΔt",
        variables: {
          inputs: [
            { name: "mass", label: "Mass (m)", unit: "kg", type: "number", min: 0 },
            { name: "velocity", label: "Velocity (v)", unit: "m/s", type: "number" },
            { name: "force", label: "Force (F)", unit: "N", type: "number" },
            { name: "time", label: "Time interval (Δt)", unit: "s", type: "number", min: 0 },
            { name: "initialMomentum", label: "Initial Momentum", unit: "kg⋅m/s", type: "number" },
            { name: "finalMomentum", label: "Final Momentum", unit: "kg⋅m/s", type: "number" }
          ],
          outputs: ["momentum", "impulse", "deltaVelocity"],
          validationRules: {
            minimumFields: 2,
            description: "Enter values to calculate momentum or impulse"
          }
        },
        usageCount: 7600,
        isActive: true,
        keywords: ["momentum", "impulse", "collision", "conservation", "mass", "velocity"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "torque-calculator",
        title: "Torque Calculator",
        description: "Calculate torque, angular velocity, angular acceleration, and rotational motion",
        category: "physics",
        subcategory: "mechanics",
        icon: "rotate-cw",
        formula: "τ = rF sin(θ), τ = Iα, L = Iω",
        variables: {
          inputs: [
            { name: "force", label: "Force (F)", unit: "N", type: "number", min: 0 },
            { name: "radius", label: "Radius (r)", unit: "m", type: "number", min: 0 },
            { name: "angle", label: "Angle (θ)", unit: "degrees", type: "number", min: 0, max: 180, default: 90 },
            { name: "momentOfInertia", label: "Moment of Inertia (I)", unit: "kg⋅m²", type: "number", min: 0 },
            { name: "angularAcceleration", label: "Angular Acceleration (α)", unit: "rad/s²", type: "number" },
            { name: "angularVelocity", label: "Angular Velocity (ω)", unit: "rad/s", type: "number" }
          ],
          outputs: ["torque", "angularMomentum", "rotationalEnergy"],
          validationRules: {
            minimumFields: 2,
            description: "Enter values to calculate torque and rotational motion"
          }
        },
        usageCount: 6300,
        isActive: true,
        keywords: ["torque", "angular", "rotation", "moment", "inertia", "lever"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "circular-motion",
        title: "Circular Motion Calculator",
        description: "Calculate centripetal force, period, frequency, and circular motion parameters",
        category: "physics",
        subcategory: "mechanics",
        icon: "circle",
        formula: "Fc = mv²/r, T = 2πr/v, f = 1/T",
        variables: {
          inputs: [
            { name: "mass", label: "Mass (m)", unit: "kg", type: "number", min: 0 },
            { name: "velocity", label: "Velocity (v)", unit: "m/s", type: "number", min: 0 },
            { name: "radius", label: "Radius (r)", unit: "m", type: "number", min: 0 },
            { name: "period", label: "Period (T)", unit: "s", type: "number", min: 0 },
            { name: "frequency", label: "Frequency (f)", unit: "Hz", type: "number", min: 0 },
            { name: "angularVelocity", label: "Angular Velocity (ω)", unit: "rad/s", type: "number", min: 0 }
          ],
          outputs: ["centripetalForce", "period", "frequency", "angularVelocity", "centrifugalAcceleration"],
          validationRules: {
            minimumFields: 3,
            description: "Enter mass, velocity/angular velocity, and radius to calculate circular motion"
          }
        },
        usageCount: 5400,
        isActive: true,
        keywords: ["circular", "centripetal", "rotation", "frequency", "period"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "pendulum-calculator",
        title: "Pendulum Calculator",
        description: "Calculate period, frequency, and energy for simple and physical pendulums",
        category: "physics",
        subcategory: "mechanics",
        icon: "clock",
        formula: "T = 2π√(L/g), E = ½kA²",
        variables: {
          inputs: [
            { name: "length", label: "Length (L)", unit: "m", type: "number", min: 0 },
            { name: "gravity", label: "Gravity (g)", unit: "m/s²", type: "number", default: 9.81, min: 0 },
            { name: "amplitude", label: "Amplitude (A)", unit: "m", type: "number", min: 0 },
            { name: "mass", label: "Mass (m)", unit: "kg", type: "number", min: 0 },
            { name: "period", label: "Period (T)", unit: "s", type: "number", min: 0 }
          ],
          outputs: ["period", "frequency", "maxVelocity", "totalEnergy"],
          validationRules: {
            minimumFields: 2,
            description: "Enter length and gravity, or period to calculate pendulum motion"
          }
        },
        usageCount: 4800,
        isActive: true,
        keywords: ["pendulum", "oscillation", "period", "gravity", "harmonic"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "hookes-law",
        title: "Hooke's Law Calculator",
        description: "Calculate spring force, spring constant, displacement, and elastic potential energy",
        category: "physics",
        subcategory: "mechanics",
        icon: "spring",
        formula: "F = -kx, PE = ½kx²",
        variables: {
          inputs: [
            { name: "springConstant", label: "Spring Constant (k)", unit: "N/m", type: "number", min: 0 },
            { name: "displacement", label: "Displacement (x)", unit: "m", type: "number" },
            { name: "force", label: "Force (F)", unit: "N", type: "number" },
            { name: "mass", label: "Mass (m)", unit: "kg", type: "number", min: 0 }
          ],
          outputs: ["force", "displacement", "springConstant", "elasticPotentialEnergy", "period"],
          validationRules: {
            minimumFields: 2,
            description: "Enter at least 2 values to calculate spring properties"
          }
        },
        usageCount: 6700,
        isActive: true,
        keywords: ["hooke", "spring", "elastic", "force", "constant", "displacement"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "simple-harmonic-motion",
        title: "Simple Harmonic Motion Calculator",
        description: "Calculate amplitude, frequency, period, and phase for oscillatory motion",
        category: "physics",
        subcategory: "mechanics",
        icon: "activity",
        formula: "x(t) = A cos(ωt + φ), ω = 2πf = 2π/T",
        variables: {
          inputs: [
            { name: "amplitude", label: "Amplitude (A)", unit: "m", type: "number", min: 0 },
            { name: "frequency", label: "Frequency (f)", unit: "Hz", type: "number", min: 0 },
            { name: "period", label: "Period (T)", unit: "s", type: "number", min: 0 },
            { name: "angularFrequency", label: "Angular Frequency (ω)", unit: "rad/s", type: "number", min: 0 },
            { name: "mass", label: "Mass (m)", unit: "kg", type: "number", min: 0 },
            { name: "springConstant", label: "Spring Constant (k)", unit: "N/m", type: "number", min: 0 }
          ],
          outputs: ["frequency", "period", "angularFrequency", "maxVelocity", "maxAcceleration", "totalEnergy"],
          validationRules: {
            minimumFields: 1,
            description: "Enter frequency, period, or other parameters to analyze harmonic motion"
          }
        },
        usageCount: 5900,
        isActive: true,
        keywords: ["harmonic", "oscillation", "frequency", "amplitude", "period", "vibration"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Gravitation & Astronomy Calculators
      {
        id: "gravitational-force",
        title: "Gravitational Force Calculator",
        description: "Calculate gravitational force between objects using Newton's law of universal gravitation",
        category: "physics",
        subcategory: "gravitation",
        icon: "globe",
        formula: "F = G(m₁m₂)/r²",
        variables: {
          inputs: [
            { name: "mass1", label: "Mass 1 (m₁)", unit: "kg", type: "number", required: true, min: 0 },
            { name: "mass2", label: "Mass 2 (m₂)", unit: "kg", type: "number", required: true, min: 0 },
            { name: "distance", label: "Distance (r)", unit: "m", type: "number", required: true, min: 0 },
            { name: "gravitationalConstant", label: "Gravitational Constant (G)", unit: "N⋅m²/kg²", type: "number", default: 6.67430e-11, min: 0 }
          ],
          outputs: ["gravitationalForce", "acceleration1", "acceleration2"],
          validationRules: {
            minimumFields: 4,
            description: "Enter both masses, distance, and gravitational constant to calculate force"
          }
        },
        usageCount: 4200,
        isActive: true,
        keywords: ["gravity", "gravitational", "force", "newton", "universal", "astronomy"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "escape-velocity",
        title: "Escape Velocity Calculator",
        description: "Calculate the minimum velocity needed to escape a celestial body's gravitational field",
        category: "physics",
        subcategory: "gravitation",
        icon: "rocket",
        formula: "v_e = √(2GM/r)",
        variables: {
          inputs: [
            { name: "mass", label: "Planet Mass (M)", unit: "kg", type: "number", min: 0 },
            { name: "radius", label: "Planet Radius (r)", unit: "m", type: "number", min: 0 },
            { name: "gravitationalConstant", label: "Gravitational Constant (G)", unit: "N⋅m²/kg²", type: "number", default: 6.67430e-11, min: 0 },
            { name: "surfaceGravity", label: "Surface Gravity (g)", unit: "m/s²", type: "number", min: 0 }
          ],
          outputs: ["escapeVelocity", "escapeVelocityKmh"],
          validationRules: {
            minimumFields: 2,
            description: "Enter planet mass and radius, or surface gravity and radius"
          }
        },
        usageCount: 3800,
        isActive: true,
        keywords: ["escape", "velocity", "planet", "gravity", "space", "orbital"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "orbital-period",
        title: "Orbital Period Calculator",
        description: "Calculate orbital period, velocity, and parameters for satellites and planets",
        category: "physics",
        subcategory: "gravitation",
        icon: "circle-dot",
        formula: "T = 2π√(r³/GM), v = √(GM/r)",
        variables: {
          inputs: [
            { name: "orbitalRadius", label: "Orbital Radius (r)", unit: "m", type: "number", min: 0 },
            { name: "centralMass", label: "Central Mass (M)", unit: "kg", type: "number", min: 0 },
            { name: "gravitationalConstant", label: "Gravitational Constant (G)", unit: "N⋅m²/kg²", type: "number", default: 6.67430e-11, min: 0 },
            { name: "period", label: "Period (T)", unit: "s", type: "number", min: 0 }
          ],
          outputs: ["period", "orbitalVelocity", "orbitalFrequency", "orbitalEnergy"],
          validationRules: {
            minimumFields: 3,
            description: "Enter orbital radius, central mass, and gravitational constant"
          }
        },
        usageCount: 2900,
        isActive: true,
        keywords: ["orbital", "period", "satellite", "kepler", "gravity", "circular"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "keplers-laws",
        title: "Kepler's Laws Calculator",
        description: "Calculate planetary motion using Kepler's three laws of orbital mechanics",
        category: "physics",
        subcategory: "gravitation",
        icon: "orbit",
        formula: "T² ∝ a³, r₁v₁ = r₂v₂",
        variables: {
          inputs: [
            { name: "semiMajorAxis", label: "Semi-major Axis (a)", unit: "AU", type: "number", min: 0 },
            { name: "period", label: "Orbital Period (T)", unit: "years", type: "number", min: 0 },
            { name: "aphelion", label: "Aphelion Distance", unit: "AU", type: "number", min: 0 },
            { name: "perihelion", label: "Perihelion Distance", unit: "AU", type: "number", min: 0 },
            { name: "eccentricity", label: "Eccentricity (e)", unit: "", type: "number", min: 0, max: 1 }
          ],
          outputs: ["period", "semiMajorAxis", "eccentricity", "aphelion", "perihelion"],
          validationRules: {
            minimumFields: 2,
            description: "Enter orbital parameters to analyze planetary motion"
          }
        },
        usageCount: 2100,
        isActive: true,
        keywords: ["kepler", "planetary", "orbital", "ellipse", "astronomy", "period"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "relativity-calculator",
        title: "Special Relativity Calculator",
        description: "Calculate time dilation, length contraction, and relativistic effects",
        category: "physics",
        subcategory: "gravitation",
        icon: "clock",
        formula: "γ = 1/√(1-v²/c²), Δt' = γΔt, L' = L/γ",
        variables: {
          inputs: [
            { name: "velocity", label: "Velocity (v)", unit: "m/s", type: "number", min: 0 },
            { name: "speedOfLight", label: "Speed of Light (c)", unit: "m/s", type: "number", default: 299792458, min: 0 },
            { name: "properTime", label: "Proper Time (Δt)", unit: "s", type: "number", min: 0 },
            { name: "properLength", label: "Proper Length (L)", unit: "m", type: "number", min: 0 }
          ],
          outputs: ["lorentzFactor", "dilatedTime", "contractedLength", "relativeMass"],
          validationRules: {
            minimumFields: 2,
            description: "Enter velocity and reference values to calculate relativistic effects"
          }
        },
        usageCount: 1800,
        isActive: true,
        keywords: ["relativity", "einstein", "time", "dilation", "length", "contraction", "lorentz"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Waves & Sound Calculators
      {
        id: "wave-speed",
        title: "Wave Speed Calculator",
        description: "Calculate wave speed, frequency, wavelength, and wave properties",
        category: "physics",
        subcategory: "waves",
        icon: "wave-square",
        formula: "v = fλ, T = 1/f",
        variables: {
          inputs: [
            { name: "frequency", label: "Frequency (f)", unit: "Hz", type: "number", min: 0 },
            { name: "wavelength", label: "Wavelength (λ)", unit: "m", type: "number", min: 0 },
            { name: "period", label: "Period (T)", unit: "s", type: "number", min: 0 },
            { name: "waveSpeed", label: "Wave Speed (v)", unit: "m/s", type: "number", min: 0 }
          ],
          outputs: ["waveSpeed", "frequency", "wavelength", "period"],
          validationRules: {
            minimumFields: 2,
            description: "Enter at least 2 values to calculate wave properties"
          }
        },
        usageCount: 7200,
        isActive: true,
        keywords: ["wave", "frequency", "wavelength", "speed", "period", "oscillation"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "doppler-effect",
        title: "Doppler Effect Calculator",
        description: "Calculate frequency shift due to relative motion between source and observer",
        category: "physics",
        subcategory: "waves",
        icon: "sound",
        formula: "f' = f(v ± v_o)/(v ± v_s)",
        variables: {
          inputs: [
            { name: "originalFrequency", label: "Source Frequency (f)", unit: "Hz", type: "number", required: true, min: 0 },
            { name: "soundSpeed", label: "Wave Speed (v)", unit: "m/s", type: "number", default: 343, min: 0 },
            { name: "observerVelocity", label: "Observer Velocity (v_o)", unit: "m/s", type: "number", default: 0 },
            { name: "sourceVelocity", label: "Source Velocity (v_s)", unit: "m/s", type: "number", default: 0 },
            { name: "approaching", label: "Relative Motion", unit: "", type: "select", options: ["approaching", "receding"], default: "approaching" }
          ],
          outputs: ["observedFrequency", "frequencyShift", "percentChange"],
          validationRules: {
            minimumFields: 3,
            description: "Enter source frequency, wave speed, and velocities"
          }
        },
        usageCount: 4700,
        isActive: true,
        keywords: ["doppler", "frequency", "shift", "sound", "radar", "astronomy"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "sound-intensity",
        title: "Sound Intensity Calculator",
        description: "Calculate sound intensity, decibel levels, and loudness measurements",
        category: "physics",
        subcategory: "waves",
        icon: "volume-2",
        formula: "β = 10 log₁₀(I/I₀), I = P/A",
        variables: {
          inputs: [
            { name: "intensity", label: "Sound Intensity (I)", unit: "W/m²", type: "number", min: 0 },
            { name: "decibels", label: "Sound Level (β)", unit: "dB", type: "number", min: 0 },
            { name: "power", label: "Sound Power (P)", unit: "W", type: "number", min: 0 },
            { name: "area", label: "Surface Area (A)", unit: "m²", type: "number", min: 0 },
            { name: "referenceIntensity", label: "Reference Intensity (I₀)", unit: "W/m²", type: "number", default: 1e-12, min: 0 }
          ],
          outputs: ["decibels", "intensity", "power", "area"],
          validationRules: {
            minimumFields: 2,
            description: "Enter intensity or decibel level with reference values"
          }
        },
        usageCount: 3600,
        isActive: true,
        keywords: ["sound", "intensity", "decibel", "loudness", "acoustics", "noise"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "resonance-calculator",
        title: "Resonance Calculator",
        description: "Calculate resonant frequency, quality factor, and standing wave patterns",
        category: "physics",
        subcategory: "waves",
        icon: "radio",
        formula: "f₀ = 1/(2π√LC), Q = f₀/Δf",
        variables: {
          inputs: [
            { name: "length", label: "Length (L)", unit: "m", type: "number", min: 0 },
            { name: "waveSpeed", label: "Wave Speed (v)", unit: "m/s", type: "number", min: 0 },
            { name: "harmonicNumber", label: "Harmonic (n)", unit: "", type: "number", default: 1, min: 1 },
            { name: "frequency", label: "Frequency (f)", unit: "Hz", type: "number", min: 0 },
            { name: "qualityFactor", label: "Quality Factor (Q)", unit: "", type: "number", min: 0 }
          ],
          outputs: ["resonantFrequency", "wavelength", "harmonics", "qualityFactor"],
          validationRules: {
            minimumFields: 2,
            description: "Enter length and wave speed, or frequency parameters"
          }
        },
        usageCount: 2900,
        isActive: true,
        keywords: ["resonance", "frequency", "harmonic", "standing", "wave", "oscillation"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Optics Calculators
      {
        id: "lens-formula",
        title: "Lens Formula Calculator",
        description: "Calculate focal length, object distance, image distance, and magnification for lenses",
        category: "physics",
        subcategory: "optics",
        icon: "eye",
        formula: "1/f = 1/u + 1/v, m = v/u = h'/h",
        variables: {
          inputs: [
            { name: "focalLength", label: "Focal Length (f)", unit: "cm", type: "number" },
            { name: "objectDistance", label: "Object Distance (u)", unit: "cm", type: "number", min: 0 },
            { name: "imageDistance", label: "Image Distance (v)", unit: "cm", type: "number" },
            { name: "objectHeight", label: "Object Height (h)", unit: "cm", type: "number", min: 0 },
            { name: "imageHeight", label: "Image Height (h')", unit: "cm", type: "number" }
          ],
          outputs: ["focalLength", "objectDistance", "imageDistance", "magnification", "imageHeight"],
          validationRules: {
            minimumFields: 2,
            description: "Enter at least 2 known values to calculate lens properties"
          }
        },
        usageCount: 6800,
        isActive: true,
        keywords: ["lens", "focal", "magnification", "optics", "refraction", "image"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "mirror-formula",
        title: "Mirror Formula Calculator",
        description: "Calculate focal length, object distance, and image formation for concave and convex mirrors",
        category: "physics",
        subcategory: "optics",
        icon: "mirror",
        formula: "1/f = 1/u + 1/v, m = -v/u",
        variables: {
          inputs: [
            { name: "focalLength", label: "Focal Length (f)", unit: "cm", type: "number" },
            { name: "objectDistance", label: "Object Distance (u)", unit: "cm", type: "number", min: 0 },
            { name: "imageDistance", label: "Image Distance (v)", unit: "cm", type: "number" },
            { name: "mirrorType", label: "Mirror Type", unit: "", type: "select", options: ["concave", "convex"], default: "concave" },
            { name: "objectHeight", label: "Object Height (h)", unit: "cm", type: "number", min: 0 }
          ],
          outputs: ["focalLength", "objectDistance", "imageDistance", "magnification", "imageNature"],
          validationRules: {
            minimumFields: 2,
            description: "Enter at least 2 known values to calculate mirror properties"
          }
        },
        usageCount: 5700,
        isActive: true,
        keywords: ["mirror", "concave", "convex", "focal", "reflection", "image"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "snells-law",
        title: "Snell's Law Calculator",
        description: "Calculate angles of incidence and refraction for light passing through different media",
        category: "physics",
        subcategory: "optics",
        icon: "triangle",
        formula: "n₁sin(θ₁) = n₂sin(θ₂)",
        variables: {
          inputs: [
            { name: "n1", label: "Refractive Index 1 (n₁)", unit: "", type: "number", required: true, min: 1 },
            { name: "n2", label: "Refractive Index 2 (n₂)", unit: "", type: "number", required: true, min: 1 },
            { name: "incidentAngle", label: "Incident Angle (θ₁)", unit: "degrees", type: "number", min: 0, max: 90 },
            { name: "refractedAngle", label: "Refracted Angle (θ₂)", unit: "degrees", type: "number", min: 0, max: 90 }
          ],
          outputs: ["incidentAngle", "refractedAngle", "criticalAngle"],
          validationRules: {
            minimumFields: 3,
            description: "Enter both refractive indices and one angle"
          }
        },
        usageCount: 8100,
        isActive: true,
        keywords: ["snell", "refraction", "angle", "refractive", "index", "light"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "critical-angle",
        title: "Critical Angle Calculator",
        description: "Calculate critical angle for total internal reflection between optical media",
        category: "physics",
        subcategory: "optics",
        icon: "zap",
        formula: "θc = arcsin(n₂/n₁)",
        variables: {
          inputs: [
            { name: "n1", label: "Denser Medium Index (n₁)", unit: "", type: "number", required: true, min: 1 },
            { name: "n2", label: "Rarer Medium Index (n₂)", unit: "", type: "number", required: true, min: 1 },
            { name: "incidentAngle", label: "Incident Angle", unit: "degrees", type: "number", min: 0, max: 90 }
          ],
          outputs: ["criticalAngle", "totalInternalReflection", "refractedAngle"],
          validationRules: {
            minimumFields: 2,
            description: "Enter refractive indices of both media"
          }
        },
        usageCount: 4300,
        isActive: true,
        keywords: ["critical", "angle", "reflection", "total", "internal", "optics"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "diffraction-calculator",
        title: "Diffraction Calculator",
        description: "Calculate single-slit diffraction patterns, minima, and intensity distribution",
        category: "physics",
        subcategory: "optics",
        icon: "grid",
        formula: "sin(θ) = nλ/a, I = I₀[sin(β)/β]²",
        variables: {
          inputs: [
            { name: "wavelength", label: "Wavelength (λ)", unit: "nm", type: "number", required: true, min: 0 },
            { name: "slitWidth", label: "Slit Width (a)", unit: "μm", type: "number", required: true, min: 0 },
            { name: "screenDistance", label: "Screen Distance (D)", unit: "m", type: "number", min: 0 },
            { name: "minOrder", label: "Minimum Order (n)", unit: "", type: "number", default: 1, min: 1 }
          ],
          outputs: ["diffractionAngle", "linearPosition", "intensity", "centralMaxWidth"],
          validationRules: {
            minimumFields: 2,
            description: "Enter wavelength and slit width for diffraction analysis"
          }
        },
        usageCount: 3400,
        isActive: true,
        keywords: ["diffraction", "slit", "wavelength", "interference", "pattern", "light"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Electricity & Magnetism Calculators (Additional)
      {
        id: "coulombs-law",
        title: "Coulomb's Law Calculator",
        description: "Calculate electrostatic force between charged particles",
        category: "physics",
        subcategory: "electricity",
        icon: "zap",
        formula: "F = k(q₁q₂)/r²",
        variables: {
          inputs: [
            { name: "charge1", label: "Charge 1 (q₁)", unit: "C", type: "number", required: true },
            { name: "charge2", label: "Charge 2 (q₂)", unit: "C", type: "number", required: true },
            { name: "distance", label: "Distance (r)", unit: "m", type: "number", required: true, min: 0 },
            { name: "coulombConstant", label: "Coulomb Constant (k)", unit: "N⋅m²/C²", type: "number", default: 8.99e9, min: 0 }
          ],
          outputs: ["electrostaticForce", "electricField1", "electricField2", "potentialEnergy"],
          validationRules: {
            minimumFields: 4,
            description: "Enter both charges, distance, and Coulomb constant"
          }
        },
        usageCount: 6900,
        isActive: true,
        keywords: ["coulomb", "electrostatic", "force", "charge", "electric", "field"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "electric-field",
        title: "Electric Field Calculator",
        description: "Calculate electric field strength, potential, and field properties",
        category: "physics",
        subcategory: "electricity",
        icon: "lightning",
        formula: "E = F/q = kQ/r², V = Ed",
        variables: {
          inputs: [
            { name: "charge", label: "Source Charge (Q)", unit: "C", type: "number", required: true },
            { name: "distance", label: "Distance (r)", unit: "m", type: "number", min: 0 },
            { name: "testCharge", label: "Test Charge (q)", unit: "C", type: "number" },
            { name: "force", label: "Electric Force (F)", unit: "N", type: "number" },
            { name: "potential", label: "Electric Potential (V)", unit: "V", type: "number" }
          ],
          outputs: ["electricField", "force", "potential", "fieldDirection"],
          validationRules: {
            minimumFields: 2,
            description: "Enter charge and distance, or other field parameters"
          }
        },
        usageCount: 5800,
        isActive: true,
        keywords: ["electric", "field", "potential", "charge", "voltage", "force"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "capacitance-calculator",
        title: "Capacitance Calculator",
        description: "Calculate capacitance, stored energy, and charge for capacitors",
        category: "physics",
        subcategory: "electricity",
        icon: "battery",
        formula: "C = Q/V, E = ½CV², C = ε₀A/d",
        variables: {
          inputs: [
            { name: "capacitance", label: "Capacitance (C)", unit: "F", type: "number", min: 0 },
            { name: "voltage", label: "Voltage (V)", unit: "V", type: "number", min: 0 },
            { name: "charge", label: "Charge (Q)", unit: "C", type: "number" },
            { name: "plateArea", label: "Plate Area (A)", unit: "m²", type: "number", min: 0 },
            { name: "separation", label: "Plate Separation (d)", unit: "m", type: "number", min: 0 },
            { name: "permittivity", label: "Permittivity (ε)", unit: "F/m", type: "number", default: 8.854e-12, min: 0 }
          ],
          outputs: ["capacitance", "charge", "voltage", "storedEnergy", "electricField"],
          validationRules: {
            minimumFields: 2,
            description: "Enter at least 2 values to calculate capacitor properties"
          }
        },
        usageCount: 4900,
        isActive: true,
        keywords: ["capacitor", "capacitance", "charge", "energy", "voltage", "electric"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "rc-circuit",
        title: "RC Circuit Calculator",
        description: "Calculate time constant, charge/discharge curves, and transient behavior",
        category: "physics",
        subcategory: "electricity",
        icon: "activity",
        formula: "τ = RC, Q(t) = Q₀(1-e^(-t/τ)), V(t) = V₀e^(-t/τ)",
        variables: {
          inputs: [
            { name: "resistance", label: "Resistance (R)", unit: "Ω", type: "number", min: 0 },
            { name: "capacitance", label: "Capacitance (C)", unit: "F", type: "number", min: 0 },
            { name: "voltage", label: "Supply Voltage (V₀)", unit: "V", type: "number", min: 0 },
            { name: "time", label: "Time (t)", unit: "s", type: "number", min: 0 }
          ],
          outputs: ["timeConstant", "chargeAtTime", "voltageAtTime", "currentAtTime", "timeToPercent"],
          validationRules: {
            minimumFields: 2,
            description: "Enter resistance and capacitance for RC circuit analysis"
          }
        },
        usageCount: 4100,
        isActive: true,
        keywords: ["rc", "circuit", "time", "constant", "charge", "discharge", "capacitor"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "inductance-calculator",
        title: "Inductance Calculator",
        description: "Calculate inductance, magnetic flux, and RL circuit behavior",
        category: "physics",
        subcategory: "electricity",
        icon: "coil",
        formula: "L = Φ/I, τ = L/R, E = -L(dI/dt)",
        variables: {
          inputs: [
            { name: "inductance", label: "Inductance (L)", unit: "H", type: "number", min: 0 },
            { name: "current", label: "Current (I)", unit: "A", type: "number" },
            { name: "magneticFlux", label: "Magnetic Flux (Φ)", unit: "Wb", type: "number" },
            { name: "resistance", label: "Resistance (R)", unit: "Ω", type: "number", min: 0 },
            { name: "voltage", label: "Applied Voltage (V)", unit: "V", type: "number" }
          ],
          outputs: ["inductance", "timeConstant", "magneticFlux", "inductiveReactance", "storedEnergy"],
          validationRules: {
            minimumFields: 2,
            description: "Enter inductance and current, or other circuit parameters"
          }
        },
        usageCount: 3200,
        isActive: true,
        keywords: ["inductance", "inductor", "magnetic", "flux", "coil", "henry"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "magnetic-force",
        title: "Magnetic Force Calculator",
        description: "Calculate magnetic force on moving charges and current-carrying conductors",
        category: "physics",
        subcategory: "electricity",
        icon: "magnet",
        formula: "F = qvB sin(θ), F = BIL sin(θ)",
        variables: {
          inputs: [
            { name: "charge", label: "Charge (q)", unit: "C", type: "number" },
            { name: "velocity", label: "Velocity (v)", unit: "m/s", type: "number", min: 0 },
            { name: "magneticField", label: "Magnetic Field (B)", unit: "T", type: "number", min: 0 },
            { name: "angle", label: "Angle (θ)", unit: "degrees", type: "number", min: 0, max: 180, default: 90 },
            { name: "current", label: "Current (I)", unit: "A", type: "number" },
            { name: "length", label: "Conductor Length (L)", unit: "m", type: "number", min: 0 }
          ],
          outputs: ["magneticForce", "forceDirection", "radius", "cyclotronFrequency"],
          validationRules: {
            minimumFields: 3,
            description: "Enter charge/current, velocity/length, and magnetic field"
          }
        },
        usageCount: 4600,
        isActive: true,
        keywords: ["magnetic", "force", "lorentz", "charge", "current", "field"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "faradays-law",
        title: "Faraday's Law Calculator",
        description: "Calculate induced EMF, magnetic flux, and electromagnetic induction",
        category: "physics",
        subcategory: "electricity",
        icon: "repeat",
        formula: "ε = -dΦ/dt = -N(dB/dt)A",
        variables: {
          inputs: [
            { name: "magneticFlux", label: "Magnetic Flux (Φ)", unit: "Wb", type: "number" },
            { name: "magneticField", label: "Magnetic Field (B)", unit: "T", type: "number", min: 0 },
            { name: "area", label: "Loop Area (A)", unit: "m²", type: "number", min: 0 },
            { name: "turns", label: "Number of Turns (N)", unit: "", type: "number", default: 1, min: 1 },
            { name: "time", label: "Time Interval (Δt)", unit: "s", type: "number", min: 0 },
            { name: "changeInFlux", label: "Change in Flux (ΔΦ)", unit: "Wb", type: "number" }
          ],
          outputs: ["inducedEMF", "magneticFlux", "fluxDensity", "inducedCurrent"],
          validationRules: {
            minimumFields: 2,
            description: "Enter flux change and time, or field and area parameters"
          }
        },
        usageCount: 3700,
        isActive: true,
        keywords: ["faraday", "induction", "emf", "flux", "magnetic", "electromagnetic"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "transformer-calculator",
        title: "Transformer Calculator",
        description: "Calculate voltage, current, and turn ratios for electrical transformers",
        category: "physics",
        subcategory: "electricity",
        icon: "shuffle",
        formula: "Vs/Vp = Ns/Np, Is/Ip = Np/Ns",
        variables: {
          inputs: [
            { name: "primaryVoltage", label: "Primary Voltage (Vp)", unit: "V", type: "number", min: 0 },
            { name: "secondaryVoltage", label: "Secondary Voltage (Vs)", unit: "V", type: "number", min: 0 },
            { name: "primaryTurns", label: "Primary Turns (Np)", unit: "", type: "number", min: 1 },
            { name: "secondaryTurns", label: "Secondary Turns (Ns)", unit: "", type: "number", min: 1 },
            { name: "primaryCurrent", label: "Primary Current (Ip)", unit: "A", type: "number", min: 0 },
            { name: "efficiency", label: "Efficiency", unit: "%", type: "number", default: 95, min: 0, max: 100 }
          ],
          outputs: ["secondaryVoltage", "secondaryCurrent", "turnRatio", "power", "efficiency"],
          validationRules: {
            minimumFields: 3,
            description: "Enter primary values and turn ratios for transformer calculations"
          }
        },
        usageCount: 5300,
        isActive: true,
        keywords: ["transformer", "voltage", "current", "turns", "ratio", "power"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "ac-circuit",
        title: "AC Circuit Calculator",
        description: "Calculate impedance, phase angle, and power in AC circuits",
        category: "physics",
        subcategory: "electricity",
        icon: "sine-wave",
        formula: "Z = √(R² + (XL - XC)²), φ = arctan((XL - XC)/R)",
        variables: {
          inputs: [
            { name: "resistance", label: "Resistance (R)", unit: "Ω", type: "number", min: 0 },
            { name: "inductiveReactance", label: "Inductive Reactance (XL)", unit: "Ω", type: "number", min: 0 },
            { name: "capacitiveReactance", label: "Capacitive Reactance (XC)", unit: "Ω", type: "number", min: 0 },
            { name: "frequency", label: "Frequency (f)", unit: "Hz", type: "number", min: 0 },
            { name: "voltage", label: "RMS Voltage (V)", unit: "V", type: "number", min: 0 }
          ],
          outputs: ["impedance", "phaseAngle", "activePower", "reactivePower", "apparentPower"],
          validationRules: {
            minimumFields: 2,
            description: "Enter resistance and reactance values for AC analysis"
          }
        },
        usageCount: 4400,
        isActive: true,
        keywords: ["ac", "circuit", "impedance", "phase", "reactance", "power"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Modern Physics Calculators
      {
        id: "photon-energy",
        title: "Photon Energy Calculator",
        description: "Calculate photon energy, frequency, wavelength using Planck's equation",
        category: "physics",
        subcategory: "modern",
        icon: "sun",
        formula: "E = hf = hc/λ",
        variables: {
          inputs: [
            { name: "frequency", label: "Frequency (f)", unit: "Hz", type: "number", min: 0 },
            { name: "wavelength", label: "Wavelength (λ)", unit: "nm", type: "number", min: 0 },
            { name: "energy", label: "Energy (E)", unit: "eV", type: "number", min: 0 },
            { name: "planckConstant", label: "Planck Constant (h)", unit: "J⋅s", type: "number", default: 6.62607015e-34, min: 0 },
            { name: "speedOfLight", label: "Speed of Light (c)", unit: "m/s", type: "number", default: 299792458, min: 0 }
          ],
          outputs: ["energy", "frequency", "wavelength", "momentum"],
          validationRules: {
            minimumFields: 1,
            description: "Enter frequency, wavelength, or energy to calculate photon properties"
          }
        },
        usageCount: 6400,
        isActive: true,
        keywords: ["photon", "energy", "planck", "frequency", "wavelength", "quantum"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "de-broglie-wavelength",
        title: "De Broglie Wavelength Calculator",
        description: "Calculate matter wave wavelength for particles using de Broglie equation",
        category: "physics",
        subcategory: "modern",
        icon: "atom",
        formula: "λ = h/p = h/mv",
        variables: {
          inputs: [
            { name: "mass", label: "Particle Mass (m)", unit: "kg", type: "number", required: true, min: 0 },
            { name: "velocity", label: "Velocity (v)", unit: "m/s", type: "number", min: 0 },
            { name: "momentum", label: "Momentum (p)", unit: "kg⋅m/s", type: "number", min: 0 },
            { name: "planckConstant", label: "Planck Constant (h)", unit: "J⋅s", type: "number", default: 6.62607015e-34, min: 0 },
            { name: "kineticEnergy", label: "Kinetic Energy (KE)", unit: "eV", type: "number", min: 0 }
          ],
          outputs: ["wavelength", "momentum", "velocity", "frequency"],
          validationRules: {
            minimumFields: 2,
            description: "Enter mass and velocity/momentum/energy to calculate de Broglie wavelength"
          }
        },
        usageCount: 2800,
        isActive: true,
        keywords: ["de broglie", "wavelength", "matter", "wave", "quantum", "momentum"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "half-life-calculator",
        title: "Half-Life Calculator",
        description: "Calculate radioactive decay, half-life, and activity using decay equations",
        category: "physics",
        subcategory: "modern",
        icon: "radiation",
        formula: "N(t) = N₀e^(-λt), t₁/₂ = ln(2)/λ",
        variables: {
          inputs: [
            { name: "initialAmount", label: "Initial Amount (N₀)", unit: "atoms", type: "number", min: 0 },
            { name: "finalAmount", label: "Final Amount (N)", unit: "atoms", type: "number", min: 0 },
            { name: "halfLife", label: "Half-Life (t₁/₂)", unit: "s", type: "number", min: 0 },
            { name: "time", label: "Time Elapsed (t)", unit: "s", type: "number", min: 0 },
            { name: "decayConstant", label: "Decay Constant (λ)", unit: "s⁻¹", type: "number", min: 0 }
          ],
          outputs: ["halfLife", "decayConstant", "finalAmount", "activity", "percentRemaining"],
          validationRules: {
            minimumFields: 2,
            description: "Enter half-life and time, or initial/final amounts"
          }
        },
        usageCount: 3900,
        isActive: true,
        keywords: ["half life", "radioactive", "decay", "nuclear", "activity", "isotope"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "radioactive-decay",
        title: "Radioactive Decay Calculator",
        description: "Calculate decay rates, activity, and nuclear decay statistics",
        category: "physics",
        subcategory: "modern",
        icon: "radioactive",
        formula: "A = λN, A₀ = λN₀, A(t) = A₀e^(-λt)",
        variables: {
          inputs: [
            { name: "initialActivity", label: "Initial Activity (A₀)", unit: "Bq", type: "number", min: 0 },
            { name: "activity", label: "Current Activity (A)", unit: "Bq", type: "number", min: 0 },
            { name: "decayConstant", label: "Decay Constant (λ)", unit: "s⁻¹", type: "number", min: 0 },
            { name: "time", label: "Time (t)", unit: "s", type: "number", min: 0 },
            { name: "numberOfNuclei", label: "Number of Nuclei (N)", unit: "", type: "number", min: 0 }
          ],
          outputs: ["activity", "numberOfNuclei", "halfLife", "meanLifetime", "massDefect"],
          validationRules: {
            minimumFields: 2,
            description: "Enter activity and time, or decay constant parameters"
          }
        },
        usageCount: 2600,
        isActive: true,
        keywords: ["radioactive", "decay", "activity", "nuclear", "becquerel", "radiation"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      {
        id: "ohms-law",
        title: "Ohm's Law Calculator",
        description: "Calculate voltage, current, resistance, and power using Ohm's law",
        category: "physics",
        subcategory: "electricity",
        icon: "bolt",
        formula: "V = IR, P = VI = I²R = V²/R",
        variables: {
          inputs: [
            { name: "voltage", label: "Voltage (V)", unit: "V", type: "number" },
            { name: "current", label: "Current (I)", unit: "A", type: "number" },
            { name: "resistance", label: "Resistance (R)", unit: "Ω", type: "number" },
            { name: "power", label: "Power (P)", unit: "W", type: "number" }
          ],
          outputs: ["voltage", "current", "resistance", "power"],
          validationRules: {
            minimumFields: 2,
            description: "Enter at least 2 known values to calculate the others"
          }
        },
        usageCount: 8200,
        isActive: true,
        keywords: ["ohm", "voltage", "current", "resistance", "power", "electricity"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      
      // Chemistry Calculators
      {
        id: "molarity-calculator",
        title: "Molarity Calculator",
        description: "Calculate molarity, moles, molecular weight, and volume of solutions",
        category: "chemistry",
        subcategory: "miscellaneous",
        icon: "flask",
        formula: "M = n/V, where M = molarity, n = moles, V = volume",
        variables: {
          inputs: [
            { name: "molarity", label: "Molarity (M)", unit: "mol/L", type: "number" },
            { name: "moles", label: "Moles (n)", unit: "mol", type: "number" },
            { name: "volume", label: "Volume (V)", unit: "L", type: "number" },
            { name: "molecularWeight", label: "Molecular Weight", unit: "g/mol", type: "number" },
            { name: "mass", label: "Mass", unit: "g", type: "number" }
          ],
          outputs: ["molarity", "moles", "volume", "mass"],
          validationRules: {
            minimumFields: 2,
            description: "Enter at least 2 known values to calculate molarity"
          }
        },
        usageCount: 15200,
        isActive: true,
        keywords: ["molarity", "concentration", "moles", "solution", "chemistry"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "ph-calculator",
        title: "pH Calculator",
        description: "Calculate pH, pOH, hydrogen and hydroxide ion concentrations",
        category: "chemistry",
        subcategory: "acid-base",
        icon: "tint",
        formula: "pH = -log[H⁺], pOH = -log[OH⁻], pH + pOH = 14",
        variables: {
          inputs: [
            { name: "ph", label: "pH", unit: "", type: "number", min: 0, max: 14 },
            { name: "poh", label: "pOH", unit: "", type: "number", min: 0, max: 14 },
            { name: "hydrogenConcentration", label: "[H⁺]", unit: "mol/L", type: "number", min: 0 },
            { name: "hydroxideConcentration", label: "[OH⁻]", unit: "mol/L", type: "number", min: 0 }
          ],
          outputs: ["ph", "poh", "hydrogenConcentration", "hydroxideConcentration"],
          validationRules: {
            minimumFields: 1,
            description: "Enter at least one known value to calculate the others"
          }
        },
        usageCount: 11700,
        isActive: true,
        keywords: ["ph", "acid", "base", "hydrogen", "hydroxide", "concentration"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Basic Chemistry Calculators
      {
        id: "molality-calculator",
        title: "Molality Calculator",
        description: "Calculate molality (moles solute per kg solvent), moles, mass, and molecular weight",
        category: "chemistry",
        subcategory: "basic-chemistry",
        icon: "test-tube",
        formula: "m = n_solute / kg_solvent, where m = molality, n = moles",
        variables: {
          inputs: [
            { name: "molality", label: "Molality (m)", unit: "mol/kg", type: "number", min: 0 },
            { name: "molesSolute", label: "Moles of Solute", unit: "mol", type: "number", min: 0 },
            { name: "massSolvent", label: "Mass of Solvent", unit: "kg", type: "number", min: 0 },
            { name: "massSolute", label: "Mass of Solute", unit: "g", type: "number", min: 0 },
            { name: "molecularWeight", label: "Molecular Weight", unit: "g/mol", type: "number", min: 0 }
          ],
          outputs: ["molality", "molesSolute", "massSolvent", "massSolute"],
          validationRules: {
            minimumFields: 2,
            description: "Enter at least 2 known values to calculate molality"
          }
        },
        usageCount: 6800,
        isActive: true,
        keywords: ["molality", "solute", "solvent", "concentration", "moles", "kg"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "normality-calculator",
        title: "Normality Calculator",
        description: "Calculate normality, equivalent weight, and number of equivalents in solutions",
        category: "chemistry",
        subcategory: "basic-chemistry",
        icon: "scale",
        formula: "N = n × M, Eq = mass / equivalent_weight, where N = normality",
        variables: {
          inputs: [
            { name: "normality", label: "Normality (N)", unit: "eq/L", type: "number", min: 0 },
            { name: "molarity", label: "Molarity (M)", unit: "mol/L", type: "number", min: 0 },
            { name: "nFactor", label: "n-Factor", unit: "", type: "number", min: 1, default: 1 },
            { name: "equivalents", label: "Number of Equivalents", unit: "eq", type: "number", min: 0 },
            { name: "volume", label: "Volume", unit: "L", type: "number", min: 0 },
            { name: "equivalentWeight", label: "Equivalent Weight", unit: "g/eq", type: "number", min: 0 },
            { name: "mass", label: "Mass", unit: "g", type: "number", min: 0 }
          ],
          outputs: ["normality", "equivalents", "equivalentWeight", "molarity"],
          validationRules: {
            minimumFields: 2,
            description: "Enter known values to calculate normality and equivalents"
          }
        },
        usageCount: 4200,
        isActive: true,
        keywords: ["normality", "equivalent", "weight", "concentration", "acid", "base"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "percentage-composition",
        title: "Percentage Composition Calculator",
        description: "Calculate mass percentage of elements in chemical compounds",
        category: "chemistry",
        subcategory: "basic-chemistry",
        icon: "pie-chart",
        formula: "% = (mass_element / total_mass) × 100",
        variables: {
          inputs: [
            { name: "elementMass", label: "Mass of Element", unit: "g", type: "number", min: 0 },
            { name: "totalMass", label: "Total Compound Mass", unit: "g", type: "number", min: 0 },
            { name: "atomicMass", label: "Atomic Mass", unit: "amu", type: "number", min: 0 },
            { name: "atomCount", label: "Number of Atoms", unit: "", type: "number", min: 1, default: 1 },
            { name: "molecularWeight", label: "Molecular Weight", unit: "g/mol", type: "number", min: 0 }
          ],
          outputs: ["percentage", "elementMass", "totalMass"],
          validationRules: {
            minimumFields: 2,
            description: "Enter element mass and total mass, or atomic data to calculate percentage"
          }
        },
        usageCount: 7100,
        isActive: true,
        keywords: ["percentage", "composition", "element", "compound", "mass", "atomic"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "empirical-formula",
        title: "Empirical Formula Calculator",
        description: "Determine empirical formula from percentage composition or mass data",
        category: "chemistry",
        subcategory: "basic-chemistry",
        icon: "formula",
        formula: "Convert % to moles, divide by smallest, find whole number ratios",
        variables: {
          inputs: [
            { name: "elements", label: "Elements (comma separated)", unit: "", type: "text", placeholder: "C, H, O", required: true },
            { name: "percentages", label: "Percentages (comma separated)", unit: "%", type: "text", placeholder: "40.0, 6.7, 53.3" },
            { name: "masses", label: "Masses (comma separated)", unit: "g", type: "text", placeholder: "12.0, 2.0, 16.0" }
          ],
          outputs: ["empiricalFormula", "moleRatios", "simplestRatios"],
          validationRules: {
            minimumFields: 2,
            description: "Enter elements and their percentages or masses"
          }
        },
        usageCount: 5600,
        isActive: true,
        keywords: ["empirical", "formula", "composition", "ratio", "moles", "elements"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "limiting-reagent",
        title: "Limiting Reagent Calculator",
        description: "Identify limiting reagent and calculate theoretical yield in chemical reactions",
        category: "chemistry",
        subcategory: "basic-chemistry",
        icon: "arrow-right",
        formula: "Compare mole ratios: actual vs stoichiometric",
        variables: {
          inputs: [
            { name: "reactant1Mass", label: "Reactant 1 Mass", unit: "g", type: "number", min: 0 },
            { name: "reactant1MW", label: "Reactant 1 Molecular Weight", unit: "g/mol", type: "number", min: 0 },
            { name: "reactant1Coeff", label: "Reactant 1 Coefficient", unit: "", type: "number", min: 1, default: 1 },
            { name: "reactant2Mass", label: "Reactant 2 Mass", unit: "g", type: "number", min: 0 },
            { name: "reactant2MW", label: "Reactant 2 Molecular Weight", unit: "g/mol", type: "number", min: 0 },
            { name: "reactant2Coeff", label: "Reactant 2 Coefficient", unit: "", type: "number", min: 1, default: 1 },
            { name: "productMW", label: "Product Molecular Weight", unit: "g/mol", type: "number", min: 0 },
            { name: "productCoeff", label: "Product Coefficient", unit: "", type: "number", min: 1, default: 1 }
          ],
          outputs: ["limitingReagent", "theoreticalYield", "excessAmount"],
          validationRules: {
            minimumFields: 6,
            description: "Enter masses, molecular weights, and coefficients for both reactants"
          }
        },
        usageCount: 4800,
        isActive: true,
        keywords: ["limiting", "reagent", "reactant", "yield", "stoichiometry", "excess"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "percent-yield",
        title: "Percent Yield Calculator",
        description: "Calculate percent yield comparing actual vs theoretical yield",
        category: "chemistry",
        subcategory: "basic-chemistry",
        icon: "percent",
        formula: "% Yield = (Actual Yield / Theoretical Yield) × 100",
        variables: {
          inputs: [
            { name: "actualYield", label: "Actual Yield", unit: "g", type: "number", min: 0 },
            { name: "theoreticalYield", label: "Theoretical Yield", unit: "g", type: "number", min: 0 },
            { name: "percentYield", label: "Percent Yield", unit: "%", type: "number", min: 0, max: 100 }
          ],
          outputs: ["percentYield", "actualYield", "theoreticalYield"],
          validationRules: {
            minimumFields: 2,
            description: "Enter any 2 values to calculate the third"
          }
        },
        usageCount: 6200,
        isActive: true,
        keywords: ["percent", "yield", "actual", "theoretical", "efficiency", "reaction"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "stoichiometry-calculator",
        title: "Stoichiometry Calculator",
        description: "Calculate mole ratios and quantities in balanced chemical equations",
        category: "chemistry",
        subcategory: "basic-chemistry",
        icon: "balance-scale",
        formula: "Mole ratio from balanced equation: n₁/c₁ = n₂/c₂",
        variables: {
          inputs: [
            { name: "knownMoles", label: "Known Moles", unit: "mol", type: "number", min: 0 },
            { name: "knownMass", label: "Known Mass", unit: "g", type: "number", min: 0 },
            { name: "knownMW", label: "Known Molecular Weight", unit: "g/mol", type: "number", min: 0 },
            { name: "knownCoeff", label: "Known Coefficient", unit: "", type: "number", min: 1, default: 1 },
            { name: "unknownCoeff", label: "Unknown Coefficient", unit: "", type: "number", min: 1, default: 1 },
            { name: "unknownMW", label: "Unknown Molecular Weight", unit: "g/mol", type: "number", min: 0 }
          ],
          outputs: ["unknownMoles", "unknownMass", "moleRatio"],
          validationRules: {
            minimumFields: 4,
            description: "Enter known substance data and coefficients to calculate unknown quantities"
          }
        },
        usageCount: 8500,
        isActive: true,
        keywords: ["stoichiometry", "mole", "ratio", "balanced", "equation", "coefficient"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Gas Laws Calculators
      {
        id: "boyles-law",
        title: "Boyle's Law Calculator",
        description: "Calculate pressure and volume relationships at constant temperature using Boyle's Law",
        category: "chemistry",
        subcategory: "gas-laws",
        icon: "thermometer",
        formula: "P₁V₁ = P₂V₂ (at constant temperature)",
        variables: {
          inputs: [
            { name: "pressure1", label: "Initial Pressure (P₁)", unit: "atm", type: "number", min: 0 },
            { name: "volume1", label: "Initial Volume (V₁)", unit: "L", type: "number", min: 0 },
            { name: "pressure2", label: "Final Pressure (P₂)", unit: "atm", type: "number", min: 0 },
            { name: "volume2", label: "Final Volume (V₂)", unit: "L", type: "number", min: 0 }
          ],
          outputs: ["pressure1", "volume1", "pressure2", "volume2"],
          validationRules: {
            minimumFields: 3,
            description: "Enter any 3 values to calculate the fourth using Boyle's Law"
          }
        },
        usageCount: 5400,
        isActive: true,
        keywords: ["boyle", "pressure", "volume", "gas", "law", "temperature"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "charles-law",
        title: "Charles's Law Calculator", 
        description: "Calculate volume and temperature relationships at constant pressure using Charles's Law",
        category: "chemistry",
        subcategory: "gas-laws",
        icon: "gauge",
        formula: "V₁/T₁ = V₂/T₂ (at constant pressure)",
        variables: {
          inputs: [
            { name: "volume1", label: "Initial Volume (V₁)", unit: "L", type: "number", min: 0 },
            { name: "temperature1", label: "Initial Temperature (T₁)", unit: "K", type: "number", min: 0 },
            { name: "volume2", label: "Final Volume (V₂)", unit: "L", type: "number", min: 0 },
            { name: "temperature2", label: "Final Temperature (T₂)", unit: "K", type: "number", min: 0 }
          ],
          outputs: ["volume1", "temperature1", "volume2", "temperature2"],
          validationRules: {
            minimumFields: 3,
            description: "Enter any 3 values to calculate the fourth using Charles's Law"
          }
        },
        usageCount: 4800,
        isActive: true,
        keywords: ["charles", "volume", "temperature", "gas", "law", "pressure"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "daltons-law",
        title: "Dalton's Law Calculator",
        description: "Calculate partial pressures and total pressure in gas mixtures using Dalton's Law",
        category: "chemistry",
        subcategory: "gas-laws",
        icon: "layers",
        formula: "P_total = P₁ + P₂ + P₃ + ... (sum of partial pressures)",
        variables: {
          inputs: [
            { name: "totalPressure", label: "Total Pressure", unit: "atm", type: "number", min: 0 },
            { name: "partialPressure1", label: "Partial Pressure 1", unit: "atm", type: "number", min: 0 },
            { name: "partialPressure2", label: "Partial Pressure 2", unit: "atm", type: "number", min: 0 },
            { name: "partialPressure3", label: "Partial Pressure 3", unit: "atm", type: "number", min: 0 },
            { name: "moles1", label: "Moles Gas 1", unit: "mol", type: "number", min: 0 },
            { name: "moles2", label: "Moles Gas 2", unit: "mol", type: "number", min: 0 },
            { name: "totalMoles", label: "Total Moles", unit: "mol", type: "number", min: 0 }
          ],
          outputs: ["totalPressure", "partialPressure1", "partialPressure2", "partialPressure3", "moleFraction"],
          validationRules: {
            minimumFields: 2,
            description: "Enter known pressures or mole data to calculate partial pressures"
          }
        },
        usageCount: 3900,
        isActive: true,
        keywords: ["dalton", "partial", "pressure", "mixture", "gas", "law"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "grahams-diffusion",
        title: "Graham's Law of Diffusion Calculator",
        description: "Calculate relative rates of diffusion and effusion for different gases",
        category: "chemistry",
        subcategory: "gas-laws",
        icon: "wind",
        formula: "Rate₁/Rate₂ = √(M₂/M₁), where M = molar mass",
        variables: {
          inputs: [
            { name: "rate1", label: "Rate of Gas 1", unit: "mol/s", type: "number", min: 0 },
            { name: "rate2", label: "Rate of Gas 2", unit: "mol/s", type: "number", min: 0 },
            { name: "molarMass1", label: "Molar Mass Gas 1", unit: "g/mol", type: "number", min: 0 },
            { name: "molarMass2", label: "Molar Mass Gas 2", unit: "g/mol", type: "number", min: 0 },
            { name: "time1", label: "Time Gas 1", unit: "s", type: "number", min: 0 },
            { name: "time2", label: "Time Gas 2", unit: "s", type: "number", min: 0 }
          ],
          outputs: ["rate1", "rate2", "rateRatio", "timeRatio"],
          validationRules: {
            minimumFields: 3,
            description: "Enter molar masses and one rate or time to calculate diffusion rates"
          }
        },
        usageCount: 2800,
        isActive: true,
        keywords: ["graham", "diffusion", "effusion", "rate", "molar", "mass"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "gay-lussac-law",
        title: "Gay-Lussac's Law Calculator",
        description: "Calculate pressure and temperature relationships at constant volume using Gay-Lussac's Law",
        category: "chemistry",
        subcategory: "gas-laws",
        icon: "thermometer",
        formula: "P₁/T₁ = P₂/T₂ (at constant volume)",
        variables: {
          inputs: [
            { name: "pressure1", label: "Initial Pressure (P₁)", unit: "atm", type: "number", min: 0 },
            { name: "temperature1", label: "Initial Temperature (T₁)", unit: "K", type: "number", min: 0 },
            { name: "pressure2", label: "Final Pressure (P₂)", unit: "atm", type: "number", min: 0 },
            { name: "temperature2", label: "Final Temperature (T₂)", unit: "K", type: "number", min: 0 }
          ],
          outputs: ["pressure1", "temperature1", "pressure2", "temperature2"],
          validationRules: {
            minimumFields: 3,
            description: "Enter any 3 values to calculate the fourth using Gay-Lussac's Law"
          }
        },
        usageCount: 4200,
        isActive: true,
        keywords: ["gay", "lussac", "pressure", "temperature", "gas", "law", "volume"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "combined-gas-law",
        title: "Combined Gas Law Calculator",
        description: "Calculate pressure, volume, and temperature relationships using the Combined Gas Law",
        category: "chemistry",
        subcategory: "gas-laws",
        icon: "layers",
        formula: "P₁V₁/T₁ = P₂V₂/T₂",
        variables: {
          inputs: [
            { name: "pressure1", label: "Initial Pressure (P₁)", unit: "atm", type: "number", min: 0 },
            { name: "volume1", label: "Initial Volume (V₁)", unit: "L", type: "number", min: 0 },
            { name: "temperature1", label: "Initial Temperature (T₁)", unit: "K", type: "number", min: 0 },
            { name: "pressure2", label: "Final Pressure (P₂)", unit: "atm", type: "number", min: 0 },
            { name: "volume2", label: "Final Volume (V₂)", unit: "L", type: "number", min: 0 },
            { name: "temperature2", label: "Final Temperature (T₂)", unit: "K", type: "number", min: 0 }
          ],
          outputs: ["pressure1", "volume1", "temperature1", "pressure2", "volume2", "temperature2"],
          validationRules: {
            minimumFields: 5,
            description: "Enter any 5 values to calculate the sixth using Combined Gas Law"
          }
        },
        usageCount: 6700,
        isActive: true,
        keywords: ["combined", "gas", "law", "pressure", "volume", "temperature"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "ideal-gas-law",
        title: "Ideal Gas Law Calculator",
        description: "Calculate pressure, volume, temperature, and moles using the Ideal Gas Law (PV = nRT)",
        category: "chemistry",
        subcategory: "gas-laws",
        icon: "atom",
        formula: "PV = nRT, where R = 0.08206 L⋅atm/(mol⋅K)",
        variables: {
          inputs: [
            { name: "pressure", label: "Pressure (P)", unit: "atm", type: "number", min: 0 },
            { name: "volume", label: "Volume (V)", unit: "L", type: "number", min: 0 },
            { name: "moles", label: "Moles (n)", unit: "mol", type: "number", min: 0 },
            { name: "temperature", label: "Temperature (T)", unit: "K", type: "number", min: 0 },
            { name: "gasConstant", label: "Gas Constant (R)", unit: "L⋅atm/(mol⋅K)", type: "number", default: 0.08206, min: 0 },
            { name: "mass", label: "Mass", unit: "g", type: "number", min: 0 },
            { name: "molecularWeight", label: "Molecular Weight", unit: "g/mol", type: "number", min: 0 }
          ],
          outputs: ["pressure", "volume", "moles", "temperature", "mass", "density"],
          validationRules: {
            minimumFields: 3,
            description: "Enter at least 3 values to calculate others using PV = nRT"
          }
        },
        usageCount: 9800,
        isActive: true,
        keywords: ["ideal", "gas", "law", "pressure", "volume", "temperature", "moles", "pv", "nrt"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "vant-hoff-factor",
        title: "Van't Hoff Factor Calculator",
        description: "Calculate Van't Hoff factor and colligative properties for solutions",
        category: "chemistry",
        subcategory: "gas-laws",
        icon: "droplet",
        formula: "i = (observed property) / (theoretical property)",
        variables: {
          inputs: [
            { name: "vantHoffFactor", label: "Van't Hoff Factor (i)", unit: "", type: "number", min: 0 },
            { name: "molality", label: "Molality (m)", unit: "mol/kg", type: "number", min: 0 },
            { name: "freezingPointDepression", label: "Freezing Point Depression (ΔTf)", unit: "°C", type: "number", min: 0 },
            { name: "boilingPointElevation", label: "Boiling Point Elevation (ΔTb)", unit: "°C", type: "number", min: 0 },
            { name: "osmoticPressure", label: "Osmotic Pressure (Π)", unit: "atm", type: "number", min: 0 },
            { name: "kf", label: "Freezing Point Constant (Kf)", unit: "°C⋅kg/mol", type: "number", min: 0, default: 1.86 },
            { name: "kb", label: "Boiling Point Constant (Kb)", unit: "°C⋅kg/mol", type: "number", min: 0, default: 0.512 },
            { name: "temperature", label: "Temperature (T)", unit: "K", type: "number", min: 0, default: 298.15 }
          ],
          outputs: ["vantHoffFactor", "freezingPointDepression", "boilingPointElevation", "osmoticPressure"],
          validationRules: {
            minimumFields: 3,
            description: "Enter molality and observed colligative property to calculate i factor"
          }
        },
        usageCount: 3200,
        isActive: true,
        keywords: ["vant", "hoff", "colligative", "freezing", "boiling", "osmotic"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Additional Acid-Base Chemistry Calculators
      {
        id: "pka-pkb-calculator",
        title: "pKa/pKb Calculator",
        description: "Calculate pKa, pKb, Ka, Kb, and acid-base strength relationships",
        category: "chemistry",
        subcategory: "acid-base",
        icon: "activity",
        formula: "pKa = -log(Ka), pKb = -log(Kb), pKa + pKb = 14",
        variables: {
          inputs: [
            { name: "pka", label: "pKa", unit: "", type: "number", min: 0, max: 14 },
            { name: "pkb", label: "pKb", unit: "", type: "number", min: 0, max: 14 },
            { name: "ka", label: "Ka (acid dissociation constant)", unit: "mol/L", type: "number", min: 0 },
            { name: "kb", label: "Kb (base dissociation constant)", unit: "mol/L", type: "number", min: 0 }
          ],
          outputs: ["pka", "pkb", "ka", "kb", "strength"],
          validationRules: {
            minimumFields: 1,
            description: "Enter any one value to calculate the others"
          }
        },
        usageCount: 4600,
        isActive: true,
        keywords: ["pka", "pkb", "acid", "base", "dissociation", "constant", "equilibrium"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "buffer-calculator",
        title: "Buffer Calculator",
        description: "Calculate buffer pH, capacity, and composition using weak acid/base pairs",
        category: "chemistry",
        subcategory: "acid-base",
        icon: "shield",
        formula: "pH = pKa + log([A⁻]/[HA]) (Henderson-Hasselbalch equation)",
        variables: {
          inputs: [
            { name: "weakAcidConc", label: "Weak Acid Concentration [HA]", unit: "mol/L", type: "number", min: 0 },
            { name: "conjugateBaseConc", label: "Conjugate Base Concentration [A⁻]", unit: "mol/L", type: "number", min: 0 },
            { name: "pka", label: "pKa of Weak Acid", unit: "", type: "number", min: 0, max: 14 },
            { name: "totalVolume", label: "Total Volume", unit: "L", type: "number", min: 0 },
            { name: "strongAcidAdded", label: "Strong Acid Added", unit: "mol", type: "number", min: 0 },
            { name: "strongBaseAdded", label: "Strong Base Added", unit: "mol", type: "number", min: 0 }
          ],
          outputs: ["bufferPH", "bufferCapacity", "newPH", "ratioChange"],
          validationRules: {
            minimumFields: 3,
            description: "Enter acid/base concentrations and pKa to calculate buffer properties"
          }
        },
        usageCount: 5200,
        isActive: true,
        keywords: ["buffer", "ph", "weak", "acid", "base", "capacity", "henderson"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "henderson-hasselbalch",
        title: "Henderson-Hasselbalch Calculator",
        description: "Calculate pH of buffer solutions using the Henderson-Hasselbalch equation",
        category: "chemistry",
        subcategory: "acid-base",
        icon: "beaker",
        formula: "pH = pKa + log([A⁻]/[HA])",
        variables: {
          inputs: [
            { name: "pka", label: "pKa", unit: "", type: "number", min: 0, max: 14, required: true },
            { name: "acidConcentration", label: "Acid Concentration [HA]", unit: "mol/L", type: "number", min: 0 },
            { name: "baseConcentration", label: "Base Concentration [A⁻]", unit: "mol/L", type: "number", min: 0 },
            { name: "ratio", label: "[A⁻]/[HA] Ratio", unit: "", type: "number", min: 0 },
            { name: "pH", label: "pH", unit: "", type: "number", min: 0, max: 14 }
          ],
          outputs: ["pH", "ratio", "acidConcentration", "baseConcentration"],
          validationRules: {
            minimumFields: 2,
            description: "Enter pKa and either concentrations, ratio, or pH"
          }
        },
        usageCount: 6800,
        isActive: true,
        keywords: ["henderson", "hasselbalch", "buffer", "ph", "pka", "ratio"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "neutralization-calculator",
        title: "Neutralization Calculator",
        description: "Calculate neutralization reactions, equivalence points, and titration curves",
        category: "chemistry",
        subcategory: "acid-base",
        icon: "droplets",
        formula: "n_acid × M_acid × V_acid = n_base × M_base × V_base",
        variables: {
          inputs: [
            { name: "acidMolarity", label: "Acid Molarity (Ma)", unit: "mol/L", type: "number", min: 0 },
            { name: "acidVolume", label: "Acid Volume (Va)", unit: "L", type: "number", min: 0 },
            { name: "baseMolarity", label: "Base Molarity (Mb)", unit: "mol/L", type: "number", min: 0 },
            { name: "baseVolume", label: "Base Volume (Vb)", unit: "L", type: "number", min: 0 },
            { name: "acidValence", label: "Acid Valence (n_acid)", unit: "", type: "number", min: 1, default: 1 },
            { name: "baseValence", label: "Base Valence (n_base)", unit: "", type: "number", min: 1, default: 1 }
          ],
          outputs: ["equivalentVolume", "equivalentMolarity", "excessReagent", "finalPH"],
          validationRules: {
            minimumFields: 5,
            description: "Enter molarity and volume for both acid and base, plus valences"
          }
        },
        usageCount: 5800,
        isActive: true,
        keywords: ["neutralization", "titration", "equivalence", "point", "acid", "base"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "solubility-product",
        title: "Solubility Product Calculator",
        description: "Calculate Ksp, molar solubility, and precipitation conditions",
        category: "chemistry",
        subcategory: "acid-base",
        icon: "test-tube-diagonal",
        formula: "Ksp = [A⁺]ᵐ[B⁻]ⁿ for AmBn(s) ⇌ mA⁺(aq) + nB⁻(aq)",
        variables: {
          inputs: [
            { name: "ksp", label: "Solubility Product (Ksp)", unit: "(mol/L)ⁿ", type: "number", min: 0 },
            { name: "molarSolubility", label: "Molar Solubility (s)", unit: "mol/L", type: "number", min: 0 },
            { name: "cationCoeff", label: "Cation Coefficient (m)", unit: "", type: "number", min: 1, default: 1 },
            { name: "anionCoeff", label: "Anion Coefficient (n)", unit: "", type: "number", min: 1, default: 1 },
            { name: "cationConc", label: "Cation Concentration", unit: "mol/L", type: "number", min: 0 },
            { name: "anionConc", label: "Anion Concentration", unit: "mol/L", type: "number", min: 0 },
            { name: "commonIonConc", label: "Common Ion Concentration", unit: "mol/L", type: "number", min: 0 }
          ],
          outputs: ["ksp", "molarSolubility", "ionProduct", "precipitationStatus"],
          validationRules: {
            minimumFields: 3,
            description: "Enter Ksp or solubility with stoichiometric coefficients"
          }
        },
        usageCount: 4100,
        isActive: true,
        keywords: ["solubility", "product", "ksp", "precipitation", "equilibrium", "ionic"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Thermodynamics Calculators
      {
        id: "reaction-rate",
        title: "Reaction Rate Calculator",
        description: "Calculate reaction rates, rate constants, and kinetic parameters for chemical reactions",
        category: "chemistry",
        subcategory: "thermodynamics",
        icon: "trending-up",
        formula: "Rate = k[A]^m[B]^n, where k = rate constant, m,n = reaction orders",
        variables: {
          inputs: [
            { name: "rateConstant", label: "Rate Constant (k)", unit: "(mol/L)^(1-n)/s", type: "number", min: 0 },
            { name: "concentrationA", label: "Concentration A", unit: "mol/L", type: "number", min: 0 },
            { name: "concentrationB", label: "Concentration B", unit: "mol/L", type: "number", min: 0 },
            { name: "orderA", label: "Order with respect to A", unit: "", type: "number", min: 0, default: 1 },
            { name: "orderB", label: "Order with respect to B", unit: "", type: "number", min: 0, default: 1 },
            { name: "reactionRate", label: "Reaction Rate", unit: "mol/(L⋅s)", type: "number", min: 0 },
            { name: "halfLife", label: "Half Life (t₁/₂)", unit: "s", type: "number", min: 0 }
          ],
          outputs: ["reactionRate", "rateConstant", "halfLife", "overallOrder"],
          validationRules: {
            minimumFields: 4,
            description: "Enter concentrations, orders, and rate constant or rate to calculate kinetics"
          }
        },
        usageCount: 3800,
        isActive: true,
        keywords: ["reaction", "rate", "kinetics", "constant", "order", "half", "life"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "arrhenius-calculator",
        title: "Arrhenius Equation Calculator",
        description: "Calculate activation energy, rate constants, and temperature dependence using Arrhenius equation",
        category: "chemistry",
        subcategory: "thermodynamics",
        icon: "thermometer-sun",
        formula: "k = A⋅e^(-Ea/RT), ln(k₂/k₁) = (Ea/R)(1/T₁ - 1/T₂)",
        variables: {
          inputs: [
            { name: "rateConstant1", label: "Rate Constant 1 (k₁)", unit: "s⁻¹", type: "number", min: 0 },
            { name: "rateConstant2", label: "Rate Constant 2 (k₂)", unit: "s⁻¹", type: "number", min: 0 },
            { name: "temperature1", label: "Temperature 1 (T₁)", unit: "K", type: "number", min: 0 },
            { name: "temperature2", label: "Temperature 2 (T₂)", unit: "K", type: "number", min: 0 },
            { name: "activationEnergy", label: "Activation Energy (Ea)", unit: "J/mol", type: "number", min: 0 },
            { name: "preExponentialFactor", label: "Pre-exponential Factor (A)", unit: "s⁻¹", type: "number", min: 0 },
            { name: "gasConstant", label: "Gas Constant (R)", unit: "J/(mol⋅K)", type: "number", default: 8.314, min: 0 }
          ],
          outputs: ["activationEnergy", "rateConstant1", "rateConstant2", "preExponentialFactor"],
          validationRules: {
            minimumFields: 4,
            description: "Enter two temperatures and rate constants, or activation energy and one rate/temp pair"
          }
        },
        usageCount: 2900,
        isActive: true,
        keywords: ["arrhenius", "activation", "energy", "temperature", "rate", "constant"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "gibbs-free-energy",
        title: "Gibbs Free Energy Calculator",
        description: "Calculate Gibbs free energy, spontaneity, and equilibrium constants",
        category: "chemistry",
        subcategory: "thermodynamics",
        icon: "arrow-down-up",
        formula: "ΔG = ΔH - TΔS, ΔG° = -RT⋅ln(K), ΔG = ΔG° + RT⋅ln(Q)",
        variables: {
          inputs: [
            { name: "enthalpy", label: "Enthalpy Change (ΔH)", unit: "J/mol", type: "number" },
            { name: "entropy", label: "Entropy Change (ΔS)", unit: "J/(mol⋅K)", type: "number" },
            { name: "temperature", label: "Temperature (T)", unit: "K", type: "number", min: 0, default: 298.15 },
            { name: "gibbsFreeEnergy", label: "Gibbs Free Energy (ΔG)", unit: "J/mol", type: "number" },
            { name: "equilibriumConstant", label: "Equilibrium Constant (K)", unit: "", type: "number", min: 0 },
            { name: "reactionQuotient", label: "Reaction Quotient (Q)", unit: "", type: "number", min: 0 },
            { name: "gasConstant", label: "Gas Constant (R)", unit: "J/(mol⋅K)", type: "number", default: 8.314, min: 0 }
          ],
          outputs: ["gibbsFreeEnergy", "spontaneity", "equilibriumConstant", "reactionQuotient"],
          validationRules: {
            minimumFields: 3,
            description: "Enter ΔH and ΔS with temperature, or ΔG with other thermodynamic values"
          }
        },
        usageCount: 4500,
        isActive: true,
        keywords: ["gibbs", "free", "energy", "spontaneity", "equilibrium", "thermodynamics"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "enthalpy-calculator",
        title: "Enthalpy Calculator",
        description: "Calculate enthalpy changes for reactions, phase transitions, and heating/cooling processes",
        category: "chemistry",
        subcategory: "thermodynamics",
        icon: "flame",
        formula: "ΔH = Σ(ΔHf products) - Σ(ΔHf reactants), q = n⋅ΔH, q = m⋅c⋅ΔT",
        variables: {
          inputs: [
            { name: "enthalpyChange", label: "Enthalpy Change (ΔH)", unit: "J/mol", type: "number" },
            { name: "moles", label: "Number of Moles (n)", unit: "mol", type: "number", min: 0 },
            { name: "heat", label: "Heat (q)", unit: "J", type: "number" },
            { name: "mass", label: "Mass (m)", unit: "g", type: "number", min: 0 },
            { name: "specificHeat", label: "Specific Heat (c)", unit: "J/(g⋅°C)", type: "number", min: 0 },
            { name: "temperatureChange", label: "Temperature Change (ΔT)", unit: "°C", type: "number" },
            { name: "enthalpyFormation", label: "Enthalpy of Formation", unit: "J/mol", type: "number" },
            { name: "enthalpyFusion", label: "Enthalpy of Fusion", unit: "J/mol", type: "number", min: 0 }
          ],
          outputs: ["enthalpyChange", "heat", "moles", "temperatureChange"],
          validationRules: {
            minimumFields: 2,
            description: "Enter values to calculate enthalpy changes and heat transfer"
          }
        },
        usageCount: 5200,
        isActive: true,
        keywords: ["enthalpy", "heat", "formation", "fusion", "combustion", "calorimetry"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "entropy-calculator",
        title: "Entropy Calculator",
        description: "Calculate entropy changes, disorder, and the second law of thermodynamics",
        category: "chemistry",
        subcategory: "thermodynamics",
        icon: "shuffle",
        formula: "ΔS = Σ(S° products) - Σ(S° reactants), ΔS = q_rev/T, ΔS = nR⋅ln(Vf/Vi)",
        variables: {
          inputs: [
            { name: "entropyChange", label: "Entropy Change (ΔS)", unit: "J/(mol⋅K)", type: "number" },
            { name: "heat", label: "Heat (q)", unit: "J", type: "number" },
            { name: "temperature", label: "Temperature (T)", unit: "K", type: "number", min: 0 },
            { name: "moles", label: "Number of Moles (n)", unit: "mol", type: "number", min: 0 },
            { name: "initialVolume", label: "Initial Volume (Vi)", unit: "L", type: "number", min: 0 },
            { name: "finalVolume", label: "Final Volume (Vf)", unit: "L", type: "number", min: 0 },
            { name: "gasConstant", label: "Gas Constant (R)", unit: "J/(mol⋅K)", type: "number", default: 8.314, min: 0 },
            { name: "standardEntropy", label: "Standard Entropy (S°)", unit: "J/(mol⋅K)", type: "number", min: 0 }
          ],
          outputs: ["entropyChange", "heat", "standardEntropy", "disorder"],
          validationRules: {
            minimumFields: 2,
            description: "Enter values to calculate entropy changes and system disorder"
          }
        },
        usageCount: 3600,
        isActive: true,
        keywords: ["entropy", "disorder", "second", "law", "thermodynamics", "reversible"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Electrochemistry Calculators
      {
        id: "nernst-equation",
        title: "Nernst Equation Calculator",
        description: "Calculate electrode potentials, cell potentials, and concentration effects in electrochemical cells",
        category: "chemistry",
        subcategory: "electrochemistry",
        icon: "battery",
        formula: "E = E° - (RT/nF)⋅ln(Q), where E = cell potential, Q = reaction quotient",
        variables: {
          inputs: [
            { name: "standardPotential", label: "Standard Potential (E°)", unit: "V", type: "number" },
            { name: "cellPotential", label: "Cell Potential (E)", unit: "V", type: "number" },
            { name: "temperature", label: "Temperature (T)", unit: "K", type: "number", min: 0, default: 298.15 },
            { name: "electronsTransferred", label: "Electrons Transferred (n)", unit: "", type: "number", min: 1, required: true },
            { name: "reactionQuotient", label: "Reaction Quotient (Q)", unit: "", type: "number", min: 0 },
            { name: "oxidizedConc", label: "Oxidized Species Concentration", unit: "mol/L", type: "number", min: 0 },
            { name: "reducedConc", label: "Reduced Species Concentration", unit: "mol/L", type: "number", min: 0 },
            { name: "gasConstant", label: "Gas Constant (R)", unit: "J/(mol⋅K)", type: "number", default: 8.314, min: 0 },
            { name: "faradayConstant", label: "Faraday Constant (F)", unit: "C/mol", type: "number", default: 96485, min: 0 }
          ],
          outputs: ["cellPotential", "standardPotential", "reactionQuotient", "spontaneity"],
          validationRules: {
            minimumFields: 4,
            description: "Enter standard potential, temperature, electrons transferred, and concentration data"
          }
        },
        usageCount: 2800,
        isActive: true,
        keywords: ["nernst", "electrode", "potential", "electrochemical", "cell", "redox"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "electrolysis-calculator",
        title: "Electrolysis Calculator",
        description: "Calculate quantities in electrolysis using Faraday's laws of electrolysis",
        category: "chemistry",
        subcategory: "electrochemistry",
        icon: "zap",
        formula: "m = (I⋅t⋅M)/(n⋅F), Q = I⋅t, moles = Q/(n⋅F)",
        variables: {
          inputs: [
            { name: "current", label: "Current (I)", unit: "A", type: "number", min: 0 },
            { name: "time", label: "Time (t)", unit: "s", type: "number", min: 0 },
            { name: "charge", label: "Total Charge (Q)", unit: "C", type: "number", min: 0 },
            { name: "molarMass", label: "Molar Mass (M)", unit: "g/mol", type: "number", min: 0 },
            { name: "electronsTransferred", label: "Electrons Transferred (n)", unit: "", type: "number", min: 1 },
            { name: "massDeposited", label: "Mass Deposited (m)", unit: "g", type: "number", min: 0 },
            { name: "molesProduced", label: "Moles Produced", unit: "mol", type: "number", min: 0 },
            { name: "faradayConstant", label: "Faraday Constant (F)", unit: "C/mol", type: "number", default: 96485, min: 0 }
          ],
          outputs: ["massDeposited", "molesProduced", "charge", "gasVolume"],
          validationRules: {
            minimumFields: 4,
            description: "Enter current, time, molar mass, and electrons transferred for electrolysis calculations"
          }
        },
        usageCount: 2400,
        isActive: true,
        keywords: ["electrolysis", "faraday", "current", "charge", "electrode", "deposition"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "redox-balancer",
        title: "Redox Balancer Calculator",
        description: "Balance redox equations and calculate electron transfer in chemical reactions",
        category: "chemistry",
        subcategory: "electrochemistry",
        icon: "arrows-right-left",
        formula: "Balance half-reactions: oxidation + reduction, ensure electron balance",
        variables: {
          inputs: [
            { name: "reactants", label: "Reactants (comma separated)", unit: "", type: "text", placeholder: "Mn2+, H2O2", required: true },
            { name: "products", label: "Products (comma separated)", unit: "", type: "text", placeholder: "Mn4+, H2O" },
            { name: "environment", label: "Environment", unit: "", type: "select", options: ["acidic", "basic", "neutral"], default: "acidic" },
            { name: "oxidationHalf", label: "Oxidation Half-Reaction", unit: "", type: "text", placeholder: "Fe → Fe³⁺ + 3e⁻" },
            { name: "reductionHalf", label: "Reduction Half-Reaction", unit: "", type: "text", placeholder: "Cr₂O₇²⁻ + 14H⁺ + 6e⁻ → 2Cr³⁺ + 7H₂O" },
            { name: "electronsOxidation", label: "Electrons Lost (Oxidation)", unit: "", type: "number", min: 1 },
            { name: "electronsReduction", label: "Electrons Gained (Reduction)", unit: "", type: "number", min: 1 }
          ],
          outputs: ["balancedEquation", "oxidationReaction", "reductionReaction", "electronBalance"],
          validationRules: {
            minimumFields: 2,
            description: "Enter reactants and products or half-reactions to balance redox equation"
          }
        },
        usageCount: 3200,
        isActive: true,
        keywords: ["redox", "balance", "oxidation", "reduction", "electron", "half", "reaction"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "oxidation-numbers",
        title: "Oxidation Numbers Calculator",
        description: "Calculate oxidation states and analyze electron transfer in chemical compounds",
        category: "chemistry",
        subcategory: "electrochemistry",
        icon: "hash",
        formula: "Sum of oxidation numbers = charge of species",
        variables: {
          inputs: [
            { name: "compound", label: "Chemical Compound", unit: "", type: "text", placeholder: "H2SO4, KMnO4", required: true },
            { name: "element", label: "Element of Interest", unit: "", type: "text", placeholder: "S, Mn" },
            { name: "knownOxStates", label: "Known Oxidation States", unit: "", type: "text", placeholder: "H:+1, O:-2" },
            { name: "compoundCharge", label: "Overall Charge", unit: "", type: "number", default: 0 },
            { name: "ionicState", label: "Ionic State", unit: "", type: "select", options: ["neutral", "cation", "anion"], default: "neutral" }
          ],
          outputs: ["oxidationNumbers", "electronConfiguration", "redoxType", "elementAnalysis"],
          validationRules: {
            minimumFields: 1,
            description: "Enter a chemical compound to calculate oxidation numbers"
          }
        },
        usageCount: 4100,
        isActive: true,
        keywords: ["oxidation", "number", "state", "electron", "valence", "compound"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Additional Miscellaneous Chemistry Calculators
      {
        id: "avogadros-number",
        title: "Avogadro's Number Calculator",
        description: "Convert between moles and particles using Avogadro's number (6.022 × 10²³)",
        category: "chemistry",
        subcategory: "miscellaneous",
        icon: "atom",
        formula: "N = n × NA, where N = particles, n = moles, NA = Avogadro's number",
        variables: {
          inputs: [
            { name: "moles", label: "Number of Moles (n)", unit: "mol", type: "number", min: 0 },
            { name: "particles", label: "Number of Particles (N)", unit: "", type: "number", min: 0 },
            { name: "avogadroNumber", label: "Avogadro's Number (NA)", unit: "particles/mol", type: "number", default: 6.022e23, min: 0 },
            { name: "mass", label: "Mass (m)", unit: "g", type: "number", min: 0 },
            { name: "molarMass", label: "Molar Mass (M)", unit: "g/mol", type: "number", min: 0 }
          ],
          outputs: ["particles", "moles", "mass", "atoms"],
          validationRules: {
            minimumFields: 2,
            description: "Enter moles or particles to calculate conversions"
          }
        },
        usageCount: 7800,
        isActive: true,
        keywords: ["avogadro", "number", "moles", "particles", "atoms", "molecules"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "equivalent-weight",
        title: "Equivalent Weight Calculator",
        description: "Calculate equivalent weight, gram equivalents, and normality relationships",
        category: "chemistry",
        subcategory: "miscellaneous",
        icon: "equals",
        formula: "Equivalent Weight = Molecular Weight / n-factor, Equivalents = mass / Eq. Weight",
        variables: {
          inputs: [
            { name: "molecularWeight", label: "Molecular Weight (MW)", unit: "g/mol", type: "number", min: 0 },
            { name: "nFactor", label: "n-Factor", unit: "", type: "number", min: 1, default: 1 },
            { name: "equivalentWeight", label: "Equivalent Weight", unit: "g/eq", type: "number", min: 0 },
            { name: "mass", label: "Mass", unit: "g", type: "number", min: 0 },
            { name: "equivalents", label: "Number of Equivalents", unit: "eq", type: "number", min: 0 },
            { name: "volume", label: "Volume", unit: "L", type: "number", min: 0 },
            { name: "normality", label: "Normality", unit: "eq/L", type: "number", min: 0 }
          ],
          outputs: ["equivalentWeight", "equivalents", "normality", "nFactor"],
          validationRules: {
            minimumFields: 2,
            description: "Enter molecular weight and n-factor, or equivalent weight and mass"
          }
        },
        usageCount: 3900,
        isActive: true,
        keywords: ["equivalent", "weight", "normality", "gram", "equivalents", "acid", "base"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "beer-lambert-law",
        title: "Beer-Lambert Law Calculator",
        description: "Calculate absorbance, concentration, and path length using Beer-Lambert law",
        category: "chemistry",
        subcategory: "miscellaneous",
        icon: "eye",
        formula: "A = ε × c × l, where A = absorbance, ε = molar absorptivity, c = concentration",
        variables: {
          inputs: [
            { name: "absorbance", label: "Absorbance (A)", unit: "", type: "number", min: 0 },
            { name: "concentration", label: "Concentration (c)", unit: "mol/L", type: "number", min: 0 },
            { name: "pathLength", label: "Path Length (l)", unit: "cm", type: "number", min: 0, default: 1 },
            { name: "molarAbsorptivity", label: "Molar Absorptivity (ε)", unit: "L/(mol⋅cm)", type: "number", min: 0 },
            { name: "transmittance", label: "Transmittance (T)", unit: "%", type: "number", min: 0, max: 100 },
            { name: "incidentLight", label: "Incident Light Intensity (I₀)", unit: "", type: "number", min: 0 },
            { name: "transmittedLight", label: "Transmitted Light Intensity (I)", unit: "", type: "number", min: 0 }
          ],
          outputs: ["absorbance", "concentration", "transmittance", "molarAbsorptivity"],
          validationRules: {
            minimumFields: 3,
            description: "Enter absorbance, concentration, path length, or related optical properties"
          }
        },
        usageCount: 4700,
        isActive: true,
        keywords: ["beer", "lambert", "absorbance", "concentration", "spectroscopy", "optical"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "chemical-equilibrium",
        title: "Chemical Equilibrium Calculator",
        description: "Calculate equilibrium constants, reaction quotients, and equilibrium concentrations",
        category: "chemistry",
        subcategory: "miscellaneous",
        icon: "balance-scale",
        formula: "K = [products]^coeffs / [reactants]^coeffs, Q = reaction quotient",
        variables: {
          inputs: [
            { name: "equilibriumConstant", label: "Equilibrium Constant (K)", unit: "", type: "number", min: 0 },
            { name: "reactionQuotient", label: "Reaction Quotient (Q)", unit: "", type: "number", min: 0 },
            { name: "temperature", label: "Temperature (T)", unit: "K", type: "number", min: 0, default: 298.15 },
            { name: "productConc1", label: "Product 1 Concentration", unit: "mol/L", type: "number", min: 0 },
            { name: "productConc2", label: "Product 2 Concentration", unit: "mol/L", type: "number", min: 0 },
            { name: "reactantConc1", label: "Reactant 1 Concentration", unit: "mol/L", type: "number", min: 0 },
            { name: "reactantConc2", label: "Reactant 2 Concentration", unit: "mol/L", type: "number", min: 0 },
            { name: "productCoeff1", label: "Product 1 Coefficient", unit: "", type: "number", min: 1, default: 1 },
            { name: "productCoeff2", label: "Product 2 Coefficient", unit: "", type: "number", min: 1, default: 1 },
            { name: "reactantCoeff1", label: "Reactant 1 Coefficient", unit: "", type: "number", min: 1, default: 1 },
            { name: "reactantCoeff2", label: "Reactant 2 Coefficient", unit: "", type: "number", min: 1, default: 1 }
          ],
          outputs: ["equilibriumConstant", "reactionQuotient", "direction", "equilibriumPosition"],
          validationRules: {
            minimumFields: 4,
            description: "Enter concentrations and coefficients to calculate equilibrium properties"
          }
        },
        usageCount: 5600,
        isActive: true,
        keywords: ["equilibrium", "constant", "reaction", "quotient", "le", "chatelier", "balance"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "molecular-weight-calculator",
        title: "Molecular Weight Calculator",
        description: "Calculate molecular weight, molar mass, and formula mass of chemical compounds",
        category: "chemistry",
        subcategory: "basic-chemistry",
        icon: "atom",
        formula: "Molecular Weight = Σ(atomic mass × number of atoms)",
        variables: {
          inputs: [
            { name: "formula", label: "Chemical Formula", unit: "", type: "text", placeholder: "H2O, NaCl, CaCO3", required: true },
            { name: "elements", label: "Elements (comma separated)", unit: "", type: "text", placeholder: "H, O, Na, Cl" },
            { name: "atomicMasses", label: "Atomic Masses (comma separated)", unit: "amu", type: "text", placeholder: "1.008, 15.999" },
            { name: "atomCounts", label: "Atom Counts (comma separated)", unit: "", type: "text", placeholder: "2, 1" }
          ],
          outputs: ["molecularWeight", "molarMass", "formulaMass", "elementBreakdown"],
          validationRules: {
            minimumFields: 1,
            description: "Enter chemical formula or element data to calculate molecular weight"
          }
        },
        usageCount: 12400,
        isActive: true,
        keywords: ["molecular", "weight", "molar", "mass", "formula", "compound", "atomic"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "molecular-formula-calculator",
        title: "Molecular Formula Calculator",
        description: "Determine molecular formula from empirical formula and molecular weight",
        category: "chemistry",
        subcategory: "basic-chemistry",
        icon: "formula",
        formula: "Molecular Formula = (Empirical Formula)n, where n = Molecular Weight / Empirical Weight",
        variables: {
          inputs: [
            { name: "empiricalFormula", label: "Empirical Formula", unit: "", type: "text", placeholder: "CH2O", required: true },
            { name: "molecularWeight", label: "Molecular Weight", unit: "g/mol", type: "number", min: 0 },
            { name: "empiricalWeight", label: "Empirical Formula Weight", unit: "g/mol", type: "number", min: 0 },
            { name: "multiplier", label: "Multiplier (n)", unit: "", type: "number", min: 1 }
          ],
          outputs: ["molecularFormula", "multiplier", "empiricalWeight", "molecularWeight"],
          validationRules: {
            minimumFields: 2,
            description: "Enter empirical formula and molecular weight to find molecular formula"
          }
        },
        usageCount: 4900,
        isActive: true,
        keywords: ["molecular", "formula", "empirical", "weight", "multiplier", "compound"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "dilution-calculator",
        title: "Dilution Calculator",
        description: "Calculate dilution ratios, final concentrations, and volumes using C₁V₁ = C₂V₂",
        category: "chemistry",
        subcategory: "basic-chemistry",
        icon: "beaker",
        formula: "C₁V₁ = C₂V₂, where C = concentration, V = volume",
        variables: {
          inputs: [
            { name: "initialConcentration", label: "Initial Concentration (C₁)", unit: "mol/L", type: "number", min: 0 },
            { name: "initialVolume", label: "Initial Volume (V₁)", unit: "L", type: "number", min: 0 },
            { name: "finalConcentration", label: "Final Concentration (C₂)", unit: "mol/L", type: "number", min: 0 },
            { name: "finalVolume", label: "Final Volume (V₂)", unit: "L", type: "number", min: 0 },
            { name: "dilutionFactor", label: "Dilution Factor", unit: "", type: "number", min: 1 },
            { name: "volumeToAdd", label: "Volume to Add", unit: "L", type: "number", min: 0 }
          ],
          outputs: ["finalConcentration", "finalVolume", "dilutionFactor", "volumeToAdd"],
          validationRules: {
            minimumFields: 3,
            description: "Enter any 3 values to calculate dilution parameters using C₁V₁ = C₂V₂"
          }
        },
        usageCount: 8700,
        isActive: true,
        keywords: ["dilution", "concentration", "volume", "c1v1", "c2v2", "ratio", "solution"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "percent-purity-calculator",
        title: "Percent Purity Calculator",
        description: "Calculate percent purity of chemical samples and determine actual vs theoretical amounts",
        category: "chemistry",
        subcategory: "miscellaneous",
        icon: "check-circle",
        formula: "% Purity = (Actual Amount / Theoretical Amount) × 100",
        variables: {
          inputs: [
            { name: "actualAmount", label: "Actual Amount", unit: "g", type: "number", min: 0 },
            { name: "theoreticalAmount", label: "Theoretical Amount", unit: "g", type: "number", min: 0 },
            { name: "percentPurity", label: "Percent Purity", unit: "%", type: "number", min: 0, max: 100 },
            { name: "sampleMass", label: "Sample Mass", unit: "g", type: "number", min: 0 },
            { name: "pureMass", label: "Pure Substance Mass", unit: "g", type: "number", min: 0 },
            { name: "impurityMass", label: "Impurity Mass", unit: "g", type: "number", min: 0 }
          ],
          outputs: ["percentPurity", "actualAmount", "theoreticalAmount", "impurityPercent"],
          validationRules: {
            minimumFields: 2,
            description: "Enter actual and theoretical amounts, or sample and pure substance masses"
          }
        },
        usageCount: 3800,
        isActive: true,
        keywords: ["purity", "percent", "actual", "theoretical", "sample", "impurity", "analysis"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "concentration-ppm-ppb",
        title: "Concentration ppm/ppb Calculator",
        description: "Calculate concentrations in parts per million (ppm), parts per billion (ppb), and convert between units",
        category: "chemistry",
        subcategory: "miscellaneous",
        icon: "droplets",
        formula: "ppm = (mass solute / total mass) × 10⁶, ppb = (mass solute / total mass) × 10⁹",
        variables: {
          inputs: [
            { name: "ppm", label: "Concentration (ppm)", unit: "ppm", type: "number", min: 0 },
            { name: "ppb", label: "Concentration (ppb)", unit: "ppb", type: "number", min: 0 },
            { name: "massPercent", label: "Mass Percent (%)", unit: "%", type: "number", min: 0, max: 100 },
            { name: "massSolute", label: "Mass of Solute", unit: "mg", type: "number", min: 0 },
            { name: "totalMass", label: "Total Mass of Solution", unit: "kg", type: "number", min: 0 },
            { name: "molarity", label: "Molarity", unit: "mol/L", type: "number", min: 0 },
            { name: "molecularWeight", label: "Molecular Weight", unit: "g/mol", type: "number", min: 0 },
            { name: "density", label: "Solution Density", unit: "g/mL", type: "number", min: 0, default: 1.0 }
          ],
          outputs: ["ppm", "ppb", "massPercent", "molarity", "massSolute"],
          validationRules: {
            minimumFields: 2,
            description: "Enter concentration in any unit to convert to ppm/ppb"
          }
        },
        usageCount: 5200,
        isActive: true,
        keywords: ["ppm", "ppb", "parts per million", "parts per billion", "concentration", "trace", "analysis"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Math Calculators

      // Arithmetic & Algebra Subcategory
      {
        id: "basic-arithmetic",
        title: "Basic Arithmetic Calculator",
        description: "Perform basic arithmetic operations with step-by-step solutions",
        category: "math",
        subcategory: "arithmetic-algebra",
        icon: "calculator",
        formula: "a + b, a - b, a × b, a ÷ b",
        variables: {
          inputs: [
            { name: "number1", label: "First Number (a)", unit: "", type: "number", required: true },
            { name: "number2", label: "Second Number (b)", unit: "", type: "number", required: true },
            { name: "operation", label: "Operation", unit: "", type: "select", required: true, options: ["addition", "subtraction", "multiplication", "division"] }
          ],
          outputs: ["result", "steps", "decimalForm", "fractionForm"],
          validationRules: {
            minimumFields: 3,
            description: "Enter two numbers and select an operation"
          }
        },
        usageCount: 45600,
        isActive: true,
        keywords: ["arithmetic", "addition", "subtraction", "multiplication", "division", "basic", "math"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "percentage-calculator",
        title: "Percentage Calculator",
        description: "Calculate percentages, percentage change, and percentage of numbers",
        category: "math",
        subcategory: "arithmetic-algebra",
        icon: "percent",
        formula: "% = (part/whole) × 100, change% = ((new-old)/old) × 100",
        variables: {
          inputs: [
            { name: "number", label: "Number", unit: "", type: "number" },
            { name: "percentage", label: "Percentage (%)", unit: "%", type: "number" },
            { name: "whole", label: "Whole/Total", unit: "", type: "number" },
            { name: "part", label: "Part", unit: "", type: "number" },
            { name: "oldValue", label: "Old Value", unit: "", type: "number" },
            { name: "newValue", label: "New Value", unit: "", type: "number" }
          ],
          outputs: ["percentageOfNumber", "numberFromPercentage", "percentageChange", "wholeFromPart"],
          validationRules: {
            minimumFields: 2,
            description: "Enter values to calculate percentages"
          }
        },
        usageCount: 38900,
        isActive: true,
        keywords: ["percentage", "percent", "change", "increase", "decrease", "proportion"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "ratio-proportion",
        title: "Ratio & Proportion Calculator",
        description: "Solve ratios, proportions, and find missing values in proportional relationships",
        category: "math",
        subcategory: "arithmetic-algebra",
        icon: "scale",
        formula: "a:b = c:d, a/b = c/d",
        variables: {
          inputs: [
            { name: "a", label: "First term (a)", unit: "", type: "number" },
            { name: "b", label: "Second term (b)", unit: "", type: "number" },
            { name: "c", label: "Third term (c)", unit: "", type: "number" },
            { name: "d", label: "Fourth term (d)", unit: "", type: "number" }
          ],
          outputs: ["missingValue", "simplifiedRatio", "decimal", "percentage"],
          validationRules: {
            minimumFields: 3,
            description: "Enter at least 3 values to solve proportion"
          }
        },
        usageCount: 24700,
        isActive: true,
        keywords: ["ratio", "proportion", "scale", "equivalent", "missing", "cross multiply"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "average-calculator",
        title: "Average Calculator (Mean, Median, Mode)",
        description: "Calculate mean, median, mode, and other statistical measures",
        category: "math",
        subcategory: "arithmetic-algebra",
        icon: "trending-up",
        formula: "Mean = Σx/n, Median = middle value, Mode = most frequent",
        variables: {
          inputs: [
            { name: "numbers", label: "Numbers (comma separated)", unit: "", type: "text", required: true, placeholder: "e.g. 1, 2, 3, 4, 5" }
          ],
          outputs: ["mean", "median", "mode", "range", "count", "sum"],
          validationRules: {
            minimumFields: 1,
            description: "Enter a list of numbers separated by commas"
          }
        },
        usageCount: 32100,
        isActive: true,
        keywords: ["average", "mean", "median", "mode", "statistics", "central tendency"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "factorial-calculator",
        title: "Factorial Calculator",
        description: "Calculate factorials and gamma function for large numbers",
        category: "math",
        subcategory: "arithmetic-algebra",
        icon: "hash",
        formula: "n! = n × (n-1) × (n-2) × ... × 1",
        variables: {
          inputs: [
            { name: "number", label: "Number (n)", unit: "", type: "number", required: true, min: 0, max: 170 }
          ],
          outputs: ["factorial", "steps", "scientificNotation", "approximation"],
          validationRules: {
            minimumFields: 1,
            description: "Enter a non-negative integer (0 ≤ n ≤ 170)"
          }
        },
        usageCount: 18900,
        isActive: true,
        keywords: ["factorial", "permutation", "gamma", "combinatorics", "stirling"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "exponent-logarithm",
        title: "Exponent & Logarithm Calculator",
        description: "Calculate powers, roots, logarithms, and exponential functions",
        category: "math",
        subcategory: "arithmetic-algebra",
        icon: "superscript",
        formula: "aᵇ, log_a(b), ln(x), eˣ",
        variables: {
          inputs: [
            { name: "base", label: "Base (a)", unit: "", type: "number" },
            { name: "exponent", label: "Exponent (b)", unit: "", type: "number" },
            { name: "number", label: "Number (x)", unit: "", type: "number", min: 0 },
            { name: "logBase", label: "Logarithm Base", unit: "", type: "number", min: 0, default: 10 }
          ],
          outputs: ["power", "logarithm", "naturalLog", "exponential"],
          validationRules: {
            minimumFields: 1,
            description: "Enter values to calculate powers or logarithms"
          }
        },
        usageCount: 27400,
        isActive: true,
        keywords: ["exponent", "power", "logarithm", "log", "ln", "exponential", "base"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "roots-powers",
        title: "Roots & Powers Calculator",
        description: "Calculate square roots, cube roots, nth roots, and powers",
        category: "math",
        subcategory: "arithmetic-algebra",
        icon: "square-root",
        formula: "√x, ∛x, ⁿ√x, x^n",
        variables: {
          inputs: [
            { name: "number", label: "Number (x)", unit: "", type: "number", required: true },
            { name: "rootIndex", label: "Root Index (n)", unit: "", type: "number", min: 1, default: 2 },
            { name: "power", label: "Power (n)", unit: "", type: "number" }
          ],
          outputs: ["squareRoot", "cubeRoot", "nthRoot", "powerResult"],
          validationRules: {
            minimumFields: 1,
            description: "Enter a number to calculate roots and powers"
          }
        },
        usageCount: 21800,
        isActive: true,
        keywords: ["root", "square root", "cube root", "nth root", "power", "radical"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "quadratic-solver",
        title: "Quadratic Equation Solver",
        description: "Solve quadratic equations ax² + bx + c = 0 with detailed solutions",
        category: "math",
        subcategory: "arithmetic-algebra",
        icon: "formula",
        formula: "x = (-b ± √(b² - 4ac)) / 2a",
        variables: {
          inputs: [
            { name: "a", label: "Coefficient a", unit: "", type: "number", required: true },
            { name: "b", label: "Coefficient b", unit: "", type: "number", required: true },
            { name: "c", label: "Coefficient c", unit: "", type: "number", required: true }
          ],
          outputs: ["root1", "root2", "discriminant", "vertex", "axis", "nature"],
          validationRules: {
            minimumFields: 3,
            description: "Enter coefficients a, b, and c (a ≠ 0)"
          }
        },
        usageCount: 35600,
        isActive: true,
        keywords: ["quadratic", "equation", "roots", "discriminant", "vertex", "parabola"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "polynomial-solver",
        title: "Polynomial Equation Solver",
        description: "Solve polynomial equations and find roots with factoring",
        category: "math",
        subcategory: "arithmetic-algebra",
        icon: "function-square",
        formula: "aₙxⁿ + aₙ₋₁xⁿ⁻¹ + ... + a₁x + a₀ = 0",
        variables: {
          inputs: [
            { name: "coefficients", label: "Coefficients (comma separated)", unit: "", type: "text", required: true, placeholder: "e.g. 1,-3,2 for x²-3x+2" },
            { name: "degree", label: "Degree", unit: "", type: "number", min: 1, max: 6 }
          ],
          outputs: ["roots", "factored", "derivative", "criticalPoints"],
          validationRules: {
            minimumFields: 1,
            description: "Enter polynomial coefficients from highest to lowest degree"
          }
        },
        usageCount: 16700,
        isActive: true,
        keywords: ["polynomial", "roots", "factoring", "cubic", "quartic", "equation"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "linear-system-solver",
        title: "Linear Equation System Solver",
        description: "Solve systems of linear equations using various methods",
        category: "math",
        subcategory: "arithmetic-algebra",
        icon: "grid-3x3",
        formula: "Ax = b, Gaussian elimination, Cramer's rule",
        variables: {
          inputs: [
            { name: "systemSize", label: "System Size", unit: "", type: "select", required: true, options: ["2x2", "3x3"] },
            { name: "a11", label: "a₁₁", unit: "", type: "number" },
            { name: "a12", label: "a₁₂", unit: "", type: "number" },
            { name: "a13", label: "a₁₃", unit: "", type: "number" },
            { name: "a21", label: "a₂₁", unit: "", type: "number" },
            { name: "a22", label: "a₂₂", unit: "", type: "number" },
            { name: "a23", label: "a₂₃", unit: "", type: "number" },
            { name: "a31", label: "a₃₁", unit: "", type: "number" },
            { name: "a32", label: "a₃₂", unit: "", type: "number" },
            { name: "a33", label: "a₃₃", unit: "", type: "number" },
            { name: "b1", label: "b₁", unit: "", type: "number" },
            { name: "b2", label: "b₂", unit: "", type: "number" },
            { name: "b3", label: "b₃", unit: "", type: "number" }
          ],
          outputs: ["solution", "determinant", "steps", "nature"],
          validationRules: {
            minimumFields: 6,
            description: "Enter coefficients for the system of equations"
          }
        },
        usageCount: 19200,
        isActive: true,
        keywords: ["linear", "system", "equations", "gaussian", "cramer", "matrix", "elimination"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Geometry & Trigonometry Subcategory
      {
        id: "distance-calculator",
        title: "Distance Between Points Calculator",
        description: "Calculate distance between two points in 2D or 3D space",
        category: "math",
        subcategory: "geometry-trigonometry",
        icon: "ruler",
        formula: "d = √[(x₂-x₁)² + (y₂-y₁)² + (z₂-z₁)²]",
        variables: {
          inputs: [
            { name: "x1", label: "Point 1 X-coordinate", unit: "", type: "number", required: true },
            { name: "y1", label: "Point 1 Y-coordinate", unit: "", type: "number", required: true },
            { name: "z1", label: "Point 1 Z-coordinate", unit: "", type: "number", placeholder: "Leave empty for 2D" },
            { name: "x2", label: "Point 2 X-coordinate", unit: "", type: "number", required: true },
            { name: "y2", label: "Point 2 Y-coordinate", unit: "", type: "number", required: true },
            { name: "z2", label: "Point 2 Z-coordinate", unit: "", type: "number", placeholder: "Leave empty for 2D" }
          ],
          outputs: ["distance", "steps", "midpoint", "direction"],
          validationRules: {
            minimumFields: 4,
            description: "Enter coordinates for both points"
          }
        },
        usageCount: 28400,
        isActive: true,
        keywords: ["distance", "points", "coordinates", "2d", "3d", "euclidean"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "midpoint-slope",
        title: "Midpoint & Slope Calculator",
        description: "Calculate midpoint, slope, and equation of line between two points",
        category: "math",
        subcategory: "geometry-trigonometry",
        icon: "trending-up",
        formula: "Midpoint = ((x₁+x₂)/2, (y₁+y₂)/2), Slope = (y₂-y₁)/(x₂-x₁)",
        variables: {
          inputs: [
            { name: "x1", label: "Point 1 X-coordinate", unit: "", type: "number", required: true },
            { name: "y1", label: "Point 1 Y-coordinate", unit: "", type: "number", required: true },
            { name: "x2", label: "Point 2 X-coordinate", unit: "", type: "number", required: true },
            { name: "y2", label: "Point 2 Y-coordinate", unit: "", type: "number", required: true }
          ],
          outputs: ["midpoint", "slope", "lineEquation", "angle", "intercepts"],
          validationRules: {
            minimumFields: 4,
            description: "Enter coordinates for both points"
          }
        },
        usageCount: 31200,
        isActive: true,
        keywords: ["midpoint", "slope", "line", "equation", "gradient", "linear"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "area-calculator",
        title: "Area Calculator (Multiple Shapes)",
        description: "Calculate area for triangles, rectangles, circles, polygons, and more",
        category: "math",
        subcategory: "geometry-trigonometry",
        icon: "square",
        formula: "Circle: πr², Triangle: ½bh, Rectangle: lw, Polygon: varies",
        variables: {
          inputs: [
            { name: "shape", label: "Shape Type", unit: "", type: "select", required: true, options: ["circle", "triangle", "rectangle", "square", "trapezoid", "parallelogram", "rhombus", "ellipse"] },
            { name: "radius", label: "Radius (r)", unit: "units", type: "number", min: 0 },
            { name: "base", label: "Base (b)", unit: "units", type: "number", min: 0 },
            { name: "height", label: "Height (h)", unit: "units", type: "number", min: 0 },
            { name: "length", label: "Length (l)", unit: "units", type: "number", min: 0 },
            { name: "width", label: "Width (w)", unit: "units", type: "number", min: 0 },
            { name: "side", label: "Side length", unit: "units", type: "number", min: 0 },
            { name: "semiMajor", label: "Semi-major axis (a)", unit: "units", type: "number", min: 0 },
            { name: "semiMinor", label: "Semi-minor axis (b)", unit: "units", type: "number", min: 0 }
          ],
          outputs: ["area", "perimeter", "formula", "steps"],
          validationRules: {
            minimumFields: 2,
            description: "Select shape and enter required dimensions"
          }
        },
        usageCount: 42800,
        isActive: true,
        keywords: ["area", "geometry", "circle", "triangle", "rectangle", "polygon", "shape"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "volume-calculator",
        title: "Volume Calculator (3D Shapes)",
        description: "Calculate volume for spheres, cubes, cylinders, cones, prisms, and pyramids",
        category: "math",
        subcategory: "geometry-trigonometry",
        icon: "cube",
        formula: "Sphere: (4/3)πr³, Cylinder: πr²h, Cone: (1/3)πr²h",
        variables: {
          inputs: [
            { name: "shape", label: "3D Shape Type", unit: "", type: "select", required: true, options: ["sphere", "cube", "cylinder", "cone", "rectangular_prism", "triangular_prism", "pyramid", "ellipsoid"] },
            { name: "radius", label: "Radius (r)", unit: "units", type: "number", min: 0 },
            { name: "height", label: "Height (h)", unit: "units", type: "number", min: 0 },
            { name: "length", label: "Length (l)", unit: "units", type: "number", min: 0 },
            { name: "width", label: "Width (w)", unit: "units", type: "number", min: 0 },
            { name: "side", label: "Side length", unit: "units", type: "number", min: 0 },
            { name: "baseArea", label: "Base Area", unit: "units²", type: "number", min: 0 }
          ],
          outputs: ["volume", "surfaceArea", "formula", "steps"],
          validationRules: {
            minimumFields: 2,
            description: "Select 3D shape and enter required dimensions"
          }
        },
        usageCount: 36500,
        isActive: true,
        keywords: ["volume", "3d", "sphere", "cylinder", "cone", "cube", "prism", "pyramid"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "trigonometric-functions",
        title: "Trigonometric Functions Calculator",
        description: "Calculate sin, cos, tan, and inverse trigonometric functions",
        category: "math",
        subcategory: "geometry-trigonometry",
        icon: "activity",
        formula: "sin(θ), cos(θ), tan(θ), sin⁻¹(x), cos⁻¹(x), tan⁻¹(x)",
        variables: {
          inputs: [
            { name: "angle", label: "Angle", unit: "", type: "number" },
            { name: "angleUnit", label: "Angle Unit", unit: "", type: "select", options: ["degrees", "radians"], default: "degrees" },
            { name: "value", label: "Function Value", unit: "", type: "number", min: -1, max: 1 },
            { name: "function", label: "Function Type", unit: "", type: "select", options: ["sin", "cos", "tan", "csc", "sec", "cot"], default: "sin" }
          ],
          outputs: ["sinValue", "cosValue", "tanValue", "inverseValue", "allFunctions", "unitCircle"],
          validationRules: {
            minimumFields: 1,
            description: "Enter angle or function value to calculate trigonometric functions"
          }
        },
        usageCount: 39600,
        isActive: true,
        keywords: ["trigonometry", "sin", "cos", "tan", "inverse", "trig", "angle"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "law-of-sines",
        title: "Law of Sines Calculator",
        description: "Solve triangles using the Law of Sines (a/sin(A) = b/sin(B) = c/sin(C))",
        category: "math",
        subcategory: "geometry-trigonometry",
        icon: "triangle",
        formula: "a/sin(A) = b/sin(B) = c/sin(C)",
        variables: {
          inputs: [
            { name: "sideA", label: "Side a", unit: "units", type: "number", min: 0 },
            { name: "sideB", label: "Side b", unit: "units", type: "number", min: 0 },
            { name: "sideC", label: "Side c", unit: "units", type: "number", min: 0 },
            { name: "angleA", label: "Angle A", unit: "degrees", type: "number", min: 0, max: 180 },
            { name: "angleB", label: "Angle B", unit: "degrees", type: "number", min: 0, max: 180 },
            { name: "angleC", label: "Angle C", unit: "degrees", type: "number", min: 0, max: 180 }
          ],
          outputs: ["missingSides", "missingAngles", "area", "perimeter", "triangleType"],
          validationRules: {
            minimumFields: 3,
            description: "Enter at least 3 known values (with at least one side)"
          }
        },
        usageCount: 22400,
        isActive: true,
        keywords: ["law of sines", "triangle", "solve", "trigonometry", "sides", "angles"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "law-of-cosines",
        title: "Law of Cosines Calculator",
        description: "Solve triangles using the Law of Cosines (c² = a² + b² - 2ab·cos(C))",
        category: "math",
        subcategory: "geometry-trigonometry",
        icon: "triangle",
        formula: "c² = a² + b² - 2ab·cos(C)",
        variables: {
          inputs: [
            { name: "sideA", label: "Side a", unit: "units", type: "number", min: 0 },
            { name: "sideB", label: "Side b", unit: "units", type: "number", min: 0 },
            { name: "sideC", label: "Side c", unit: "units", type: "number", min: 0 },
            { name: "angleA", label: "Angle A", unit: "degrees", type: "number", min: 0, max: 180 },
            { name: "angleB", label: "Angle B", unit: "degrees", type: "number", min: 0, max: 180 },
            { name: "angleC", label: "Angle C", unit: "degrees", type: "number", min: 0, max: 180 }
          ],
          outputs: ["missingSide", "missingAngles", "area", "perimeter", "triangleType"],
          validationRules: {
            minimumFields: 3,
            description: "Enter 3 known values to solve the triangle"
          }
        },
        usageCount: 19800,
        isActive: true,
        keywords: ["law of cosines", "triangle", "solve", "trigonometry", "cosine rule"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "vector-angle",
        title: "Angle Between Vectors Calculator",
        description: "Calculate the angle between two vectors in 2D or 3D space",
        category: "math",
        subcategory: "geometry-trigonometry",
        icon: "navigation",
        formula: "θ = cos⁻¹[(u·v)/(|u||v|)]",
        variables: {
          inputs: [
            { name: "u1", label: "Vector u - x component", unit: "", type: "number", required: true },
            { name: "u2", label: "Vector u - y component", unit: "", type: "number", required: true },
            { name: "u3", label: "Vector u - z component", unit: "", type: "number", placeholder: "Leave empty for 2D" },
            { name: "v1", label: "Vector v - x component", unit: "", type: "number", required: true },
            { name: "v2", label: "Vector v - y component", unit: "", type: "number", required: true },
            { name: "v3", label: "Vector v - z component", unit: "", type: "number", placeholder: "Leave empty for 2D" }
          ],
          outputs: ["angle", "dotProduct", "magnitudes", "unitVectors", "parallel"],
          validationRules: {
            minimumFields: 4,
            description: "Enter components for both vectors"
          }
        },
        usageCount: 15600,
        isActive: true,
        keywords: ["vector", "angle", "dot product", "magnitude", "3d", "2d"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "polar-cartesian",
        title: "Polar ↔ Cartesian Converter",
        description: "Convert between polar coordinates (r, θ) and Cartesian coordinates (x, y)",
        category: "math",
        subcategory: "geometry-trigonometry",
        icon: "compass",
        formula: "x = r·cos(θ), y = r·sin(θ), r = √(x²+y²), θ = tan⁻¹(y/x)",
        variables: {
          inputs: [
            { name: "x", label: "Cartesian X-coordinate", unit: "", type: "number" },
            { name: "y", label: "Cartesian Y-coordinate", unit: "", type: "number" },
            { name: "r", label: "Polar Radius (r)", unit: "", type: "number", min: 0 },
            { name: "theta", label: "Polar Angle (θ)", unit: "degrees", type: "number" },
            { name: "angleUnit", label: "Angle Unit", unit: "", type: "select", options: ["degrees", "radians"], default: "degrees" }
          ],
          outputs: ["cartesian", "polar", "steps", "quadrant"],
          validationRules: {
            minimumFields: 2,
            description: "Enter either Cartesian (x,y) or Polar (r,θ) coordinates"
          }
        },
        usageCount: 18900,
        isActive: true,
        keywords: ["polar", "cartesian", "coordinates", "convert", "radius", "angle"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Advanced Algebra Subcategory
      {
        id: "matrix-determinant",
        title: "Matrix Determinant Calculator",
        description: "Calculate determinant of 2x2, 3x3, and larger matrices with step-by-step solutions",
        category: "math",
        subcategory: "advanced-algebra",
        icon: "grid",
        formula: "det(A) = ad - bc (2x2), Cofactor expansion (3x3+)",
        variables: {
          inputs: [
            { name: "matrixSize", label: "Matrix Size", unit: "", type: "select", required: true, options: ["2x2", "3x3"] },
            { name: "a11", label: "a₁₁", unit: "", type: "number", required: true },
            { name: "a12", label: "a₁₂", unit: "", type: "number", required: true },
            { name: "a21", label: "a₂₁", unit: "", type: "number", required: true },
            { name: "a22", label: "a₂₂", unit: "", type: "number", required: true },
            { name: "a13", label: "a₁₃", unit: "", type: "number" },
            { name: "a23", label: "a₂₃", unit: "", type: "number" },
            { name: "a31", label: "a₃₁", unit: "", type: "number" },
            { name: "a32", label: "a₃₂", unit: "", type: "number" },
            { name: "a33", label: "a₃₃", unit: "", type: "number" }
          ],
          outputs: ["determinant", "steps", "minors", "cofactors"],
          validationRules: {
            minimumFields: 5,
            description: "Enter matrix elements based on selected size"
          }
        },
        usageCount: 16800,
        isActive: true,
        keywords: ["matrix", "determinant", "linear algebra", "cofactor", "expansion"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "matrix-inverse",
        title: "Matrix Inverse Calculator",
        description: "Calculate matrix inverse using Gauss-Jordan elimination and adjugate method",
        category: "math",
        subcategory: "advanced-algebra",
        icon: "refresh-cw",
        formula: "A⁻¹ = (1/det(A)) × adj(A), Gauss-Jordan method",
        variables: {
          inputs: [
            { name: "matrixSize", label: "Matrix Size", unit: "", type: "select", required: true, options: ["2x2", "3x3"] },
            { name: "a11", label: "a₁₁", unit: "", type: "number", required: true },
            { name: "a12", label: "a₁₂", unit: "", type: "number", required: true },
            { name: "a21", label: "a₂₁", unit: "", type: "number", required: true },
            { name: "a22", label: "a₂₂", unit: "", type: "number", required: true },
            { name: "a13", label: "a₁₃", unit: "", type: "number" },
            { name: "a23", label: "a₂₃", unit: "", type: "number" },
            { name: "a31", label: "a₃₁", unit: "", type: "number" },
            { name: "a32", label: "a₃₂", unit: "", type: "number" },
            { name: "a33", label: "a₃₃", unit: "", type: "number" }
          ],
          outputs: ["inverse", "determinant", "adjugate", "steps", "isInvertible"],
          validationRules: {
            minimumFields: 5,
            description: "Enter matrix elements (determinant must be non-zero)"
          }
        },
        usageCount: 14200,
        isActive: true,
        keywords: ["matrix", "inverse", "adjugate", "gauss jordan", "linear algebra"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "eigenvalues-eigenvectors",
        title: "Eigenvalues & Eigenvectors Calculator",
        description: "Find eigenvalues and eigenvectors for 2x2 and 3x3 matrices",
        category: "math",
        subcategory: "advanced-algebra",
        icon: "trending-up",
        formula: "det(A - λI) = 0, (A - λI)v = 0",
        variables: {
          inputs: [
            { name: "matrixSize", label: "Matrix Size", unit: "", type: "select", required: true, options: ["2x2", "3x3"] },
            { name: "a11", label: "a₁₁", unit: "", type: "number", required: true },
            { name: "a12", label: "a₁₂", unit: "", type: "number", required: true },
            { name: "a21", label: "a₂₁", unit: "", type: "number", required: true },
            { name: "a22", label: "a₂₂", unit: "", type: "number", required: true },
            { name: "a13", label: "a₁₃", unit: "", type: "number" },
            { name: "a23", label: "a₂₃", unit: "", type: "number" },
            { name: "a31", label: "a₃₁", unit: "", type: "number" },
            { name: "a32", label: "a₃₂", unit: "", type: "number" },
            { name: "a33", label: "a₃₃", unit: "", type: "number" }
          ],
          outputs: ["eigenvalues", "eigenvectors", "characteristicPolynomial", "steps"],
          validationRules: {
            minimumFields: 5,
            description: "Enter matrix elements to find eigenvalues and eigenvectors"
          }
        },
        usageCount: 12500,
        isActive: true,
        keywords: ["eigenvalue", "eigenvector", "characteristic", "polynomial", "linear algebra"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "vector-operations",
        title: "Vector Operations Calculator",
        description: "Calculate vector magnitude, dot product, cross product, and unit vectors",
        category: "math",
        subcategory: "advanced-algebra",
        icon: "move",
        formula: "|v| = √(x²+y²+z²), u·v = uxvx+uyvy+uzvz, u×v = det([i,j,k],[ux,uy,uz],[vx,vy,vz])",
        variables: {
          inputs: [
            { name: "dimensionality", label: "Vector Dimension", unit: "", type: "select", required: true, options: ["2D", "3D"] },
            { name: "u1", label: "Vector u - x component", unit: "", type: "number", required: true },
            { name: "u2", label: "Vector u - y component", unit: "", type: "number", required: true },
            { name: "u3", label: "Vector u - z component", unit: "", type: "number" },
            { name: "v1", label: "Vector v - x component", unit: "", type: "number" },
            { name: "v2", label: "Vector v - y component", unit: "", type: "number" },
            { name: "v3", label: "Vector v - z component", unit: "", type: "number" }
          ],
          outputs: ["magnitude", "dotProduct", "crossProduct", "unitVector", "angle", "projection"],
          validationRules: {
            minimumFields: 3,
            description: "Enter vector components for calculations"
          }
        },
        usageCount: 18900,
        isActive: true,
        keywords: ["vector", "dot product", "cross product", "magnitude", "unit vector", "projection"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "complex-numbers",
        title: "Complex Numbers Calculator",
        description: "Perform operations with complex numbers including arithmetic, polar form, and roots",
        category: "math",
        subcategory: "advanced-algebra",
        icon: "compass",
        formula: "z = a + bi, |z| = √(a²+b²), arg(z) = tan⁻¹(b/a)",
        variables: {
          inputs: [
            { name: "a1", label: "First Complex - Real part (a)", unit: "", type: "number" },
            { name: "b1", label: "First Complex - Imaginary part (b)", unit: "", type: "number" },
            { name: "a2", label: "Second Complex - Real part (c)", unit: "", type: "number" },
            { name: "b2", label: "Second Complex - Imaginary part (d)", unit: "", type: "number" },
            { name: "operation", label: "Operation", unit: "", type: "select", options: ["addition", "subtraction", "multiplication", "division", "conjugate", "modulus", "argument", "polar"] },
            { name: "power", label: "Power (for exponentiation)", unit: "", type: "number" },
            { name: "root", label: "Root (for nth root)", unit: "", type: "number", min: 1 }
          ],
          outputs: ["result", "polarForm", "modulus", "argument", "conjugate", "steps"],
          validationRules: {
            minimumFields: 3,
            description: "Enter complex number(s) and select operation"
          }
        },
        usageCount: 11400,
        isActive: true,
        keywords: ["complex", "imaginary", "polar", "modulus", "argument", "conjugate"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Statistics & Probability Subcategory
      {
        id: "probability-calculator",
        title: "Probability Calculator",
        description: "Calculate basic probability, conditional probability, and Bayes' theorem",
        category: "math",
        subcategory: "statistics-probability",
        icon: "dice-1",
        formula: "P(A) = favorable/total, P(A|B) = P(A∩B)/P(B), Bayes: P(A|B) = P(B|A)P(A)/P(B)",
        variables: {
          inputs: [
            { name: "favorableOutcomes", label: "Favorable Outcomes", unit: "", type: "number", min: 0 },
            { name: "totalOutcomes", label: "Total Outcomes", unit: "", type: "number", min: 1 },
            { name: "eventA", label: "P(A)", unit: "", type: "number", min: 0, max: 1 },
            { name: "eventB", label: "P(B)", unit: "", type: "number", min: 0, max: 1 },
            { name: "eventAandB", label: "P(A∩B)", unit: "", type: "number", min: 0, max: 1 },
            { name: "eventBgivenA", label: "P(B|A)", unit: "", type: "number", min: 0, max: 1 }
          ],
          outputs: ["basicProbability", "conditionalProbability", "bayesTheorem", "complement", "union", "intersection"],
          validationRules: {
            minimumFields: 2,
            description: "Enter values for probability calculations"
          }
        },
        usageCount: 25600,
        isActive: true,
        keywords: ["probability", "bayes", "conditional", "complement", "union", "intersection"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "permutations-combinations",
        title: "Permutations & Combinations Calculator",
        description: "Calculate permutations P(n,r) and combinations C(n,r) with factorials",
        category: "math",
        subcategory: "statistics-probability",
        icon: "shuffle",
        formula: "P(n,r) = n!/(n-r)!, C(n,r) = n!/(r!(n-r)!)",
        variables: {
          inputs: [
            { name: "n", label: "Total items (n)", unit: "", type: "number", required: true, min: 0, max: 170 },
            { name: "r", label: "Items selected (r)", unit: "", type: "number", required: true, min: 0 },
            { name: "calculationType", label: "Calculation Type", unit: "", type: "select", required: true, options: ["permutation", "combination", "both"] }
          ],
          outputs: ["permutation", "combination", "steps", "factorials"],
          validationRules: {
            minimumFields: 3,
            description: "Enter n and r values (r ≤ n)"
          }
        },
        usageCount: 33400,
        isActive: true,
        keywords: ["permutation", "combination", "factorial", "arrangement", "selection"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "z-score-calculator",
        title: "Z-Score Calculator",
        description: "Calculate z-scores, percentiles, and normal distribution probabilities",
        category: "math",
        subcategory: "statistics-probability",
        icon: "bar-chart",
        formula: "z = (x - μ)/σ, P(Z ≤ z) = Φ(z)",
        variables: {
          inputs: [
            { name: "value", label: "Data Value (x)", unit: "", type: "number" },
            { name: "mean", label: "Population Mean (μ)", unit: "", type: "number" },
            { name: "standardDeviation", label: "Standard Deviation (σ)", unit: "", type: "number", min: 0 },
            { name: "zScore", label: "Z-Score (z)", unit: "", type: "number" },
            { name: "probability", label: "Probability (p)", unit: "", type: "number", min: 0, max: 1 }
          ],
          outputs: ["zScore", "probability", "percentile", "value", "standardScore"],
          validationRules: {
            minimumFields: 3,
            description: "Enter value, mean, and standard deviation, or z-score"
          }
        },
        usageCount: 29800,
        isActive: true,
        keywords: ["z score", "normal distribution", "percentile", "standard score", "probability"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "t-test-calculator",
        title: "t-Test Calculator",
        description: "Perform one-sample, two-sample, and paired t-tests with confidence intervals",
        category: "math",
        subcategory: "statistics-probability",
        icon: "trending-up",
        formula: "t = (x̄ - μ)/(s/√n), df = n-1 (one-sample)",
        variables: {
          inputs: [
            { name: "testType", label: "Test Type", unit: "", type: "select", required: true, options: ["one-sample", "two-sample", "paired"] },
            { name: "sampleMean", label: "Sample Mean (x̄)", unit: "", type: "number" },
            { name: "populationMean", label: "Population Mean (μ)", unit: "", type: "number" },
            { name: "sampleStd", label: "Sample Standard Deviation (s)", unit: "", type: "number", min: 0 },
            { name: "sampleSize", label: "Sample Size (n)", unit: "", type: "number", min: 1 },
            { name: "significanceLevel", label: "Significance Level (α)", unit: "", type: "number", min: 0, max: 1, default: 0.05 },
            { name: "dataset", label: "Sample Data (comma separated)", unit: "", type: "text", placeholder: "e.g. 1, 2, 3, 4, 5" }
          ],
          outputs: ["tStatistic", "pValue", "degreesOfFreedom", "criticalValue", "confidenceInterval", "conclusion"],
          validationRules: {
            minimumFields: 4,
            description: "Enter sample statistics or raw data for t-test"
          }
        },
        usageCount: 18600,
        isActive: true,
        keywords: ["t test", "hypothesis", "statistical significance", "confidence interval", "p value"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "anova-calculator",
        title: "ANOVA Calculator",
        description: "Perform one-way Analysis of Variance (ANOVA) with F-test and post-hoc analysis",
        category: "math",
        subcategory: "statistics-probability",
        icon: "bar-chart-2",
        formula: "F = MSB/MSW, MSB = SSB/(k-1), MSW = SSW/(N-k)",
        variables: {
          inputs: [
            { name: "group1", label: "Group 1 Data (comma separated)", unit: "", type: "text", placeholder: "e.g. 1, 2, 3" },
            { name: "group2", label: "Group 2 Data (comma separated)", unit: "", type: "text", placeholder: "e.g. 4, 5, 6" },
            { name: "group3", label: "Group 3 Data (comma separated)", unit: "", type: "text", placeholder: "e.g. 7, 8, 9" },
            { name: "significanceLevel", label: "Significance Level (α)", unit: "", type: "number", min: 0, max: 1, default: 0.05 }
          ],
          outputs: ["fStatistic", "pValue", "dfBetween", "dfWithin", "ssTotal", "msBetween", "msWithin", "conclusion"],
          validationRules: {
            minimumFields: 2,
            description: "Enter data for at least 2 groups"
          }
        },
        usageCount: 13900,
        isActive: true,
        keywords: ["anova", "analysis of variance", "f test", "group comparison", "statistical significance"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "probability-distributions",
        title: "Probability Distributions Calculator",
        description: "Calculate probabilities for normal, binomial, Poisson, and other distributions",
        category: "math",
        subcategory: "statistics-probability",
        icon: "activity",
        formula: "Normal: f(x) = (1/(σ√2π))e^(-½((x-μ)/σ)²), Binomial: P(X=k) = C(n,k)p^k(1-p)^(n-k)",
        variables: {
          inputs: [
            { name: "distribution", label: "Distribution Type", unit: "", type: "select", required: true, options: ["normal", "binomial", "poisson", "uniform", "exponential"] },
            { name: "mean", label: "Mean (μ)", unit: "", type: "number" },
            { name: "standardDeviation", label: "Standard Deviation (σ)", unit: "", type: "number", min: 0 },
            { name: "n", label: "Number of trials (n)", unit: "", type: "number", min: 0 },
            { name: "p", label: "Probability of success (p)", unit: "", type: "number", min: 0, max: 1 },
            { name: "lambda", label: "Rate parameter (λ)", unit: "", type: "number", min: 0 },
            { name: "x", label: "Value (x)", unit: "", type: "number" },
            { name: "a", label: "Lower bound (a)", unit: "", type: "number" },
            { name: "b", label: "Upper bound (b)", unit: "", type: "number" }
          ],
          outputs: ["probability", "cumulativeProbability", "mean", "variance", "standardDeviation", "percentiles"],
          validationRules: {
            minimumFields: 2,
            description: "Select distribution and enter required parameters"
          }
        },
        usageCount: 21700,
        isActive: true,
        keywords: ["distribution", "normal", "binomial", "poisson", "probability", "cumulative"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "correlation-calculator",
        title: "Correlation Calculator",
        description: "Calculate Pearson correlation coefficient and linear correlation analysis",
        category: "math",
        subcategory: "statistics-probability",
        icon: "trending-up",
        formula: "r = Σ((xi-x̄)(yi-ȳ))/√(Σ(xi-x̄)²Σ(yi-ȳ)²)",
        variables: {
          inputs: [
            { name: "xValues", label: "X Values (comma separated)", unit: "", type: "text", required: true, placeholder: "e.g. 1, 2, 3, 4, 5" },
            { name: "yValues", label: "Y Values (comma separated)", unit: "", type: "text", required: true, placeholder: "e.g. 2, 4, 6, 8, 10" }
          ],
          outputs: ["correlationCoefficient", "rSquared", "significance", "covariance", "strength", "direction"],
          validationRules: {
            minimumFields: 2,
            description: "Enter paired x and y values (equal number of values)"
          }
        },
        usageCount: 16800,
        isActive: true,
        keywords: ["correlation", "pearson", "coefficient", "linear", "relationship", "covariance"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "linear-regression",
        title: "Linear Regression Calculator",
        description: "Perform linear regression analysis with equation, R², and predictions",
        category: "math",
        subcategory: "statistics-probability",
        icon: "trending-up",
        formula: "y = mx + b, m = Σ((xi-x̄)(yi-ȳ))/Σ(xi-x̄)², b = ȳ - mx̄",
        variables: {
          inputs: [
            { name: "xValues", label: "X Values (comma separated)", unit: "", type: "text", required: true, placeholder: "e.g. 1, 2, 3, 4, 5" },
            { name: "yValues", label: "Y Values (comma separated)", unit: "", type: "text", required: true, placeholder: "e.g. 2, 4, 6, 8, 10" },
            { name: "predictX", label: "X value for prediction", unit: "", type: "number" }
          ],
          outputs: ["slope", "intercept", "equation", "rSquared", "correlation", "prediction", "residuals"],
          validationRules: {
            minimumFields: 2,
            description: "Enter paired x and y values for regression analysis"
          }
        },
        usageCount: 24300,
        isActive: true,
        keywords: ["regression", "linear", "slope", "intercept", "r squared", "prediction"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Calculus & Transforms Subcategory  
      {
        id: "integral-calculator",
        title: "Integral Calculator",
        description: "Calculate definite and indefinite integrals with step-by-step solutions",
        category: "math",
        subcategory: "calculus",
        icon: "italic",
        formula: "∫f(x)dx, ∫[a,b]f(x)dx",
        variables: {
          inputs: [
            { name: "function", label: "Function f(x)", unit: "", type: "text", required: true, placeholder: "e.g. x^2 + 3*x + 1" },
            { name: "variable", label: "Variable", unit: "", type: "text", default: "x" },
            { name: "lowerLimit", label: "Lower Limit (a)", unit: "", type: "number", placeholder: "Leave empty for indefinite" },
            { name: "upperLimit", label: "Upper Limit (b)", unit: "", type: "number", placeholder: "Leave empty for indefinite" },
            { name: "integrationMethod", label: "Method", unit: "", type: "select", options: ["substitution", "parts", "partial_fractions", "trigonometric"], default: "substitution" }
          ],
          outputs: ["integral", "steps", "area", "graph"],
          validationRules: {
            minimumFields: 1,
            description: "Enter function to integrate"
          }
        },
        usageCount: 28400,
        isActive: true,
        keywords: ["integral", "integration", "antiderivative", "area", "calculus"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "limit-calculator",
        title: "Limit Calculator",
        description: "Calculate limits of functions with L'Hôpital's rule and step-by-step solutions",
        category: "math",
        subcategory: "calculus",
        icon: "arrow-right",
        formula: "lim[x→a] f(x), L'Hôpital: lim[x→a] f(x)/g(x) = lim[x→a] f'(x)/g'(x)",
        variables: {
          inputs: [
            { name: "function", label: "Function f(x)", unit: "", type: "text", required: true, placeholder: "e.g. (x^2-1)/(x-1)" },
            { name: "variable", label: "Variable", unit: "", type: "text", default: "x" },
            { name: "approachValue", label: "Approach Value (a)", unit: "", type: "text", required: true, placeholder: "e.g. 1, infinity, -infinity" },
            { name: "direction", label: "Direction", unit: "", type: "select", options: ["both", "left", "right"], default: "both" }
          ],
          outputs: ["limit", "steps", "lhopitalRule", "existence"],
          validationRules: {
            minimumFields: 2,
            description: "Enter function and approach value"
          }
        },
        usageCount: 19600,
        isActive: true,
        keywords: ["limit", "calculus", "lhopital", "infinity", "continuous", "approach"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "series-sequence",
        title: "Series & Sequence Calculator",
        description: "Calculate arithmetic/geometric series, sequences, and convergence tests",
        category: "math",
        subcategory: "calculus",
        icon: "list",
        formula: "Arithmetic: aₙ = a₁ + (n-1)d, Geometric: aₙ = a₁ × r^(n-1), Sₙ = Σaᵢ",
        variables: {
          inputs: [
            { name: "seriesType", label: "Series Type", unit: "", type: "select", required: true, options: ["arithmetic", "geometric", "power", "taylor"] },
            { name: "firstTerm", label: "First Term (a₁)", unit: "", type: "number" },
            { name: "commonDifference", label: "Common Difference (d)", unit: "", type: "number" },
            { name: "commonRatio", label: "Common Ratio (r)", unit: "", type: "number" },
            { name: "numberOfTerms", label: "Number of Terms (n)", unit: "", type: "number", min: 1 },
            { name: "nthTerm", label: "nth Term to Find", unit: "", type: "number", min: 1 },
            { name: "function", label: "Function (for power/Taylor)", unit: "", type: "text", placeholder: "e.g. e^x, sin(x)" },
            { name: "center", label: "Center Point (a)", unit: "", type: "number", default: 0 }
          ],
          outputs: ["nthTerm", "sum", "convergence", "ratio", "terms", "formula"],
          validationRules: {
            minimumFields: 3,
            description: "Enter series type and required parameters"
          }
        },
        usageCount: 22100,
        isActive: true,
        keywords: ["series", "sequence", "arithmetic", "geometric", "convergence", "sum"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "fourier-transform",
        title: "Fourier Transform Calculator",
        description: "Calculate Discrete Fourier Transform (DFT) and analyze frequency domain",
        category: "math",
        subcategory: "calculus",
        icon: "activity",
        formula: "X(k) = Σ[n=0 to N-1] x(n)e^(-j2πkn/N)",
        variables: {
          inputs: [
            { name: "signal", label: "Signal Values (comma separated)", unit: "", type: "text", required: true, placeholder: "e.g. 1, 0, -1, 0" },
            { name: "samplingRate", label: "Sampling Rate (Hz)", unit: "Hz", type: "number", min: 1, default: 1 },
            { name: "transformType", label: "Transform Type", unit: "", type: "select", options: ["dft", "idft"], default: "dft" }
          ],
          outputs: ["magnitude", "phase", "frequency", "realPart", "imaginaryPart", "powerSpectrum"],
          validationRules: {
            minimumFields: 1,
            description: "Enter signal values for Fourier analysis"
          }
        },
        usageCount: 8900,
        isActive: true,
        keywords: ["fourier", "transform", "dft", "frequency", "spectrum", "signal processing"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "laplace-transform",
        title: "Laplace Transform Calculator",
        description: "Calculate Laplace transforms and inverse transforms with common functions",
        category: "math",
        subcategory: "calculus",
        icon: "zap",
        formula: "ℒ{f(t)} = F(s) = ∫[0,∞] f(t)e^(-st)dt",
        variables: {
          inputs: [
            { name: "function", label: "Time Function f(t)", unit: "", type: "text", required: true, placeholder: "e.g. t^2, e^(-at), sin(wt)" },
            { name: "variable", label: "Time Variable", unit: "", type: "text", default: "t" },
            { name: "transformVariable", label: "Transform Variable", unit: "", type: "text", default: "s" },
            { name: "transformType", label: "Transform Type", unit: "", type: "select", options: ["forward", "inverse"], default: "forward" }
          ],
          outputs: ["transform", "steps", "convergence", "poles", "residues"],
          validationRules: {
            minimumFields: 1,
            description: "Enter function for Laplace transform"
          }
        },
        usageCount: 7200,
        isActive: true,
        keywords: ["laplace", "transform", "inverse", "differential", "equation", "control"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Existing Calculus calculators
      {
        id: "derivative-calculator",
        title: "Derivative Calculator",
        description: "Calculate derivatives with step-by-step solutions and graphing",
        category: "math",
        subcategory: "calculus",
        icon: "function",
        formula: "d/dx[f(x)]",
        variables: {
          inputs: [
            { name: "function", label: "Function f(x)", unit: "", type: "text", required: true, placeholder: "e.g. x^2 + 3*x + 1" },
            { name: "variable", label: "Variable", unit: "", type: "text", default: "x" },
            { name: "order", label: "Order of Derivative", unit: "", type: "number", default: 1, min: 1, max: 5 }
          ],
          outputs: ["derivative", "steps", "graph"]
        },
        usageCount: 22100,
        isActive: true,
        keywords: ["derivative", "calculus", "differentiation", "function", "slope"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "statistics-calculator",
        title: "Statistics Calculator",
        description: "Calculate mean, median, mode, standard deviation, and more",
        category: "math",
        subcategory: "statistics",
        icon: "chart-line",
        formula: "μ = Σx/n, σ = √(Σ(x-μ)²/n)",
        variables: {
          inputs: [
            { name: "dataset", label: "Data Set (comma separated)", unit: "", type: "text", required: true, placeholder: "e.g. 1, 2, 3, 4, 5" }
          ],
          outputs: ["mean", "median", "mode", "standardDeviation", "variance", "range"]
        },
        usageCount: 14300,
        isActive: true,
        keywords: ["statistics", "mean", "median", "mode", "standard deviation", "data"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Biology Calculators
      {
        id: "hardy-weinberg",
        title: "Hardy-Weinberg Calculator",
        description: "Calculate allele and genotype frequencies in populations",
        category: "biology",
        subcategory: "genetics",
        icon: "dna",
        formula: "p² + 2pq + q² = 1, p + q = 1",
        variables: {
          inputs: [
            { name: "alleleP", label: "Allele p frequency", unit: "", type: "number" },
            { name: "alleleQ", label: "Allele q frequency", unit: "", type: "number" },
            { name: "genotypePP", label: "PP genotype frequency", unit: "", type: "number" },
            { name: "genotypePQ", label: "Pq genotype frequency", unit: "", type: "number" },
            { name: "genotypeQQ", label: "qq genotype frequency", unit: "", type: "number" }
          ],
          outputs: ["alleleP", "alleleQ", "genotypePP", "genotypePQ", "genotypeQQ"]
        },
        usageCount: 5700,
        isActive: true,
        keywords: ["hardy weinberg", "genetics", "allele", "genotype", "population"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "bmi-calculator",
        title: "BMI & Body Composition Calculator",
        description: "Calculate BMI, body fat percentage, and metabolic rates",
        category: "biology",
        subcategory: "health",
        icon: "heartbeat",
        formula: "BMI = weight(kg) / height(m)²",
        variables: {
          inputs: [
            { name: "weight", label: "Weight", unit: "kg", type: "number", required: true, min: 1, max: 1000 },
            { name: "height", label: "Height", unit: "cm", type: "number", required: true, min: 30, max: 300 },
            { name: "age", label: "Age", unit: "years", type: "number", min: 1, max: 150 },
            { name: "gender", label: "Gender", unit: "", type: "select", options: ["male", "female"] }
          ],
          outputs: ["bmi", "bmiCategory", "idealWeight", "bmr"]
        },
        usageCount: 8900,
        isActive: true,
        keywords: ["bmi", "body mass index", "weight", "height", "health"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Human Body & Health Calculators
      {
        id: "bmr-calculator",
        title: "BMR Calculator (Basal Metabolic Rate)",
        description: "Calculate Basal Metabolic Rate using Harris-Benedict equation for daily energy expenditure",
        category: "biology",
        subcategory: "human-body",
        icon: "activity",
        formula: "Men: BMR = 88.362 + (13.397 × weight) + (4.799 × height) - (5.677 × age), Women: BMR = 447.593 + (9.247 × weight) + (3.098 × height) - (4.330 × age)",
        variables: {
          inputs: [
            { name: "weight", label: "Weight", unit: "kg", type: "number", required: true, min: 20, max: 300 },
            { name: "height", label: "Height", unit: "cm", type: "number", required: true, min: 100, max: 250 },
            { name: "age", label: "Age", unit: "years", type: "number", required: true, min: 10, max: 120 },
            { name: "gender", label: "Gender", unit: "", type: "select", required: true, options: ["male", "female"] },
            { name: "activityLevel", label: "Activity Level", unit: "", type: "select", required: true, options: ["sedentary", "lightly_active", "moderately_active", "very_active", "extremely_active"] }
          ],
          outputs: ["bmr", "tdee", "dailyCaloriesWeightLoss", "dailyCaloriesWeightGain"],
          validationRules: {
            minimumFields: 5,
            description: "Enter weight, height, age, gender, and activity level to calculate BMR and daily calorie needs"
          }
        },
        usageCount: 12400,
        isActive: true,
        keywords: ["bmr", "basal metabolic rate", "calories", "energy", "metabolism", "harris benedict"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "bsa-calculator",
        title: "BSA Calculator (Body Surface Area)",
        description: "Calculate Body Surface Area using Du Bois formula for medical dosing and treatments",
        category: "biology",
        subcategory: "human-body",
        icon: "user",
        formula: "BSA = 0.007184 × Weight^0.425 × Height^0.725",
        variables: {
          inputs: [
            { name: "weight", label: "Weight", unit: "kg", type: "number", required: true, min: 1, max: 300 },
            { name: "height", label: "Height", unit: "cm", type: "number", required: true, min: 30, max: 250 }
          ],
          outputs: ["bsaDuBois", "bsaMosteller", "bsaHaycock", "bsaBoyd"],
          validationRules: {
            minimumFields: 2,
            description: "Enter weight and height to calculate body surface area using multiple formulas"
          }
        },
        usageCount: 8600,
        isActive: true,
        keywords: ["bsa", "body surface area", "du bois", "medical", "dosing", "treatment"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "ibw-calculator",
        title: "Ideal Body Weight Calculator",
        description: "Calculate Ideal Body Weight using Devine, Robinson, and Miller formulas",
        category: "biology",
        subcategory: "human-body",
        icon: "target",
        formula: "Devine: Men = 50 + 2.3(height_in - 60), Women = 45.5 + 2.3(height_in - 60)",
        variables: {
          inputs: [
            { name: "height", label: "Height", unit: "cm", type: "number", required: true, min: 100, max: 250 },
            { name: "gender", label: "Gender", unit: "", type: "select", required: true, options: ["male", "female"] },
            { name: "currentWeight", label: "Current Weight (optional)", unit: "kg", type: "number", min: 20, max: 300 }
          ],
          outputs: ["ibwDevine", "ibwRobinson", "ibwMiller", "weightDifference", "percentIdeal"],
          validationRules: {
            minimumFields: 2,
            description: "Enter height and gender to calculate ideal body weight using multiple formulas"
          }
        },
        usageCount: 9200,
        isActive: true,
        keywords: ["ideal body weight", "ibw", "devine", "robinson", "miller", "weight loss"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "calorie-calculator",
        title: "Daily Calorie Requirement Calculator",
        description: "Calculate daily caloric needs based on goals: maintenance, weight loss, or weight gain",
        category: "biology",
        subcategory: "human-body",
        icon: "apple",
        formula: "TDEE = BMR × Activity Factor",
        variables: {
          inputs: [
            { name: "bmr", label: "BMR (if known)", unit: "calories/day", type: "number", min: 800, max: 4000 },
            { name: "weight", label: "Weight", unit: "kg", type: "number", min: 20, max: 300 },
            { name: "height", label: "Height", unit: "cm", type: "number", min: 100, max: 250 },
            { name: "age", label: "Age", unit: "years", type: "number", min: 10, max: 120 },
            { name: "gender", label: "Gender", unit: "", type: "select", options: ["male", "female"] },
            { name: "activityLevel", label: "Activity Level", unit: "", type: "select", required: true, options: ["sedentary", "lightly_active", "moderately_active", "very_active", "extremely_active"] },
            { name: "goal", label: "Goal", unit: "", type: "select", required: true, options: ["maintain", "lose_0.5kg", "lose_1kg", "gain_0.5kg", "gain_1kg"] }
          ],
          outputs: ["dailyCalories", "macroCarbs", "macroProtein", "macroFats", "weeklyWeightChange"],
          validationRules: {
            minimumFields: 2,
            description: "Enter activity level and goal, plus either BMR or weight/height/age/gender"
          }
        },
        usageCount: 15700,
        isActive: true,
        keywords: ["calories", "daily requirement", "tdee", "weight loss", "weight gain", "nutrition"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "heart-rate-calculator",
        title: "Heart Rate Calculator",
        description: "Calculate maximum heart rate, target heart rate zones for exercise and training",
        category: "biology",
        subcategory: "human-body",
        icon: "heart",
        formula: "Max HR = 220 - Age, Target HR = (Max HR - Resting HR) × Intensity + Resting HR",
        variables: {
          inputs: [
            { name: "age", label: "Age", unit: "years", type: "number", required: true, min: 10, max: 120 },
            { name: "restingHR", label: "Resting Heart Rate", unit: "bpm", type: "number", min: 40, max: 120, default: 70 },
            { name: "exerciseIntensity", label: "Exercise Intensity", unit: "%", type: "number", min: 50, max: 95, default: 75 }
          ],
          outputs: ["maxHeartRate", "targetHeartRate", "fatBurnZone", "cardioZone", "peakZone"],
          validationRules: {
            minimumFields: 1,
            description: "Enter age to calculate heart rate zones (resting HR optional for more accuracy)"
          }
        },
        usageCount: 11300,
        isActive: true,
        keywords: ["heart rate", "max heart rate", "target heart rate", "exercise", "cardio", "fitness"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "vo2-max-calculator",
        title: "VO2 Max Calculator",
        description: "Calculate VO2 Max (maximal oxygen uptake) for cardiovascular fitness assessment",
        category: "biology",
        subcategory: "human-body",
        icon: "wind",
        formula: "Cooper Test: VO2 Max = (Distance - 504.9) / 44.73",
        variables: {
          inputs: [
            { name: "testType", label: "Test Type", unit: "", type: "select", required: true, options: ["cooper_12min", "step_test", "rockport_walk"] },
            { name: "distance", label: "Distance (Cooper 12-min)", unit: "meters", type: "number", min: 1000, max: 5000 },
            { name: "age", label: "Age", unit: "years", type: "number", min: 10, max: 120 },
            { name: "gender", label: "Gender", unit: "", type: "select", options: ["male", "female"] },
            { name: "weight", label: "Weight", unit: "kg", type: "number", min: 30, max: 200 },
            { name: "heartRate", label: "Post-Exercise Heart Rate", unit: "bpm", type: "number", min: 100, max: 200 },
            { name: "walkTime", label: "1-Mile Walk Time", unit: "minutes", type: "number", min: 8, max: 30 }
          ],
          outputs: ["vo2Max", "fitnessCategory", "mlKgMin", "absoluteVO2"],
          validationRules: {
            minimumFields: 2,
            description: "Select test type and enter required parameters for VO2 Max calculation"
          }
        },
        usageCount: 7800,
        isActive: true,
        keywords: ["vo2 max", "cardiovascular fitness", "oxygen uptake", "cooper test", "aerobic capacity"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "lung-capacity-calculator",
        title: "Lung Capacity Calculator",
        description: "Calculate vital capacity, tidal volume, and other pulmonary function parameters",
        category: "biology",
        subcategory: "human-body",
        icon: "lungs",
        formula: "Vital Capacity: Men = (0.057 × height) - (0.022 × age) - 4.2, Women = (0.041 × height) - (0.018 × age) - 2.7",
        variables: {
          inputs: [
            { name: "height", label: "Height", unit: "cm", type: "number", required: true, min: 100, max: 250 },
            { name: "age", label: "Age", unit: "years", type: "number", required: true, min: 5, max: 120 },
            { name: "gender", label: "Gender", unit: "", type: "select", required: true, options: ["male", "female"] },
            { name: "smokingStatus", label: "Smoking Status", unit: "", type: "select", options: ["never", "former", "current"] }
          ],
          outputs: ["vitalCapacity", "tidalVolume", "inspiratoryReserve", "expiratoryReserve", "totalLungCapacity"],
          validationRules: {
            minimumFields: 3,
            description: "Enter height, age, and gender to calculate lung capacity parameters"
          }
        },
        usageCount: 5400,
        isActive: true,
        keywords: ["lung capacity", "vital capacity", "tidal volume", "pulmonary function", "respiratory"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "blood-volume-calculator",
        title: "Blood Volume Calculator",
        description: "Calculate total blood volume estimation using Nadler's formula",
        category: "biology",
        subcategory: "human-body",
        icon: "droplets",
        formula: "Men: BV = 0.3669 × height³ + 0.03219 × weight + 0.6041, Women: BV = 0.3561 × height³ + 0.03308 × weight + 0.1833",
        variables: {
          inputs: [
            { name: "weight", label: "Weight", unit: "kg", type: "number", required: true, min: 20, max: 200 },
            { name: "height", label: "Height", unit: "cm", type: "number", required: true, min: 100, max: 250 },
            { name: "gender", label: "Gender", unit: "", type: "select", required: true, options: ["male", "female"] },
            { name: "hematocrit", label: "Hematocrit (%)", unit: "%", type: "number", min: 20, max: 60, default: 42 }
          ],
          outputs: ["totalBloodVolume", "plasmaVolume", "redCellVolume", "bloodVolumePerKg"],
          validationRules: {
            minimumFields: 3,
            description: "Enter weight, height, and gender to calculate blood volume using Nadler's formula"
          }
        },
        usageCount: 4200,
        isActive: true,
        keywords: ["blood volume", "nadler", "plasma volume", "hematocrit", "circulation"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "blood-pressure-calculator",
        title: "Blood Pressure Calculator",
        description: "Analyze blood pressure readings, calculate mean arterial pressure and pulse pressure",
        category: "biology",
        subcategory: "human-body",
        icon: "gauge",
        formula: "MAP = (2 × Diastolic + Systolic) / 3, Pulse Pressure = Systolic - Diastolic",
        variables: {
          inputs: [
            { name: "systolic", label: "Systolic Pressure", unit: "mmHg", type: "number", required: true, min: 70, max: 300 },
            { name: "diastolic", label: "Diastolic Pressure", unit: "mmHg", type: "number", required: true, min: 40, max: 200 },
            { name: "age", label: "Age", unit: "years", type: "number", min: 5, max: 120 }
          ],
          outputs: ["meanArterialPressure", "pulsePressure", "bpCategory", "hypertensionStage", "recommendations"],
          validationRules: {
            minimumFields: 2,
            description: "Enter systolic and diastolic pressure to analyze blood pressure readings"
          }
        },
        usageCount: 8900,
        isActive: true,
        keywords: ["blood pressure", "systolic", "diastolic", "hypertension", "map", "pulse pressure"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "bac-calculator",
        title: "BAC Calculator (Blood Alcohol Content)",
        description: "Calculate Blood Alcohol Content using Widmark formula for alcohol metabolism",
        category: "biology",
        subcategory: "human-body",
        icon: "wine",
        formula: "BAC = (Alcohol consumed × 0.789) / (Body weight × r) - (0.015 × hours)",
        variables: {
          inputs: [
            { name: "weight", label: "Body Weight", unit: "kg", type: "number", required: true, min: 30, max: 200 },
            { name: "gender", label: "Gender", unit: "", type: "select", required: true, options: ["male", "female"] },
            { name: "alcoholAmount", label: "Alcohol Consumed", unit: "grams", type: "number", required: true, min: 0, max: 200 },
            { name: "timeElapsed", label: "Time Since Drinking", unit: "hours", type: "number", required: true, min: 0, max: 24 },
            { name: "drinks", label: "Number of Standard Drinks", unit: "drinks", type: "number", min: 0, max: 20 }
          ],
          outputs: ["bacPercent", "bacMgDl", "sobrietyTime", "impairmentLevel", "legalStatus"],
          validationRules: {
            minimumFields: 4,
            description: "Enter weight, gender, alcohol consumed, and time elapsed to calculate BAC"
          }
        },
        usageCount: 6700,
        isActive: true,
        keywords: ["bac", "blood alcohol content", "alcohol", "intoxication", "widmark", "metabolism"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Molecular & Cell Biology Calculators
      {
        id: "dna-rna-concentration",
        title: "DNA/RNA Concentration Calculator",
        description: "Calculate nucleic acid concentration using UV spectrophotometry (A260/A280 ratio)",
        category: "biology",
        subcategory: "molecular-cell",
        icon: "dna",
        formula: "Concentration = A260 × dilution factor × extinction coefficient",
        variables: {
          inputs: [
            { name: "a260", label: "A260 Absorbance", unit: "", type: "number", required: true, min: 0, max: 10 },
            { name: "a280", label: "A280 Absorbance", unit: "", type: "number", required: true, min: 0, max: 10 },
            { name: "dilutionFactor", label: "Dilution Factor", unit: "", type: "number", required: true, min: 1, max: 10000, default: 1 },
            { name: "nucleicAcidType", label: "Nucleic Acid Type", unit: "", type: "select", required: true, options: ["dsDNA", "ssDNA", "RNA", "oligo"] },
            { name: "pathLength", label: "Path Length", unit: "cm", type: "number", min: 0.1, max: 10, default: 1 }
          ],
          outputs: ["concentration", "a260a280Ratio", "purityAssessment", "yield", "molarConcentration"],
          validationRules: {
            minimumFields: 4,
            description: "Enter A260, A280, dilution factor, and nucleic acid type to calculate concentration"
          }
        },
        usageCount: 5800,
        isActive: true,
        keywords: ["dna", "rna", "concentration", "uv spectrophotometry", "a260", "a280", "purity"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "protein-concentration",
        title: "Protein Concentration Calculator",
        description: "Calculate protein concentration using Bradford, Lowry, or BCA assay methods",
        category: "biology",
        subcategory: "molecular-cell",
        icon: "atom",
        formula: "Bradford: Concentration = (Abs595 - b) / m, where m = slope, b = intercept",
        variables: {
          inputs: [
            { name: "assayType", label: "Assay Type", unit: "", type: "select", required: true, options: ["bradford", "lowry", "bca", "uv280"] },
            { name: "absorbance", label: "Absorbance", unit: "", type: "number", required: true, min: 0, max: 5 },
            { name: "wavelength", label: "Wavelength", unit: "nm", type: "number", min: 200, max: 800, default: 595 },
            { name: "dilutionFactor", label: "Dilution Factor", unit: "", type: "number", required: true, min: 1, max: 1000, default: 1 },
            { name: "pathLength", label: "Path Length", unit: "cm", type: "number", min: 0.1, max: 10, default: 1 },
            { name: "standardCurveSlope", label: "Standard Curve Slope", unit: "", type: "number", min: 0, max: 10 },
            { name: "standardCurveIntercept", label: "Standard Curve Intercept", unit: "", type: "number", min: -1, max: 1 }
          ],
          outputs: ["proteinConcentration", "totalProtein", "molarConcentration", "specificActivity"],
          validationRules: {
            minimumFields: 4,
            description: "Select assay type and enter absorbance, wavelength, and dilution factor"
          }
        },
        usageCount: 7200,
        isActive: true,
        keywords: ["protein", "concentration", "bradford", "lowry", "bca", "assay", "spectrophotometry"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "enzyme-activity",
        title: "Enzyme Activity Calculator",
        description: "Calculate enzyme activity, specific activity, and catalytic efficiency",
        category: "biology",
        subcategory: "molecular-cell",
        icon: "zap",
        formula: "Activity = ΔAbs / (ε × path length × time), Specific Activity = Activity / protein concentration",
        variables: {
          inputs: [
            { name: "deltaAbsorbance", label: "Change in Absorbance (ΔA)", unit: "", type: "number", required: true, min: 0, max: 5 },
            { name: "timeInterval", label: "Time Interval", unit: "minutes", type: "number", required: true, min: 0.1, max: 60 },
            { name: "extinctionCoefficient", label: "Extinction Coefficient (ε)", unit: "M⁻¹cm⁻¹", type: "number", required: true, min: 100, max: 100000 },
            { name: "pathLength", label: "Path Length", unit: "cm", type: "number", required: true, min: 0.1, max: 10, default: 1 },
            { name: "reactionVolume", label: "Reaction Volume", unit: "mL", type: "number", required: true, min: 0.1, max: 10 },
            { name: "proteinConcentration", label: "Protein Concentration", unit: "mg/mL", type: "number", min: 0.001, max: 100 },
            { name: "dilutionFactor", label: "Enzyme Dilution Factor", unit: "", type: "number", min: 1, max: 10000, default: 1 }
          ],
          outputs: ["enzymeActivity", "specificActivity", "totalActivity", "catalyticEfficiency", "turnoverNumber"],
          validationRules: {
            minimumFields: 5,
            description: "Enter change in absorbance, time, extinction coefficient, path length, and reaction volume"
          }
        },
        usageCount: 4600,
        isActive: true,
        keywords: ["enzyme", "activity", "kinetics", "specific activity", "catalytic efficiency", "biochemistry"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "michaelis-menten",
        title: "Michaelis-Menten Calculator",
        description: "Calculate enzyme kinetic parameters: Km, Vmax, kcat using Michaelis-Menten equation",
        category: "biology",
        subcategory: "molecular-cell",
        icon: "trending-up",
        formula: "v = (Vmax × [S]) / (Km + [S])",
        variables: {
          inputs: [
            { name: "substrateConcentrations", label: "Substrate Concentrations", unit: "mM", type: "text", required: true, placeholder: "Enter comma-separated values" },
            { name: "initialVelocities", label: "Initial Velocities", unit: "μmol/min", type: "text", required: true, placeholder: "Enter comma-separated values" },
            { name: "enzymeConcentration", label: "Enzyme Concentration", unit: "μM", type: "number", min: 0.001, max: 1000 },
            { name: "temperature", label: "Temperature", unit: "°C", type: "number", min: 4, max: 100, default: 25 },
            { name: "ph", label: "pH", unit: "", type: "number", min: 3, max: 12, default: 7.4 }
          ],
          outputs: ["km", "vmax", "kcat", "catalyticEfficiency", "rSquared", "lineweaverBurkPlot"],
          validationRules: {
            minimumFields: 2,
            description: "Enter substrate concentrations and corresponding initial velocities (minimum 4 data points)"
          }
        },
        usageCount: 3400,
        isActive: true,
        keywords: ["michaelis menten", "enzyme kinetics", "km", "vmax", "kcat", "lineweaver burk"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "cell-dilution",
        title: "Cell Dilution Calculator",
        description: "Calculate serial dilutions, cell concentrations, and dilution protocols",
        category: "biology",
        subcategory: "molecular-cell",
        icon: "test-tube",
        formula: "C1V1 = C2V2, Dilution Factor = Final Volume / Initial Volume",
        variables: {
          inputs: [
            { name: "initialConcentration", label: "Initial Concentration", unit: "cells/mL", type: "number", required: true, min: 1, max: 1e12 },
            { name: "finalConcentration", label: "Desired Final Concentration", unit: "cells/mL", type: "number", min: 1, max: 1e12 },
            { name: "finalVolume", label: "Final Volume Needed", unit: "mL", type: "number", required: true, min: 0.1, max: 1000 },
            { name: "numberOfDilutions", label: "Number of Serial Dilutions", unit: "", type: "number", min: 1, max: 10 },
            { name: "dilutionFactor", label: "Dilution Factor per Step", unit: "", type: "number", min: 2, max: 1000, default: 10 }
          ],
          outputs: ["volumeToTake", "volumeToAdd", "totalDilutionFactor", "serialDilutionSteps", "finalConcentrationAchieved"],
          validationRules: {
            minimumFields: 2,
            description: "Enter initial concentration and either final concentration or final volume"
          }
        },
        usageCount: 6800,
        isActive: true,
        keywords: ["cell dilution", "serial dilution", "c1v1 c2v2", "cell culture", "concentration"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "bacterial-growth",
        title: "Bacterial Growth Calculator",
        description: "Calculate exponential bacterial growth rate, doubling time, and population dynamics",
        category: "biology",
        subcategory: "molecular-cell",
        icon: "bacteria",
        formula: "Nt = N0 × e^(μt), Doubling time = ln(2) / μ",
        variables: {
          inputs: [
            { name: "initialPopulation", label: "Initial Population (N0)", unit: "cells/mL", type: "number", required: true, min: 1, max: 1e12 },
            { name: "finalPopulation", label: "Final Population (Nt)", unit: "cells/mL", type: "number", min: 1, max: 1e12 },
            { name: "timeInterval", label: "Time Interval", unit: "hours", type: "number", required: true, min: 0.1, max: 100 },
            { name: "growthRate", label: "Growth Rate (μ)", unit: "per hour", type: "number", min: 0.01, max: 10 },
            { name: "doublingTime", label: "Doubling Time", unit: "hours", type: "number", min: 0.1, max: 100 },
            { name: "targetTime", label: "Target Time for Prediction", unit: "hours", type: "number", min: 0, max: 200 }
          ],
          outputs: ["growthRate", "doublingTime", "predictedPopulation", "generationNumber", "exponentialPhase"],
          validationRules: {
            minimumFields: 2,
            description: "Enter initial population and time interval, plus either final population, growth rate, or doubling time"
          }
        },
        usageCount: 5200,
        isActive: true,
        keywords: ["bacterial growth", "exponential growth", "doubling time", "microbiology", "population dynamics"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Genetics & Evolution Calculators
      {
        id: "punnett-square",
        title: "Punnett Square Calculator",
        description: "Calculate genetic cross outcomes and offspring probability ratios",
        category: "biology",
        subcategory: "genetics",
        icon: "grid-3x3",
        formula: "Probability = (Number of desired outcomes) / (Total number of outcomes)",
        variables: {
          inputs: [
            { name: "parent1Genotype", label: "Parent 1 Genotype", unit: "", type: "text", required: true, placeholder: "e.g., Aa" },
            { name: "parent2Genotype", label: "Parent 2 Genotype", unit: "", type: "text", required: true, placeholder: "e.g., aa" },
            { name: "crossType", label: "Cross Type", unit: "", type: "select", required: true, options: ["monohybrid", "dihybrid", "testcross"] },
            { name: "dominancePattern", label: "Dominance Pattern", unit: "", type: "select", required: true, options: ["complete", "incomplete", "codominant"] }
          ],
          outputs: ["offspringRatios", "genotypeFrequencies", "phenotypeFrequencies", "punnettGrid", "chisquareTest"],
          validationRules: {
            minimumFields: 4,
            description: "Enter both parent genotypes, cross type, and dominance pattern"
          }
        },
        usageCount: 8900,
        isActive: true,
        keywords: ["punnett square", "genetics", "crosses", "genotype", "phenotype", "heredity"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "mendelian-inheritance",
        title: "Mendelian Inheritance Calculator",
        description: "Calculate inheritance patterns following Mendel's laws for dominant/recessive traits",
        category: "biology",
        subcategory: "genetics",
        icon: "family-tree",
        formula: "F2 ratio: 3:1 (dominant:recessive) for monohybrid cross",
        variables: {
          inputs: [
            { name: "inheritanceType", label: "Inheritance Type", unit: "", type: "select", required: true, options: ["autosomal_dominant", "autosomal_recessive", "x_linked_recessive", "x_linked_dominant"] },
            { name: "parentGenotypes", label: "Parent Genotypes", unit: "", type: "text", required: true, placeholder: "e.g., AA x aa" },
            { name: "numberOfOffspring", label: "Number of Offspring", unit: "", type: "number", min: 1, max: 1000, default: 100 },
            { name: "penetrance", label: "Penetrance", unit: "%", type: "number", min: 0, max: 100, default: 100 }
          ],
          outputs: ["expectedRatios", "probabilityAffected", "carrierProbability", "skipGenerationRisk", "inheritancePattern"],
          validationRules: {
            minimumFields: 2,
            description: "Select inheritance type and enter parent genotypes to calculate outcomes"
          }
        },
        usageCount: 6400,
        isActive: true,
        keywords: ["mendelian inheritance", "dominant", "recessive", "x-linked", "autosomal", "penetrance"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "population-growth-rate",
        title: "Population Growth Rate Calculator",
        description: "Calculate demographic parameters: birth rate, death rate, growth rate, and population projections",
        category: "biology",
        subcategory: "genetics",
        icon: "trending-up",
        formula: "Growth Rate = Birth Rate - Death Rate + Immigration - Emigration",
        variables: {
          inputs: [
            { name: "initialPopulation", label: "Initial Population", unit: "individuals", type: "number", required: true, min: 1, max: 1e12 },
            { name: "birthRate", label: "Birth Rate", unit: "per 1000 per year", type: "number", min: 0, max: 100 },
            { name: "deathRate", label: "Death Rate", unit: "per 1000 per year", type: "number", min: 0, max: 100 },
            { name: "immigrationRate", label: "Immigration Rate", unit: "per 1000 per year", type: "number", min: 0, max: 100, default: 0 },
            { name: "emigrationRate", label: "Emigration Rate", unit: "per 1000 per year", type: "number", min: 0, max: 100, default: 0 },
            { name: "timeYears", label: "Time Period", unit: "years", type: "number", required: true, min: 1, max: 100 },
            { name: "carryingCapacity", label: "Carrying Capacity", unit: "individuals", type: "number", min: 1, max: 1e12 }
          ],
          outputs: ["growthRate", "doublingTime", "projectedPopulation", "netMigration", "populationMomentum"],
          validationRules: {
            minimumFields: 3,
            description: "Enter initial population, time period, and at least birth or death rate"
          }
        },
        usageCount: 4800,
        isActive: true,
        keywords: ["population growth", "demographics", "birth rate", "death rate", "ecology", "evolution"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Medical & Clinical Calculators
      {
        id: "drug-dosage",
        title: "Drug Dosage Calculator",
        description: "Calculate medication dosages, pediatric doses, and administration schedules",
        category: "biology",
        subcategory: "medical-clinical",
        icon: "pill",
        formula: "Dose = (Weight × mg/kg dose) / concentration",
        variables: {
          inputs: [
            { name: "patientWeight", label: "Patient Weight", unit: "kg", type: "number", required: true, min: 0.5, max: 300 },
            { name: "dosagePerKg", label: "Dosage per kg", unit: "mg/kg", type: "number", required: true, min: 0.01, max: 1000 },
            { name: "drugConcentration", label: "Drug Concentration", unit: "mg/mL", type: "number", required: true, min: 0.1, max: 1000 },
            { name: "frequency", label: "Dosing Frequency", unit: "times/day", type: "number", required: true, min: 1, max: 24 },
            { name: "patientAge", label: "Patient Age", unit: "years", type: "number", min: 0, max: 120 },
            { name: "administrationRoute", label: "Route", unit: "", type: "select", options: ["oral", "iv", "im", "sc", "topical"] }
          ],
          outputs: ["totalDailyDose", "singleDose", "volumePerDose", "pediatricDose", "maxSafeDose"],
          validationRules: {
            minimumFields: 4,
            description: "Enter patient weight, dosage per kg, drug concentration, and frequency"
          }
        },
        usageCount: 9600,
        isActive: true,
        keywords: ["drug dosage", "medication", "pediatric dose", "pharmacology", "clinical", "pharmacy"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "drug-half-life",
        title: "Drug Half-Life Calculator",
        description: "Calculate pharmacokinetic parameters: half-life, clearance, and steady-state concentrations",
        category: "biology",
        subcategory: "medical-clinical",
        icon: "clock",
        formula: "t½ = 0.693 / ke, Steady State = 5 × t½",
        variables: {
          inputs: [
            { name: "initialConcentration", label: "Initial Concentration (C0)", unit: "mg/L", type: "number", required: true, min: 0.1, max: 1000 },
            { name: "concentrationTime", label: "Concentration at Time T", unit: "mg/L", type: "number", min: 0.01, max: 1000 },
            { name: "timeInterval", label: "Time Interval", unit: "hours", type: "number", required: true, min: 0.1, max: 168 },
            { name: "eliminationConstant", label: "Elimination Constant (ke)", unit: "per hour", type: "number", min: 0.001, max: 10 },
            { name: "volumeDistribution", label: "Volume of Distribution", unit: "L/kg", type: "number", min: 0.1, max: 50 },
            { name: "patientWeight", label: "Patient Weight", unit: "kg", type: "number", min: 1, max: 300 }
          ],
          outputs: ["halfLife", "eliminationConstant", "clearance", "steadyStateTime", "timeToElimination"],
          validationRules: {
            minimumFields: 2,
            description: "Enter initial concentration and time interval, plus either final concentration or elimination constant"
          }
        },
        usageCount: 5300,
        isActive: true,
        keywords: ["half life", "pharmacokinetics", "elimination", "clearance", "steady state", "drug metabolism"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "gfr-calculator",
        title: "GFR Calculator (Glomerular Filtration Rate)",
        description: "Calculate estimated GFR using CKD-EPI and MDRD equations for kidney function assessment",
        category: "biology",
        subcategory: "medical-clinical",
        icon: "kidney",
        formula: "CKD-EPI: eGFR = 141 × min(SCr/κ,1)^α × max(SCr/κ,1)^-1.209 × 0.993^Age",
        variables: {
          inputs: [
            { name: "serumCreatinine", label: "Serum Creatinine", unit: "mg/dL", type: "number", required: true, min: 0.1, max: 20 },
            { name: "age", label: "Age", unit: "years", type: "number", required: true, min: 1, max: 120 },
            { name: "gender", label: "Gender", unit: "", type: "select", required: true, options: ["male", "female"] },
            { name: "race", label: "Race", unit: "", type: "select", required: true, options: ["african_american", "other"] },
            { name: "equation", label: "Equation", unit: "", type: "select", required: true, options: ["ckd_epi", "mdrd", "cockcroft_gault"] },
            { name: "weight", label: "Weight (for Cockcroft-Gault)", unit: "kg", type: "number", min: 10, max: 300 }
          ],
          outputs: ["gfrCkdEpi", "gfrMdrd", "gfrCockcroftGault", "ckdStage", "kidneyFunctionStatus"],
          validationRules: {
            minimumFields: 5,
            description: "Enter serum creatinine, age, gender, race, and preferred equation"
          }
        },
        usageCount: 7800,
        isActive: true,
        keywords: ["gfr", "glomerular filtration rate", "kidney function", "creatinine", "ckd-epi", "mdrd"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "hematocrit-calculator",
        title: "Hematocrit Calculator",
        description: "Calculate hematocrit, hemoglobin relationship, and blood cell percentages",
        category: "biology",
        subcategory: "medical-clinical",
        icon: "droplet",
        formula: "Hematocrit ≈ Hemoglobin × 3 (Rule of Three)",
        variables: {
          inputs: [
            { name: "hemoglobin", label: "Hemoglobin", unit: "g/dL", type: "number", min: 3, max: 25 },
            { name: "hematocrit", label: "Hematocrit", unit: "%", type: "number", min: 10, max: 70 },
            { name: "redCellCount", label: "RBC Count", unit: "million/μL", type: "number", min: 1, max: 10 },
            { name: "patientAge", label: "Patient Age", unit: "years", type: "number", min: 0, max: 120 },
            { name: "patientGender", label: "Gender", unit: "", type: "select", options: ["male", "female"] }
          ],
          outputs: ["hematocrit", "hemoglobin", "mcv", "mch", "mchc", "anemiaStatus"],
          validationRules: {
            minimumFields: 1,
            description: "Enter either hemoglobin or hematocrit to calculate blood parameters"
          }
        },
        usageCount: 4500,
        isActive: true,
        keywords: ["hematocrit", "hemoglobin", "rbc", "anemia", "blood count", "hematology"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "cholesterol-ratio",
        title: "Cholesterol Ratio Calculator",
        description: "Calculate cholesterol ratios, cardiovascular risk assessment from lipid panel",
        category: "biology",
        subcategory: "medical-clinical",
        icon: "heart-pulse",
        formula: "TC/HDL Ratio = Total Cholesterol / HDL Cholesterol",
        variables: {
          inputs: [
            { name: "totalCholesterol", label: "Total Cholesterol", unit: "mg/dL", type: "number", required: true, min: 50, max: 800 },
            { name: "hdlCholesterol", label: "HDL Cholesterol", unit: "mg/dL", type: "number", required: true, min: 10, max: 150 },
            { name: "ldlCholesterol", label: "LDL Cholesterol", unit: "mg/dL", type: "number", min: 20, max: 500 },
            { name: "triglycerides", label: "Triglycerides", unit: "mg/dL", type: "number", min: 30, max: 2000 },
            { name: "patientAge", label: "Age", unit: "years", type: "number", min: 1, max: 120 },
            { name: "patientGender", label: "Gender", unit: "", type: "select", options: ["male", "female"] }
          ],
          outputs: ["tcHdlRatio", "ldlHdlRatio", "nonHdlCholesterol", "cardiovascularRisk", "lipidStatus"],
          validationRules: {
            minimumFields: 2,
            description: "Enter total cholesterol and HDL cholesterol to calculate ratios and risk assessment"
          }
        },
        usageCount: 6900,
        isActive: true,
        keywords: ["cholesterol", "hdl", "ldl", "triglycerides", "cardiovascular risk", "lipid panel"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Physiology & Ecology Calculators
      {
        id: "photosynthesis-rate",
        title: "Photosynthesis Rate Calculator",
        description: "Calculate photosynthetic rate, carbon fixation, and light use efficiency",
        category: "biology",
        subcategory: "physiology-ecology",
        icon: "sun",
        formula: "6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ + 6O₂",
        variables: {
          inputs: [
            { name: "lightIntensity", label: "Light Intensity", unit: "μmol/m²/s", type: "number", required: true, min: 0, max: 3000 },
            { name: "co2Concentration", label: "CO₂ Concentration", unit: "ppm", type: "number", required: true, min: 100, max: 2000 },
            { name: "temperature", label: "Temperature", unit: "°C", type: "number", required: true, min: 0, max: 50 },
            { name: "leafArea", label: "Leaf Area", unit: "cm²", type: "number", min: 1, max: 1000 },
            { name: "timeInterval", label: "Time Interval", unit: "hours", type: "number", min: 0.1, max: 24, default: 1 },
            { name: "waterAvailability", label: "Water Availability", unit: "%", type: "number", min: 0, max: 100, default: 100 }
          ],
          outputs: ["netPhotosynthesisRate", "grossPhotosynthesisRate", "carbonFixationRate", "oxygenProduction", "lightUseEfficiency"],
          validationRules: {
            minimumFields: 3,
            description: "Enter light intensity, CO₂ concentration, and temperature to calculate photosynthesis rate"
          }
        },
        usageCount: 3800,
        isActive: true,
        keywords: ["photosynthesis", "carbon fixation", "light intensity", "co2", "plant physiology"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "respiration-rate",
        title: "Cellular Respiration Rate Calculator",
        description: "Calculate cellular respiration rate, oxygen consumption, and metabolic efficiency",
        category: "biology",
        subcategory: "physiology-ecology",
        icon: "lungs",
        formula: "C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + ATP",
        variables: {
          inputs: [
            { name: "oxygenConsumption", label: "Oxygen Consumption", unit: "mL O₂/hr", type: "number", required: true, min: 0.1, max: 1000 },
            { name: "co2Production", label: "CO₂ Production", unit: "mL CO₂/hr", type: "number", min: 0.1, max: 1000 },
            { name: "organismMass", label: "Organism Mass", unit: "g", type: "number", required: true, min: 0.001, max: 10000 },
            { name: "temperature", label: "Temperature", unit: "°C", type: "number", required: true, min: 0, max: 50 },
            { name: "timeInterval", label: "Time Interval", unit: "hours", type: "number", min: 0.1, max: 24, default: 1 },
            { name: "metabolicState", label: "Metabolic State", unit: "", type: "select", options: ["resting", "active", "stressed"] }
          ],
          outputs: ["respiratoryQuotient", "metabolicRate", "atpProduction", "specificRespirationRate", "caloricEquivalent"],
          validationRules: {
            minimumFields: 3,
            description: "Enter oxygen consumption, organism mass, and temperature to calculate respiration parameters"
          }
        },
        usageCount: 2900,
        isActive: true,
        keywords: ["cellular respiration", "oxygen consumption", "metabolic rate", "rq", "atp production"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Mathematics Calculators - Arithmetic & Algebra
      {
        id: "basic-arithmetic",
        title: "Basic Arithmetic Calculator",
        description: "Perform basic arithmetic operations: addition, subtraction, multiplication, and division",
        category: "mathematics",
        subcategory: "arithmetic",
        icon: "calculator",
        formula: "a + b, a - b, a × b, a ÷ b",
        variables: {
          inputs: [
            { name: "number1", label: "First Number (a)", unit: "", type: "number", required: true },
            { name: "number2", label: "Second Number (b)", unit: "", type: "number", required: true },
            { name: "operation", label: "Operation", unit: "", type: "select", options: ["addition", "subtraction", "multiplication", "division"], required: true }
          ],
          outputs: ["result", "steps"],
          validationRules: {
            minimumFields: 3,
            description: "Enter two numbers and select an operation"
          }
        },
        usageCount: 25000,
        isActive: true,
        keywords: ["arithmetic", "addition", "subtraction", "multiplication", "division", "basic", "math"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "percentage-calculator",
        title: "Percentage Calculator",
        description: "Calculate percentages, percentage change, and percentage of a number",
        category: "mathematics",
        subcategory: "arithmetic",
        icon: "percent",
        formula: "% = (part/whole) × 100, % change = ((new-old)/old) × 100",
        variables: {
          inputs: [
            { name: "calculationType", label: "Calculation Type", unit: "", type: "select", options: ["percentage_of", "what_percent", "percent_change"], required: true },
            { name: "number1", label: "First Value", unit: "", type: "number", required: true, min: 0 },
            { name: "number2", label: "Second Value", unit: "", type: "number", required: true, min: 0 },
            { name: "percentage", label: "Percentage", unit: "%", type: "number", min: 0, max: 1000 }
          ],
          outputs: ["result", "percentage", "calculation"],
          validationRules: {
            minimumFields: 2,
            description: "Select calculation type and enter values"
          }
        },
        usageCount: 18500,
        isActive: true,
        keywords: ["percentage", "percent", "ratio", "proportion", "change", "increase", "decrease"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "ratio-proportion",
        title: "Ratio and Proportion Calculator",
        description: "Calculate ratios, proportions, and solve proportion problems",
        category: "mathematics",
        subcategory: "arithmetic",
        icon: "scale",
        formula: "a:b = c:d, a/b = c/d",
        variables: {
          inputs: [
            { name: "a", label: "First Term (a)", unit: "", type: "number", required: true, min: 0 },
            { name: "b", label: "Second Term (b)", unit: "", type: "number", required: true, min: 0 },
            { name: "c", label: "Third Term (c)", unit: "", type: "number", min: 0 },
            { name: "d", label: "Fourth Term (d)", unit: "", type: "number", min: 0 }
          ],
          outputs: ["ratio", "proportion", "missingTerm", "equivalent"],
          validationRules: {
            minimumFields: 3,
            description: "Enter at least 3 terms to solve proportion problems"
          }
        },
        usageCount: 12300,
        isActive: true,
        keywords: ["ratio", "proportion", "scale", "equivalent", "fraction", "cross multiply"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "average-calculator",
        title: "Average, Mean, Median, Mode Calculator",
        description: "Calculate arithmetic mean, median, mode, and range for a set of numbers",
        category: "mathematics",
        subcategory: "arithmetic",
        icon: "bar-chart",
        formula: "Mean = Σx/n, Median = middle value, Mode = most frequent",
        variables: {
          inputs: [
            { name: "numbers", label: "Numbers (comma-separated)", unit: "", type: "text", required: true },
            { name: "calculationType", label: "Calculate", unit: "", type: "select", options: ["all", "mean", "median", "mode", "range"], default: "all" }
          ],
          outputs: ["mean", "median", "mode", "range", "count", "sum"],
          validationRules: {
            minimumFields: 1,
            description: "Enter a list of numbers separated by commas"
          }
        },
        usageCount: 16700,
        isActive: true,
        keywords: ["average", "mean", "median", "mode", "range", "statistics", "central tendency"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "factorial-calculator",
        title: "Factorial Calculator",
        description: "Calculate factorial, double factorial, and subfactorial of numbers",
        category: "mathematics",
        subcategory: "arithmetic",
        icon: "hash",
        formula: "n! = n × (n-1) × ... × 1, 0! = 1",
        variables: {
          inputs: [
            { name: "number", label: "Number (n)", unit: "", type: "number", required: true, min: 0, max: 170 },
            { name: "factorialType", label: "Factorial Type", unit: "", type: "select", options: ["factorial", "double_factorial", "subfactorial"], default: "factorial" }
          ],
          outputs: ["result", "steps", "approximation"],
          validationRules: {
            minimumFields: 1,
            description: "Enter a non-negative integer (0-170 for standard factorial)"
          }
        },
        usageCount: 9400,
        isActive: true,
        keywords: ["factorial", "permutation", "combination", "gamma", "stirling"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "exponent-logarithm",
        title: "Exponent and Logarithm Calculator",
        description: "Calculate exponentials, logarithms, natural logs, and power functions",
        category: "mathematics",
        subcategory: "arithmetic",
        icon: "trending-up",
        formula: "aⁿ, log_b(x), ln(x), e^x",
        variables: {
          inputs: [
            { name: "base", label: "Base (a or b)", unit: "", type: "number", required: true, min: 0 },
            { name: "exponent", label: "Exponent (n)", unit: "", type: "number" },
            { name: "number", label: "Number (x)", unit: "", type: "number", min: 0 },
            { name: "operation", label: "Operation", unit: "", type: "select", options: ["power", "logarithm", "natural_log", "exponential"], required: true }
          ],
          outputs: ["result", "steps", "properties"],
          validationRules: {
            minimumFields: 2,
            description: "Select operation and enter appropriate values"
          }
        },
        usageCount: 11800,
        isActive: true,
        keywords: ["exponent", "logarithm", "power", "log", "ln", "exponential", "natural"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "roots-powers",
        title: "Roots and Powers Calculator",
        description: "Calculate square roots, cube roots, nth roots, and power functions",
        category: "mathematics",
        subcategory: "arithmetic",
        icon: "square-root",
        formula: "√x, ∛x, ⁿ√x, x^(1/n)",
        variables: {
          inputs: [
            { name: "number", label: "Number (x)", unit: "", type: "number", required: true },
            { name: "rootIndex", label: "Root Index (n)", unit: "", type: "number", min: 2, default: 2 },
            { name: "operation", label: "Operation", unit: "", type: "select", options: ["square_root", "cube_root", "nth_root", "power"], required: true }
          ],
          outputs: ["result", "realRoots", "complexRoots", "steps"],
          validationRules: {
            minimumFields: 2,
            description: "Enter number and select root type or power operation"
          }
        },
        usageCount: 13200,
        isActive: true,
        keywords: ["root", "square root", "cube root", "radical", "power", "nth root"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "quadratic-solver",
        title: "Quadratic Equation Solver",
        description: "Solve quadratic equations using the quadratic formula and find roots",
        category: "mathematics",
        subcategory: "arithmetic",
        icon: "function-square",
        formula: "ax² + bx + c = 0, x = (-b ± √(b²-4ac)) / 2a",
        variables: {
          inputs: [
            { name: "a", label: "Coefficient a", unit: "", type: "number", required: true },
            { name: "b", label: "Coefficient b", unit: "", type: "number", required: true },
            { name: "c", label: "Coefficient c", unit: "", type: "number", required: true }
          ],
          outputs: ["root1", "root2", "discriminant", "vertex", "steps"],
          validationRules: {
            minimumFields: 3,
            description: "Enter coefficients a, b, and c (a ≠ 0)"
          }
        },
        usageCount: 15600,
        isActive: true,
        keywords: ["quadratic", "equation", "roots", "discriminant", "formula", "parabola"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "polynomial-solver",
        title: "Polynomial Equation Solver",
        description: "Solve polynomial equations and find roots for various degrees",
        category: "mathematics",
        subcategory: "arithmetic",
        icon: "trending-up",
        formula: "aₙxⁿ + aₙ₋₁xⁿ⁻¹ + ... + a₁x + a₀ = 0",
        variables: {
          inputs: [
            { name: "coefficients", label: "Coefficients (comma-separated)", unit: "", type: "text", required: true },
            { name: "degree", label: "Polynomial Degree", unit: "", type: "number", min: 1, max: 4, default: 2 },
            { name: "method", label: "Solution Method", unit: "", type: "select", options: ["automatic", "factoring", "numerical"], default: "automatic" }
          ],
          outputs: ["roots", "realRoots", "complexRoots", "factorization"],
          validationRules: {
            minimumFields: 2,
            description: "Enter polynomial coefficients from highest to lowest degree"
          }
        },
        usageCount: 8900,
        isActive: true,
        keywords: ["polynomial", "equation", "roots", "factoring", "cubic", "quartic"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "linear-equation-solver",
        title: "Linear Equation Solver",
        description: "Solve linear equations and systems of linear equations",
        category: "mathematics",
        subcategory: "arithmetic",
        icon: "line-chart",
        formula: "ax + b = 0, system: ax + by = c",
        variables: {
          inputs: [
            { name: "equationType", label: "Equation Type", unit: "", type: "select", options: ["single", "system_2x2", "system_3x3"], required: true },
            { name: "a", label: "Coefficient a", unit: "", type: "number" },
            { name: "b", label: "Coefficient b", unit: "", type: "number" },
            { name: "c", label: "Constant c", unit: "", type: "number" },
            { name: "equations", label: "System Equations", unit: "", type: "text" }
          ],
          outputs: ["solution", "steps", "graphInfo", "systemType"],
          validationRules: {
            minimumFields: 2,
            description: "Select equation type and enter coefficients"
          }
        },
        usageCount: 14200,
        isActive: true,
        keywords: ["linear", "equation", "system", "solve", "simultaneous", "matrix"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Mathematics Calculators - Geometry & Trigonometry
      {
        id: "distance-between-points",
        title: "Distance Between Points Calculator",
        description: "Calculate the distance between two points in 2D and 3D space",
        category: "mathematics",
        subcategory: "geometry",
        icon: "ruler",
        formula: "d = √[(x₂-x₁)² + (y₂-y₁)²] for 2D, d = √[(x₂-x₁)² + (y₂-y₁)² + (z₂-z₁)²] for 3D",
        variables: {
          inputs: [
            { name: "dimension", label: "Dimension", unit: "", type: "select", options: ["2D", "3D"], required: true, default: "2D" },
            { name: "x1", label: "Point 1 - X coordinate", unit: "", type: "number", required: true },
            { name: "y1", label: "Point 1 - Y coordinate", unit: "", type: "number", required: true },
            { name: "z1", label: "Point 1 - Z coordinate", unit: "", type: "number" },
            { name: "x2", label: "Point 2 - X coordinate", unit: "", type: "number", required: true },
            { name: "y2", label: "Point 2 - Y coordinate", unit: "", type: "number", required: true },
            { name: "z2", label: "Point 2 - Z coordinate", unit: "", type: "number" }
          ],
          outputs: ["distance", "steps", "midpoint"],
          validationRules: {
            minimumFields: 4,
            description: "Enter coordinates for two points"
          }
        },
        usageCount: 11400,
        isActive: true,
        keywords: ["distance", "points", "coordinates", "euclidean", "geometry", "2d", "3d"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "midpoint-slope",
        title: "Midpoint and Slope Calculator",
        description: "Calculate midpoint, slope, and equation of line between two points",
        category: "mathematics",
        subcategory: "geometry",
        icon: "line-chart",
        formula: "Midpoint: ((x₁+x₂)/2, (y₁+y₂)/2), Slope: m = (y₂-y₁)/(x₂-x₁)",
        variables: {
          inputs: [
            { name: "x1", label: "Point 1 - X coordinate", unit: "", type: "number", required: true },
            { name: "y1", label: "Point 1 - Y coordinate", unit: "", type: "number", required: true },
            { name: "x2", label: "Point 2 - X coordinate", unit: "", type: "number", required: true },
            { name: "y2", label: "Point 2 - Y coordinate", unit: "", type: "number", required: true }
          ],
          outputs: ["midpoint", "slope", "lineEquation", "distance", "angle"],
          validationRules: {
            minimumFields: 4,
            description: "Enter coordinates for two points"
          }
        },
        usageCount: 9800,
        isActive: true,
        keywords: ["midpoint", "slope", "line", "equation", "gradient", "coordinates"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "area-calculator",
        title: "Area Calculator",
        description: "Calculate area of various geometric shapes: triangle, rectangle, circle, trapezoid, etc.",
        category: "mathematics",
        subcategory: "geometry",
        icon: "square",
        formula: "Various: A = lw, A = πr², A = ½bh, etc.",
        variables: {
          inputs: [
            { name: "shape", label: "Shape", unit: "", type: "select", options: ["rectangle", "square", "circle", "triangle", "trapezoid", "parallelogram", "ellipse", "polygon"], required: true },
            { name: "length", label: "Length/Side 1", unit: "", type: "number", min: 0 },
            { name: "width", label: "Width/Side 2", unit: "", type: "number", min: 0 },
            { name: "radius", label: "Radius", unit: "", type: "number", min: 0 },
            { name: "base", label: "Base", unit: "", type: "number", min: 0 },
            { name: "height", label: "Height", unit: "", type: "number", min: 0 },
            { name: "sides", label: "Number of Sides", unit: "", type: "number", min: 3, max: 20 }
          ],
          outputs: ["area", "perimeter", "formula", "steps"],
          validationRules: {
            minimumFields: 2,
            description: "Select shape and enter required dimensions"
          }
        },
        usageCount: 22500,
        isActive: true,
        keywords: ["area", "rectangle", "circle", "triangle", "geometry", "shape", "perimeter"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "volume-calculator",
        title: "Volume Calculator",
        description: "Calculate volume and surface area of 3D shapes: cube, sphere, cylinder, pyramid, etc.",
        category: "mathematics",
        subcategory: "geometry",
        icon: "cube",
        formula: "Various: V = lwh, V = ⁴⁄₃πr³, V = πr²h, etc.",
        variables: {
          inputs: [
            { name: "shape", label: "3D Shape", unit: "", type: "select", options: ["cube", "rectangular_prism", "sphere", "cylinder", "cone", "pyramid", "triangular_prism"], required: true },
            { name: "length", label: "Length", unit: "", type: "number", min: 0 },
            { name: "width", label: "Width", unit: "", type: "number", min: 0 },
            { name: "height", label: "Height", unit: "", type: "number", min: 0 },
            { name: "radius", label: "Radius", unit: "", type: "number", min: 0 },
            { name: "side", label: "Side Length", unit: "", type: "number", min: 0 }
          ],
          outputs: ["volume", "surfaceArea", "formula", "steps"],
          validationRules: {
            minimumFields: 2,
            description: "Select 3D shape and enter required dimensions"
          }
        },
        usageCount: 18700,
        isActive: true,
        keywords: ["volume", "surface area", "cube", "sphere", "cylinder", "3d", "geometry"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "trigonometric-functions",
        title: "Trigonometric Functions Calculator",
        description: "Calculate sin, cos, tan, and their inverse functions for angles",
        category: "mathematics",
        subcategory: "geometry",
        icon: "triangle",
        formula: "sin(θ), cos(θ), tan(θ), arcsin(x), arccos(x), arctan(x)",
        variables: {
          inputs: [
            { name: "angleInput", label: "Angle", unit: "", type: "number", required: true },
            { name: "angleUnit", label: "Angle Unit", unit: "", type: "select", options: ["degrees", "radians"], required: true, default: "degrees" },
            { name: "function", label: "Function", unit: "", type: "select", options: ["sin", "cos", "tan", "csc", "sec", "cot", "arcsin", "arccos", "arctan"], required: true },
            { name: "value", label: "Value (for inverse functions)", unit: "", type: "number", min: -1, max: 1 }
          ],
          outputs: ["result", "allFunctions", "quadrant", "reference"],
          validationRules: {
            minimumFields: 3,
            description: "Enter angle and select function, or enter value for inverse functions"
          }
        },
        usageCount: 19200,
        isActive: true,
        keywords: ["trigonometry", "sin", "cos", "tan", "angle", "radians", "degrees", "inverse"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "law-of-sines-cosines",
        title: "Law of Sines and Cosines Calculator",
        description: "Solve triangles using law of sines and law of cosines",
        category: "mathematics",
        subcategory: "geometry",
        icon: "triangle",
        formula: "a/sin(A) = b/sin(B) = c/sin(C), c² = a² + b² - 2ab·cos(C)",
        variables: {
          inputs: [
            { name: "knownElements", label: "Known Elements", unit: "", type: "select", options: ["SSS", "SAS", "ASA", "AAS", "SSA"], required: true },
            { name: "sideA", label: "Side a", unit: "", type: "number", min: 0 },
            { name: "sideB", label: "Side b", unit: "", type: "number", min: 0 },
            { name: "sideC", label: "Side c", unit: "", type: "number", min: 0 },
            { name: "angleA", label: "Angle A", unit: "degrees", type: "number", min: 0, max: 180 },
            { name: "angleB", label: "Angle B", unit: "degrees", type: "number", min: 0, max: 180 },
            { name: "angleC", label: "Angle C", unit: "degrees", type: "number", min: 0, max: 180 }
          ],
          outputs: ["allSides", "allAngles", "area", "perimeter", "triangleType"],
          validationRules: {
            minimumFields: 3,
            description: "Select triangle type and enter known sides/angles"
          }
        },
        usageCount: 8600,
        isActive: true,
        keywords: ["triangle", "law of sines", "law of cosines", "solve triangle", "trigonometry"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "angle-between-vectors",
        title: "Angle Between Vectors Calculator",
        description: "Calculate angle between two vectors in 2D or 3D space",
        category: "mathematics",
        subcategory: "geometry",
        icon: "move",
        formula: "cos(θ) = (a·b) / (|a||b|), where a·b is dot product",
        variables: {
          inputs: [
            { name: "dimension", label: "Dimension", unit: "", type: "select", options: ["2D", "3D"], required: true, default: "2D" },
            { name: "v1x", label: "Vector 1 - X component", unit: "", type: "number", required: true },
            { name: "v1y", label: "Vector 1 - Y component", unit: "", type: "number", required: true },
            { name: "v1z", label: "Vector 1 - Z component", unit: "", type: "number" },
            { name: "v2x", label: "Vector 2 - X component", unit: "", type: "number", required: true },
            { name: "v2y", label: "Vector 2 - Y component", unit: "", type: "number", required: true },
            { name: "v2z", label: "Vector 2 - Z component", unit: "", type: "number" },
            { name: "angleUnit", label: "Result Unit", unit: "", type: "select", options: ["degrees", "radians"], default: "degrees" }
          ],
          outputs: ["angle", "dotProduct", "magnitudes", "unitVectors"],
          validationRules: {
            minimumFields: 4,
            description: "Enter components for both vectors"
          }
        },
        usageCount: 6900,
        isActive: true,
        keywords: ["vector", "angle", "dot product", "magnitude", "3d", "geometry"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "polar-cartesian-converter",
        title: "Polar ↔ Cartesian Converter",
        description: "Convert between polar (r, θ) and Cartesian (x, y) coordinate systems",
        category: "mathematics",
        subcategory: "geometry",
        icon: "compass",
        formula: "x = r·cos(θ), y = r·sin(θ), r = √(x²+y²), θ = atan2(y,x)",
        variables: {
          inputs: [
            { name: "conversionType", label: "Conversion Type", unit: "", type: "select", options: ["polar_to_cartesian", "cartesian_to_polar"], required: true },
            { name: "x", label: "X coordinate", unit: "", type: "number" },
            { name: "y", label: "Y coordinate", unit: "", type: "number" },
            { name: "r", label: "Radius (r)", unit: "", type: "number", min: 0 },
            { name: "theta", label: "Angle (θ)", unit: "", type: "number" },
            { name: "angleUnit", label: "Angle Unit", unit: "", type: "select", options: ["degrees", "radians"], default: "degrees" }
          ],
          outputs: ["x", "y", "r", "theta", "steps"],
          validationRules: {
            minimumFields: 3,
            description: "Select conversion type and enter coordinates"
          }
        },
        usageCount: 7800,
        isActive: true,
        keywords: ["polar", "cartesian", "coordinates", "conversion", "radius", "angle"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Mathematics Calculators - Advanced Algebra
      {
        id: "matrix-determinant",
        title: "Matrix Determinant Calculator",
        description: "Calculate determinant of 2×2, 3×3, and 4×4 matrices",
        category: "mathematics",
        subcategory: "algebra",
        icon: "grid-3x3",
        formula: "det(A) = ad - bc (2×2), more complex for 3×3 and 4×4",
        variables: {
          inputs: [
            { name: "matrixSize", label: "Matrix Size", unit: "", type: "select", options: ["2x2", "3x3", "4x4"], required: true, default: "2x2" },
            { name: "matrixEntries", label: "Matrix Entries (row-wise, comma-separated)", unit: "", type: "text", required: true },
            { name: "calculationMethod", label: "Method", unit: "", type: "select", options: ["cofactor", "lu_decomposition"], default: "cofactor" }
          ],
          outputs: ["determinant", "steps", "matrixRank", "properties"],
          validationRules: {
            minimumFields: 2,
            description: "Select matrix size and enter entries separated by commas"
          }
        },
        usageCount: 8400,
        isActive: true,
        keywords: ["matrix", "determinant", "linear algebra", "cofactor", "rank"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "matrix-inverse",
        title: "Matrix Inverse Calculator",
        description: "Calculate inverse of 2×2 and 3×3 matrices using various methods",
        category: "mathematics",
        subcategory: "algebra",
        icon: "flip-horizontal",
        formula: "A⁻¹ = (1/det(A)) × adj(A)",
        variables: {
          inputs: [
            { name: "matrixSize", label: "Matrix Size", unit: "", type: "select", options: ["2x2", "3x3"], required: true, default: "2x2" },
            { name: "matrixEntries", label: "Matrix Entries (row-wise, comma-separated)", unit: "", type: "text", required: true },
            { name: "method", label: "Method", unit: "", type: "select", options: ["adjugate", "gauss_jordan", "lu_decomposition"], default: "adjugate" }
          ],
          outputs: ["inverseMatrix", "determinant", "steps", "verification"],
          validationRules: {
            minimumFields: 2,
            description: "Select matrix size and enter non-singular matrix entries"
          }
        },
        usageCount: 7200,
        isActive: true,
        keywords: ["matrix", "inverse", "adjugate", "gauss jordan", "singular"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "eigenvalues-eigenvectors",
        title: "Eigenvalues and Eigenvectors Calculator",
        description: "Find eigenvalues, eigenvectors, and diagonalization of matrices",
        category: "mathematics",
        subcategory: "algebra",
        icon: "target",
        formula: "Av = λv, det(A - λI) = 0",
        variables: {
          inputs: [
            { name: "matrixSize", label: "Matrix Size", unit: "", type: "select", options: ["2x2", "3x3"], required: true, default: "2x2" },
            { name: "matrixEntries", label: "Matrix Entries (row-wise, comma-separated)", unit: "", type: "text", required: true },
            { name: "precision", label: "Decimal Precision", unit: "", type: "number", min: 2, max: 10, default: 4 }
          ],
          outputs: ["eigenvalues", "eigenvectors", "characteristicPolynomial", "diagonalization"],
          validationRules: {
            minimumFields: 2,
            description: "Enter square matrix entries to find eigenvalues and eigenvectors"
          }
        },
        usageCount: 5900,
        isActive: true,
        keywords: ["eigenvalue", "eigenvector", "diagonalization", "characteristic", "polynomial"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "vector-operations",
        title: "Vector Operations Calculator",
        description: "Perform vector addition, subtraction, dot product, cross product, and more",
        category: "mathematics",
        subcategory: "algebra",
        icon: "move",
        formula: "a + b, a · b, a × b, |a|, proj_a(b)",
        variables: {
          inputs: [
            { name: "dimension", label: "Vector Dimension", unit: "", type: "select", options: ["2D", "3D"], required: true, default: "3D" },
            { name: "operation", label: "Operation", unit: "", type: "select", options: ["addition", "subtraction", "dot_product", "cross_product", "magnitude", "unit_vector", "projection"], required: true },
            { name: "vector1", label: "Vector 1 (comma-separated)", unit: "", type: "text", required: true },
            { name: "vector2", label: "Vector 2 (comma-separated)", unit: "", type: "text" },
            { name: "scalar", label: "Scalar (for scaling)", unit: "", type: "number" }
          ],
          outputs: ["result", "magnitude", "unitVector", "angle"],
          validationRules: {
            minimumFields: 3,
            description: "Select operation and enter vector components"
          }
        },
        usageCount: 9600,
        isActive: true,
        keywords: ["vector", "dot product", "cross product", "magnitude", "projection", "unit vector"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "complex-number-calculator",
        title: "Complex Number Calculator",
        description: "Perform operations on complex numbers: addition, multiplication, division, polar form",
        category: "mathematics",
        subcategory: "algebra",
        icon: "compass",
        formula: "z = a + bi, |z| = √(a² + b²), arg(z) = atan2(b,a)",
        variables: {
          inputs: [
            { name: "operation", label: "Operation", unit: "", type: "select", options: ["addition", "subtraction", "multiplication", "division", "magnitude", "argument", "conjugate", "polar_form", "rectangular_form"], required: true },
            { name: "real1", label: "Real part 1 (a)", unit: "", type: "number", required: true },
            { name: "imag1", label: "Imaginary part 1 (b)", unit: "", type: "number", required: true },
            { name: "real2", label: "Real part 2 (c)", unit: "", type: "number" },
            { name: "imag2", label: "Imaginary part 2 (d)", unit: "", type: "number" },
            { name: "modulus", label: "Modulus (r)", unit: "", type: "number", min: 0 },
            { name: "argument", label: "Argument (θ)", unit: "degrees", type: "number" }
          ],
          outputs: ["result", "magnitude", "argument", "conjugate", "polarForm"],
          validationRules: {
            minimumFields: 3,
            description: "Select operation and enter complex number components"
          }
        },
        usageCount: 6800,
        isActive: true,
        keywords: ["complex", "imaginary", "polar", "rectangular", "magnitude", "argument", "conjugate"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Mathematics Calculators - Statistics & Probability
      {
        id: "probability-calculator",
        title: "Probability Calculator",
        description: "Calculate basic probabilities, conditional probabilities, and probability distributions",
        category: "mathematics",
        subcategory: "statistics",
        icon: "pie-chart",
        formula: "P(A) = favorable/total, P(A|B) = P(A∩B)/P(B)",
        variables: {
          inputs: [
            { name: "calculationType", label: "Calculation Type", unit: "", type: "select", options: ["basic", "conditional", "binomial", "normal"], required: true },
            { name: "favorableOutcomes", label: "Favorable Outcomes", unit: "", type: "number", min: 0 },
            { name: "totalOutcomes", label: "Total Outcomes", unit: "", type: "number", min: 1 },
            { name: "trials", label: "Number of Trials (n)", unit: "", type: "number", min: 1 },
            { name: "successProbability", label: "Success Probability (p)", unit: "", type: "number", min: 0, max: 1 },
            { name: "successes", label: "Number of Successes (k)", unit: "", type: "number", min: 0 }
          ],
          outputs: ["probability", "complement", "odds", "percentage"],
          validationRules: {
            minimumFields: 2,
            description: "Select calculation type and enter relevant parameters"
          }
        },
        usageCount: 13400,
        isActive: true,
        keywords: ["probability", "conditional", "binomial", "normal", "odds", "statistics"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "permutations-combinations",
        title: "Permutations and Combinations Calculator",
        description: "Calculate permutations (nPr) and combinations (nCr) for counting problems",
        category: "mathematics",
        subcategory: "statistics",
        icon: "shuffle",
        formula: "nPr = n!/(n-r)!, nCr = n!/(r!(n-r)!)",
        variables: {
          inputs: [
            { name: "calculationType", label: "Calculation Type", unit: "", type: "select", options: ["permutation", "combination"], required: true },
            { name: "n", label: "Total items (n)", unit: "", type: "number", required: true, min: 0, max: 170 },
            { name: "r", label: "Selected items (r)", unit: "", type: "number", required: true, min: 0 },
            { name: "allowRepetition", label: "Allow Repetition", unit: "", type: "select", options: ["yes", "no"], default: "no" }
          ],
          outputs: ["result", "formula", "steps", "factorial"],
          validationRules: {
            minimumFields: 3,
            description: "Enter total items (n) and selected items (r), where r ≤ n"
          }
        },
        usageCount: 11700,
        isActive: true,
        keywords: ["permutation", "combination", "factorial", "counting", "arrangement"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "standard-deviation-variance",
        title: "Standard Deviation and Variance Calculator",
        description: "Calculate mean, variance, and standard deviation for population and sample data",
        category: "mathematics",
        subcategory: "statistics",
        icon: "trending-up",
        formula: "σ² = Σ(x-μ)²/N, σ = √σ², s² = Σ(x-x̄)²/(n-1)",
        variables: {
          inputs: [
            { name: "dataSet", label: "Data Set (comma-separated)", unit: "", type: "text", required: true },
            { name: "calculationType", label: "Type", unit: "", type: "select", options: ["population", "sample"], required: true, default: "sample" },
            { name: "precision", label: "Decimal Places", unit: "", type: "number", min: 1, max: 10, default: 4 }
          ],
          outputs: ["mean", "variance", "standardDeviation", "count", "range"],
          validationRules: {
            minimumFields: 2,
            description: "Enter data values separated by commas"
          }
        },
        usageCount: 15800,
        isActive: true,
        keywords: ["standard deviation", "variance", "mean", "population", "sample", "dispersion"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "z-score-calculator",
        title: "Z-Score Calculator",
        description: "Calculate z-scores, percentiles, and probabilities for normal distributions",
        category: "mathematics",
        subcategory: "statistics",
        icon: "bell",
        formula: "z = (x - μ) / σ",
        variables: {
          inputs: [
            { name: "calculationType", label: "Calculate", unit: "", type: "select", options: ["z_score", "percentile", "probability"], required: true },
            { name: "value", label: "Value (x)", unit: "", type: "number", required: true },
            { name: "mean", label: "Mean (μ)", unit: "", type: "number", required: true },
            { name: "standardDeviation", label: "Standard Deviation (σ)", unit: "", type: "number", required: true, min: 0 },
            { name: "zScore", label: "Z-Score", unit: "", type: "number" }
          ],
          outputs: ["zScore", "percentile", "probability", "area"],
          validationRules: {
            minimumFields: 4,
            description: "Enter value, mean, and standard deviation for normal distribution"
          }
        },
        usageCount: 9600,
        isActive: true,
        keywords: ["z-score", "normal distribution", "percentile", "probability", "standard normal"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "t-test-calculator",
        title: "t-Test Calculator",
        description: "Perform one-sample, two-sample, and paired t-tests for hypothesis testing",
        category: "mathematics",
        subcategory: "statistics",
        icon: "chart",
        formula: "t = (x̄ - μ) / (s/√n), t = (x̄₁ - x̄₂) / sp√(1/n₁ + 1/n₂)",
        variables: {
          inputs: [
            { name: "testType", label: "Test Type", unit: "", type: "select", options: ["one_sample", "two_sample", "paired"], required: true },
            { name: "sampleMean", label: "Sample Mean (x̄)", unit: "", type: "number", required: true },
            { name: "populationMean", label: "Population Mean (μ)", unit: "", type: "number" },
            { name: "sampleStdDev", label: "Sample Std Dev (s)", unit: "", type: "number", min: 0 },
            { name: "sampleSize", label: "Sample Size (n)", unit: "", type: "number", required: true, min: 1 },
            { name: "confidenceLevel", label: "Confidence Level", unit: "%", type: "number", default: 95, min: 80, max: 99.9 }
          ],
          outputs: ["tStatistic", "pValue", "criticalValue", "confidenceInterval"],
          validationRules: {
            minimumFields: 4,
            description: "Enter sample statistics for t-test calculation"
          }
        },
        usageCount: 6400,
        isActive: true,
        keywords: ["t-test", "hypothesis testing", "confidence interval", "p-value", "statistics"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "anova-calculator",
        title: "ANOVA Calculator",
        description: "Perform one-way Analysis of Variance (ANOVA) to compare multiple groups",
        category: "mathematics",
        subcategory: "statistics",
        icon: "box-plot",
        formula: "F = MSB/MSW, where MSB = SSB/df_between, MSW = SSW/df_within",
        variables: {
          inputs: [
            { name: "groups", label: "Number of Groups", unit: "", type: "number", required: true, min: 2, max: 10 },
            { name: "groupData", label: "Group Data (each group on new line)", unit: "", type: "textarea", required: true },
            { name: "confidenceLevel", label: "Confidence Level", unit: "%", type: "number", default: 95, min: 80, max: 99.9 },
            { name: "anovaType", label: "ANOVA Type", unit: "", type: "select", options: ["one_way"], default: "one_way" }
          ],
          outputs: ["fStatistic", "pValue", "criticalValue", "summaryTable"],
          validationRules: {
            minimumFields: 2,
            description: "Enter data for each group (comma-separated values, one group per line)"
          }
        },
        usageCount: 4200,
        isActive: true,
        keywords: ["anova", "analysis of variance", "f-test", "multiple groups", "statistics"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "probability-distributions",
        title: "Probability Distributions Calculator",
        description: "Calculate probabilities and statistics for various probability distributions",
        category: "mathematics",
        subcategory: "statistics",
        icon: "curve",
        formula: "Various: Normal, Binomial, Poisson, Exponential, etc.",
        variables: {
          inputs: [
            { name: "distribution", label: "Distribution", unit: "", type: "select", options: ["normal", "binomial", "poisson", "exponential", "uniform"], required: true },
            { name: "parameter1", label: "Parameter 1", unit: "", type: "number", required: true },
            { name: "parameter2", label: "Parameter 2", unit: "", type: "number" },
            { name: "xValue", label: "X Value", unit: "", type: "number", required: true },
            { name: "calculationType", label: "Calculate", unit: "", type: "select", options: ["pdf", "cdf", "quantile"], required: true }
          ],
          outputs: ["result", "mean", "variance", "standardDeviation"],
          validationRules: {
            minimumFields: 4,
            description: "Select distribution, enter parameters, and specify calculation type"
          }
        },
        usageCount: 7800,
        isActive: true,
        keywords: ["probability distribution", "normal", "binomial", "poisson", "pdf", "cdf"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "correlation-coefficient",
        title: "Correlation Coefficient Calculator",
        description: "Calculate Pearson correlation coefficient and determine relationship strength",
        category: "mathematics",
        subcategory: "statistics",
        icon: "trending-up",
        formula: "r = Σ[(xi-x̄)(yi-ȳ)] / √[Σ(xi-x̄)²Σ(yi-ȳ)²]",
        variables: {
          inputs: [
            { name: "xValues", label: "X Values (comma-separated)", unit: "", type: "text", required: true },
            { name: "yValues", label: "Y Values (comma-separated)", unit: "", type: "text", required: true },
            { name: "correlationType", label: "Correlation Type", unit: "", type: "select", options: ["pearson", "spearman"], default: "pearson" },
            { name: "significanceLevel", label: "Significance Level", unit: "", type: "number", default: 0.05, min: 0.01, max: 0.1 }
          ],
          outputs: ["correlationCoefficient", "pValue", "significance", "interpretation"],
          validationRules: {
            minimumFields: 2,
            description: "Enter paired X and Y values (same number of values in each set)"
          }
        },
        usageCount: 8900,
        isActive: true,
        keywords: ["correlation", "pearson", "relationship", "linear", "association"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "linear-regression",
        title: "Linear Regression Calculator",
        description: "Perform linear regression analysis and calculate line of best fit",
        category: "mathematics",
        subcategory: "statistics",
        icon: "line-chart",
        formula: "y = mx + b, where m = Σ[(xi-x̄)(yi-ȳ)] / Σ(xi-x̄)²",
        variables: {
          inputs: [
            { name: "xValues", label: "X Values (comma-separated)", unit: "", type: "text", required: true },
            { name: "yValues", label: "Y Values (comma-separated)", unit: "", type: "text", required: true },
            { name: "confidenceLevel", label: "Confidence Level", unit: "%", type: "number", default: 95, min: 80, max: 99.9 },
            { name: "predictValue", label: "X Value to Predict", unit: "", type: "number" }
          ],
          outputs: ["slope", "intercept", "rSquared", "equation", "prediction"],
          validationRules: {
            minimumFields: 2,
            description: "Enter paired X and Y values for regression analysis"
          }
        },
        usageCount: 10300,
        isActive: true,
        keywords: ["linear regression", "line of best fit", "slope", "intercept", "r-squared"],
        createdAt: new Date(),
        updatedAt: new Date()
      },

      // Mathematics Calculators - Calculus & Transforms
      {
        id: "derivative-calculator",
        title: "Derivative Calculator",
        description: "Calculate derivatives of functions using various differentiation rules",
        category: "mathematics",
        subcategory: "calculus",
        icon: "trending-up",
        formula: "f'(x), d/dx, power rule, product rule, quotient rule, chain rule",
        variables: {
          inputs: [
            { name: "function", label: "Function f(x)", unit: "", type: "text", required: true },
            { name: "variable", label: "Variable", unit: "", type: "select", options: ["x", "t", "u", "y"], default: "x" },
            { name: "derivativeOrder", label: "Derivative Order", unit: "", type: "number", min: 1, max: 5, default: 1 },
            { name: "evaluateAt", label: "Evaluate at point", unit: "", type: "number" }
          ],
          outputs: ["derivative", "steps", "simplified", "evaluation"],
          validationRules: {
            minimumFields: 2,
            description: "Enter a mathematical function to differentiate"
          }
        },
        usageCount: 16800,
        isActive: true,
        keywords: ["derivative", "differentiation", "calculus", "power rule", "chain rule", "slope"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "integral-calculator",
        title: "Integral Calculator",
        description: "Calculate definite and indefinite integrals using various integration techniques",
        category: "mathematics",
        subcategory: "calculus",
        icon: "area-chart",
        formula: "∫f(x)dx, ∫[a to b]f(x)dx, integration by parts, substitution",
        variables: {
          inputs: [
            { name: "function", label: "Function f(x)", unit: "", type: "text", required: true },
            { name: "variable", label: "Variable", unit: "", type: "select", options: ["x", "t", "u", "y"], default: "x" },
            { name: "integralType", label: "Type", unit: "", type: "select", options: ["indefinite", "definite"], required: true },
            { name: "lowerLimit", label: "Lower Limit (a)", unit: "", type: "number" },
            { name: "upperLimit", label: "Upper Limit (b)", unit: "", type: "number" },
            { name: "method", label: "Method", unit: "", type: "select", options: ["automatic", "substitution", "parts", "partial_fractions"], default: "automatic" }
          ],
          outputs: ["integral", "steps", "area", "evaluation"],
          validationRules: {
            minimumFields: 3,
            description: "Enter function and specify integral type"
          }
        },
        usageCount: 14500,
        isActive: true,
        keywords: ["integral", "integration", "calculus", "area", "antiderivative", "definite", "indefinite"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "limit-calculator",
        title: "Limit Calculator",
        description: "Calculate limits of functions as x approaches a value or infinity",
        category: "mathematics",
        subcategory: "calculus",
        icon: "target",
        formula: "lim(x→a) f(x), lim(x→∞) f(x), L'Hôpital's rule",
        variables: {
          inputs: [
            { name: "function", label: "Function f(x)", unit: "", type: "text", required: true },
            { name: "variable", label: "Variable", unit: "", type: "select", options: ["x", "t", "u", "y"], default: "x" },
            { name: "approachValue", label: "Approaches", unit: "", type: "text", required: true, placeholder: "e.g., 0, infinity, -infinity" },
            { name: "direction", label: "Direction", unit: "", type: "select", options: ["both", "left", "right"], default: "both" },
            { name: "method", label: "Method", unit: "", type: "select", options: ["automatic", "lhopital", "substitution", "factoring"], default: "automatic" }
          ],
          outputs: ["limit", "steps", "leftLimit", "rightLimit"],
          validationRules: {
            minimumFields: 3,
            description: "Enter function and the value it approaches"
          }
        },
        usageCount: 11200,
        isActive: true,
        keywords: ["limit", "calculus", "infinity", "lhopital", "continuity", "asymptote"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "series-sequence-calculator",
        title: "Series and Sequence Calculator",
        description: "Calculate sequences, series convergence, Taylor series, and Fourier series",
        category: "mathematics",
        subcategory: "calculus",
        icon: "list",
        formula: "aₙ, Σaₙ, Taylor series, geometric series, p-series",
        variables: {
          inputs: [
            { name: "calculationType", label: "Type", unit: "", type: "select", options: ["arithmetic_sequence", "geometric_sequence", "series_sum", "taylor_series", "convergence"], required: true },
            { name: "formula", label: "Formula/Function", unit: "", type: "text", required: true },
            { name: "firstTerm", label: "First Term (a₁)", unit: "", type: "number" },
            { name: "commonDifference", label: "Common Difference (d)", unit: "", type: "number" },
            { name: "commonRatio", label: "Common Ratio (r)", unit: "", type: "number" },
            { name: "nTerms", label: "Number of Terms (n)", unit: "", type: "number", min: 1, max: 1000 },
            { name: "centerPoint", label: "Center Point (for Taylor)", unit: "", type: "number", default: 0 }
          ],
          outputs: ["result", "convergence", "sum", "terms"],
          validationRules: {
            minimumFields: 2,
            description: "Select type and enter sequence/series parameters"
          }
        },
        usageCount: 8900,
        isActive: true,
        keywords: ["series", "sequence", "taylor", "convergence", "sum", "geometric", "arithmetic"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "fourier-transform",
        title: "Fourier Transform Calculator",
        description: "Calculate Fourier transform and inverse Fourier transform of functions",
        category: "mathematics",
        subcategory: "calculus",
        icon: "sine-wave",
        formula: "F(ω) = ∫f(t)e^(-iωt)dt, f(t) = (1/2π)∫F(ω)e^(iωt)dω",
        variables: {
          inputs: [
            { name: "function", label: "Function f(t)", unit: "", type: "text", required: true },
            { name: "transformType", label: "Transform Type", unit: "", type: "select", options: ["fourier", "inverse_fourier", "discrete_fourier"], required: true },
            { name: "variable", label: "Variable", unit: "", type: "select", options: ["t", "x", "n"], default: "t" },
            { name: "frequencyVariable", label: "Frequency Variable", unit: "", type: "select", options: ["ω", "f", "k"], default: "ω" },
            { name: "samplingRate", label: "Sampling Rate (for DFT)", unit: "Hz", type: "number", min: 1 }
          ],
          outputs: ["transform", "magnitude", "phase", "steps"],
          validationRules: {
            minimumFields: 3,
            description: "Enter function and select transform type"
          }
        },
        usageCount: 5400,
        isActive: true,
        keywords: ["fourier", "transform", "frequency", "spectrum", "signal", "dft", "fft"],
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "laplace-transform",
        title: "Laplace Transform Calculator",
        description: "Calculate Laplace transform and inverse Laplace transform of functions",
        category: "mathematics",
        subcategory: "calculus",
        icon: "arrow-right",
        formula: "L{f(t)} = F(s) = ∫₀^∞ f(t)e^(-st)dt",
        variables: {
          inputs: [
            { name: "function", label: "Function f(t)", unit: "", type: "text", required: true },
            { name: "transformType", label: "Transform Type", unit: "", type: "select", options: ["laplace", "inverse_laplace"], required: true },
            { name: "variable", label: "Time Variable", unit: "", type: "select", options: ["t", "x"], default: "t" },
            { name: "frequencyVariable", label: "Complex Variable", unit: "", type: "select", options: ["s", "z"], default: "s" },
            { name: "initialConditions", label: "Initial Conditions", unit: "", type: "text", placeholder: "e.g., f(0)=1, f'(0)=0" }
          ],
          outputs: ["transform", "steps", "properties", "applications"],
          validationRules: {
            minimumFields: 3,
            description: "Enter function and select transform type"
          }
        },
        usageCount: 4700,
        isActive: true,
        keywords: ["laplace", "transform", "differential equations", "control", "circuit", "inverse"],
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];

    sampleCalculators.forEach(calc => {
      this.calculators.set(calc.id, calc);
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCalculators(category?: string): Promise<Calculator[]> {
    const calculators = Array.from(this.calculators.values()).filter(calc => calc.isActive);
    if (category) {
      return calculators.filter(calc => calc.category === category);
    }
    return calculators;
  }

  async getCalculator(id: string): Promise<Calculator | undefined> {
    return this.calculators.get(id);
  }

  async createCalculator(calculator: InsertCalculator): Promise<Calculator> {
    const id = randomUUID();
    const newCalculator: Calculator = {
      ...calculator,
      id,
      formula: calculator.formula || null,
      keywords: calculator.keywords || null,
      usageCount: 0,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.calculators.set(id, newCalculator);
    return newCalculator;
  }

  async updateCalculatorUsage(id: string): Promise<void> {
    const calculator = this.calculators.get(id);
    if (calculator) {
      calculator.usageCount = (calculator.usageCount || 0) + 1;
      calculator.updatedAt = new Date();
      this.calculators.set(id, calculator);
    }
  }

  async searchCalculators(query: string): Promise<Calculator[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.calculators.values()).filter(calc => 
      calc.isActive && (
        calc.title.toLowerCase().includes(searchTerm) ||
        calc.description.toLowerCase().includes(searchTerm) ||
        calc.keywords?.some(keyword => keyword.toLowerCase().includes(searchTerm))
      )
    );
  }

  async createCalculatorResult(result: InsertCalculatorResult): Promise<CalculatorResult> {
    const id = randomUUID();
    const newResult: CalculatorResult = {
      ...result,
      id,
      steps: result.steps || null,
      createdAt: new Date()
    };
    this.calculatorResults.set(id, newResult);
    return newResult;
  }

  async getCalculatorResults(calculatorId: string): Promise<CalculatorResult[]> {
    return Array.from(this.calculatorResults.values()).filter(
      result => result.calculatorId === calculatorId
    );
  }
}

export const storage = new MemStorage();
