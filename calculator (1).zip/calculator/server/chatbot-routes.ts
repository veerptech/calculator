import { Request, Response } from "express";
import { z } from "zod";
import { ChatbotService } from "./chatbot-service";

const ChatMessageSchema = z.object({
  message: z.string().min(1).max(500),
});

export function setupChatbotRoutes(app: any) {
  // Chatbot message endpoint
  app.post("/api/chatbot/message", async (req: Request, res: Response) => {
    try {
      const { message } = ChatMessageSchema.parse(req.body);
      
      const response = ChatbotService.processMessage(message);
      
      res.json({
        success: true,
        response
      });
    } catch (error) {
      console.error("Chatbot error:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          error: "Invalid message format",
          details: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        error: "Failed to process message",
        response: {
          message: "Sorry, I'm having trouble right now. Please try again later! 🤖",
          needsClarification: true
        }
      });
    }
  });

  // Get available calculators for suggestions
  app.get("/api/chatbot/calculators", async (req: Request, res: Response) => {
    try {
      const calculatorsBySubject = {
        physics: ["Projectile Motion", "Kinematics", "Ohm's Law", "Wave Speed", "Lens Formula"],
        chemistry: ["Molarity", "pH Calculator", "Dilution", "Molecular Weight", "Gas Laws"],
        biology: ["BMI Calculator", "BMR Calculator", "Body Surface Area", "DNA Concentration"],
        math: ["Quadratic Equation", "Standard Deviation", "Probability", "Trigonometry"]
      };
      
      res.json({
        success: true,
        calculators: calculatorsBySubject
      });
    } catch (error) {
      console.error("Chatbot calculators error:", error);
      res.status(500).json({
        success: false,
        error: "Failed to get calculator suggestions"
      });
    }
  });
}