import { useState, useMemo, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Calculator } from "@shared/schema";
import { SEOHead } from "@/components/seo-head";
import { CategorySidebar } from "@/components/category-sidebar";
import { MobileNav } from "@/components/ui/mobile-nav";
import { MainNavigation } from "@/components/main-navigation";
import { Footer } from "@/components/footer";
import { calculatorCategories } from "@/lib/calculators";

export default function CategoryPage() {
  const [match, params] = useRoute("/category/:categoryId?");
  const [, navigate] = useLocation();
  const initialCategory = params?.categoryId || "all";
  
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);

  // Sync state with route parameters when they change
  useEffect(() => {
    const newCategory = params?.categoryId || "all";
    setSelectedCategory(newCategory);
    setSelectedSubcategory(null);
  }, [params?.categoryId]);

  const { data: calculators = [], isLoading } = useQuery<Calculator[]>({
    queryKey: ["/api/calculators"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const handleCalculatorClick = (calculator: Calculator) => {
    // Navigate to calculator page using SPA routing
    navigate(`/calculator/${calculator.id}`);
  };

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setSelectedSubcategory(null);
    // Navigate to category URL using SPA routing
    const url = categoryId === "all" ? "/category" : `/category/${categoryId}`;
    navigate(url, { replace: true });
  };

  const handleSubcategorySelect = (categoryId: string, subcategoryId: string) => {
    setSelectedCategory(categoryId);
    setSelectedSubcategory(subcategoryId);
    // Navigate to category URL using SPA routing
    navigate(`/category/${categoryId}`, { replace: true });
  };

  const currentCategoryName = useMemo(() => {
    if (selectedCategory === "all") return "All Categories";
    return calculatorCategories.find(c => c.id === selectedCategory)?.name || "Category";
  }, [selectedCategory]);

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": `${currentCategoryName} Calculators - Science Calculators Hub`,
    "description": `Browse ${currentCategoryName.toLowerCase()} calculators with step-by-step solutions`,
    "url": typeof window !== 'undefined' ? window.location.href : '',
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="flex items-center justify-center h-screen">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
            <p>Loading calculators...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <MainNavigation />
      <SEOHead
        title={`${currentCategoryName} Calculators - Science Calculators Hub`}
        description={`Browse ${currentCategoryName.toLowerCase()} calculators with step-by-step solutions and detailed explanations.`}
        keywords={`${currentCategoryName.toLowerCase()} calculator, science calculator, math calculator, physics calculator, chemistry calculator, biology calculator`}
        canonicalUrl={typeof window !== 'undefined' ? window.location.href : ''}
        structuredData={structuredData}
      />

      {/* Mobile Navigation for Category/Subcategory Selection */}
      <div className="md:hidden p-4 border-b">
        <MobileNav
          selectedCategory={selectedCategory}
          selectedSubcategory={selectedSubcategory}
          onCategorySelect={handleCategorySelect}
          onSubcategorySelect={handleSubcategorySelect}
          calculators={calculators}
        />
      </div>

      {/* Main Content with Sidebar */}
      <div className="hidden md:block h-[calc(100vh-4rem)]">
        <CategorySidebar
          selectedCategory={selectedCategory}
          selectedSubcategory={selectedSubcategory}
          onCategorySelect={handleCategorySelect}
          onSubcategorySelect={handleSubcategorySelect}
          onCalculatorClick={handleCalculatorClick}
          calculators={calculators}
        />
      </div>

      {/* Mobile Content - Simplified grid view */}
      <div className="md:hidden">
        <div className="p-4">
          <div className="mb-6">
            <h1 className="text-2xl font-bold mb-2">{currentCategoryName}</h1>
            <p className="text-muted-foreground">
              {(() => {
                const filteredCount = calculators.filter(calc => 
                  selectedCategory === "all" || 
                  (selectedSubcategory 
                    ? calc.category === selectedCategory && calc.subcategory === selectedSubcategory
                    : calc.category === selectedCategory)
                ).length;
                return `${filteredCount} calculator${filteredCount !== 1 ? 's' : ''} available`;
              })()}
            </p>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            {calculators
              .filter(calc => 
                selectedCategory === "all" || 
                (selectedSubcategory 
                  ? calc.category === selectedCategory && calc.subcategory === selectedSubcategory
                  : calc.category === selectedCategory)
              )
              .map(calculator => (
                <div
                  key={calculator.id}
                  className="border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => handleCalculatorClick(calculator)}
                >
                  <h3 className="font-semibold mb-2">{calculator.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{calculator.description}</p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{calculator.category}</span>
                    <span>{calculator.usageCount || 0} uses</span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}