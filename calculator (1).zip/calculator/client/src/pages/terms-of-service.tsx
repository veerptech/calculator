import { SEOHead } from "@/components/seo-head";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Terms of Service - Science Calculators Hub"
        description="Terms of Service for Science Calculators Hub - Legal terms and conditions for using our calculator services."
        keywords="terms of service, legal terms, conditions, calculator usage"
        canonicalUrl={`${window.location.origin}/terms-of-service`}
      />

      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <div className="flex h-16 items-center">
            <Button variant="ghost" asChild>
              <a href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </a>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 lg:px-8 max-w-4xl py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl font-bold">Terms of Service</CardTitle>
            <p className="text-muted-foreground">Last updated: {new Date().toLocaleDateString()}</p>
          </CardHeader>
          <CardContent className="prose prose-gray max-w-none dark:prose-invert">
            <div className="space-y-6">
              <section>
                <h2 className="text-2xl font-semibold mb-4">1. Acceptance of Terms</h2>
                <p className="mb-4">
                  By accessing and using Science Calculators Hub ("Service"), you accept and agree to be bound by the terms and provision of this agreement.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">2. Description of Service</h2>
                <p className="mb-4">
                  Science Calculators Hub provides online scientific calculators for physics, chemistry, biology, and mathematics. Our service includes:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Free access to scientific calculators</li>
                  <li>Step-by-step solutions and explanations</li>
                  <li>AI-powered assistance and recommendations</li>
                  <li>Educational content and study tips</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">3. User Responsibilities</h2>
                <p className="mb-4">You agree to:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Use the service for lawful purposes only</li>
                  <li>Not attempt to interfere with the service's functionality</li>
                  <li>Not use automated systems to access the service</li>
                  <li>Respect intellectual property rights</li>
                  <li>Use calculators for educational and legitimate purposes</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">4. Accuracy of Calculations</h2>
                <p className="mb-4">
                  While we strive to provide accurate calculations, we do not guarantee the accuracy, completeness, or reliability of any calculations or results. Users should verify important calculations independently.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">5. Intellectual Property</h2>
                <p className="mb-4">
                  The service and its original content, features, and functionality are owned by Science Calculators Hub and are protected by international copyright, trademark, and other intellectual property laws.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">6. Limitation of Liability</h2>
                <p className="mb-4">
                  In no event shall Science Calculators Hub be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of the service.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">7. Service Availability</h2>
                <p className="mb-4">
                  We strive to maintain service availability but do not guarantee uninterrupted access. We reserve the right to modify or discontinue the service at any time.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">8. Changes to Terms</h2>
                <p className="mb-4">
                  We reserve the right to update these terms at any time. Changes will be effective immediately upon posting to the website.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">9. Contact Information</h2>
                <p className="mb-4">
                  If you have questions about these Terms of Service, please contact us through our <a href="/contact" className="text-primary hover:underline">Contact Us</a> page.
                </p>
              </section>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}