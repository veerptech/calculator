import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Calculator } from "@shared/schema";
import { SEOHead } from "@/components/seo-head";
import { SearchBar } from "@/components/search-bar";
import { CalculatorCard } from "@/components/calculator-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { calculatorCategories, subcategories } from "@/lib/calculators";
import { MainNavigation } from "@/components/main-navigation";
import { Footer } from "@/components/footer";
import { HeaderAd, SidebarAd, FooterAd, MobileAd, ContentAd } from "@/components/ad-placement";
import { 
  Calculator as CalculatorIcon, 
  Users, 
  BookOpen, 
  Zap, 
  Shield, 
  Smartphone,
  Atom,
  FlaskConical,
  SquareFunction,
  Dna,
  Rocket,
  Globe,
  Eye,
  Zap as Bolt,
  Fuel,
  Droplet,
  Thermometer,
  Battery,
  TestTube,
  Plus,
  Triangle,
  Activity,
  TrendingUp,
  Infinity,
  Heart,
  Microscope,
  Stethoscope,
  Leaf
} from "lucide-react";

// Helper function to get category icons
function getCategoryIcon(iconName: string, className: string = "h-4 w-4") {
  const iconMap: Record<string, React.ReactNode> = {
    atom: <Atom className={className} />,
    flask: <FlaskConical className={className} />,
    "square-root-alt": <SquareFunction className={className} />,
    dna: <Dna className={className} />,
    calculator: <CalculatorIcon className={className} />,
  };
  
  return iconMap[iconName] || <CalculatorIcon className={className} />;
}

// Helper function to get subcategory icons
function getSubcategoryIcon(iconName: string, className: string = "h-4 w-4") {
  const iconMap: Record<string, React.ReactNode> = {
    rocket: <Rocket className={className} />,
    globe: <Globe className={className} />,
    "wave-square": <Activity className={className} />,
    eye: <Eye className={className} />,
    bolt: <Bolt className={className} />,
    atom: <Atom className={className} />,
    flask: <FlaskConical className={className} />,
    "gas-pump": <Fuel className={className} />,
    tint: <Droplet className={className} />,
    "thermometer-half": <Thermometer className={className} />,
    battery: <Battery className={className} />,
    vial: <TestTube className={className} />,
    calculator: <CalculatorIcon className={className} />,
    shapes: <Triangle className={className} />,
    function: <Plus className={className} />,
    "chart-line": <TrendingUp className={className} />,
    infinity: <Infinity className={className} />,
    heartbeat: <Heart className={className} />,
    microscope: <Microscope className={className} />,
    dna: <Dna className={className} />,
    stethoscope: <Stethoscope className={className} />,
    seedling: <Leaf className={className} />,
  };
  
  return iconMap[iconName] || <CalculatorIcon className={className} />;
}

export default function Home() {
  const [, navigate] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: calculators = [], isLoading } = useQuery<Calculator[]>({
    queryKey: ["/api/calculators"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const filteredCalculators = useMemo(() => {
    let filtered = calculators;

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter(calc => calc.category === selectedCategory);
    }

    // Filter by subcategory
    if (selectedSubcategory) {
      filtered = filtered.filter(calc => calc.subcategory === selectedSubcategory);
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(calc => 
        calc.title.toLowerCase().includes(query) ||
        calc.description.toLowerCase().includes(query) ||
        calc.keywords?.some(keyword => keyword.toLowerCase().includes(query))
      );
    }

    return filtered;
  }, [calculators, selectedCategory, selectedSubcategory, searchQuery]);

  const groupedCalculators = useMemo(() => {
    const grouped: Record<string, Calculator[]> = {};
    
    filteredCalculators.forEach(calc => {
      if (!grouped[calc.category]) {
        grouped[calc.category] = [];
      }
      grouped[calc.category].push(calc);
    });

    return grouped;
  }, [filteredCalculators]);

  const handleCalculatorClick = (calculator: Calculator) => {
    // Navigate to calculator page using SPA routing
    navigate(`/calculator/${calculator.id}`);
  };

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setSelectedSubcategory(null);
  };

  const handleSubcategorySelect = (categoryId: string, subcategoryId: string) => {
    setSelectedCategory(categoryId);
    setSelectedSubcategory(subcategoryId);
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    "name": "Science Calculators Hub",
    "applicationCategory": "EducationalApplication",
    "description": "Free online calculators for physics, chemistry, mathematics, and biology with step-by-step solutions",
    "url": typeof window !== 'undefined' ? window.location.origin : '',
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.8",
      "reviewCount": "15000"
    }
  };

  const stats = {
    physicsCalculators: calculators.filter(c => c.category === "physics").length,
    chemistryCalculators: calculators.filter(c => c.category === "chemistry").length,
    mathCalculators: calculators.filter(c => c.category === "math").length,
    biologyCalculators: calculators.filter(c => c.category === "biology").length,
  };

  return (
    <div className="min-h-screen bg-background">
      <MainNavigation />
      <SEOHead
        title="Science Calculators Hub - Physics, Chemistry, Math & Biology Calculators | Free Online Tools"
        description="Free online calculators for physics, chemistry, mathematics, and biology. Calculate molarity, solve physics problems, perform statistical analysis, and more. Step-by-step solutions included."
        keywords="physics calculator, chemistry calculator, math calculator, biology calculator, molarity calculator, pH calculator, kinematic equations, stoichiometry, calculus calculator, statistics calculator, genetics calculator"
        canonicalUrl={typeof window !== 'undefined' ? window.location.origin : ''}
        structuredData={structuredData}
      />


      {/* Hero Section */}
      <section className="py-12 lg:py-20 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Free Scientific Calculators
            </h1>
            <p className="text-xl lg:text-2xl text-muted-foreground mb-8 leading-relaxed">
              Comprehensive collection of physics, chemistry, mathematics, and biology calculators with step-by-step solutions. Perfect for students, teachers, and professionals.
            </p>
            
            {/* Search Bar */}
            <SearchBar
              onSearch={setSearchQuery}
              onSelectCalculator={handleCalculatorClick}
              className="mb-8"
            />

            {/* Quick Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary" data-testid="physics-count">
                  {stats.physicsCalculators}+
                </div>
                <div className="text-sm text-muted-foreground">Physics Calculators</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-secondary" data-testid="chemistry-count">
                  {stats.chemistryCalculators}+
                </div>
                <div className="text-sm text-muted-foreground">Chemistry Tools</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent" data-testid="math-count">
                  {stats.mathCalculators}+
                </div>
                <div className="text-sm text-muted-foreground">Math Calculators</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary" data-testid="biology-count">
                  {stats.biologyCalculators}+
                </div>
                <div className="text-sm text-muted-foreground">Biology Tools</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Header Ad */}
      <HeaderAd className="my-4" />

      {/* Category & Subcategory Navigation */}
      <section className="py-8 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          {/* All Calculators Button */}
          <div className="mb-6 text-center">
            <Button
              variant={selectedCategory === "all" ? "default" : "outline"}
              onClick={() => handleCategorySelect("all")}
              className="px-8 py-3 text-lg"
              data-testid="filter-all"
            >
              <CalculatorIcon className="mr-2 h-5 w-5" />
              All Calculators
            </Button>
          </div>

          {/* Category Tabs */}
          <Tabs value={selectedCategory} onValueChange={handleCategorySelect} className="w-full">
            <div className="flex justify-center mb-6">
              <TabsList className="grid grid-cols-5 w-full max-w-3xl">
                <TabsTrigger 
                  value="all"
                  className="flex items-center gap-2"
                  data-testid="category-tab-all"
                >
                  <CalculatorIcon className="h-4 w-4" />
                  <span className="hidden sm:inline">All</span>
                </TabsTrigger>
                {calculatorCategories.map(category => (
                  <TabsTrigger 
                    key={category.id} 
                    value={category.id}
                    className="flex items-center gap-2"
                    data-testid={`category-tab-${category.id}`}
                  >
                    {getCategoryIcon(category.icon)}
                    <span className="hidden sm:inline">{category.name}</span>
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            {/* All Categories Tab Content */}
            <TabsContent value="all" className="mt-0">
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-2xl font-semibold mb-2 flex items-center justify-center">
                    <CalculatorIcon className="mr-3 h-6 w-6" />
                    All Calculators
                  </h3>
                  <p className="text-muted-foreground">
                    {calculators.length} calculators available across all categories
                  </p>
                </div>
                <MobileAd />
                <ContentAd />
              </div>
            </TabsContent>

            {/* Subcategory Tabs for Each Category */}
            {calculatorCategories.map(category => (
              <TabsContent key={category.id} value={category.id} className="mt-0">
                <div className="space-y-6">
                  <div className="text-center">
                    <h3 className="text-2xl font-semibold mb-2 flex items-center justify-center">
                      {getCategoryIcon(category.icon, "mr-3 h-6 w-6")}
                      {category.name} Calculators
                    </h3>
                    <p className="text-muted-foreground">
                      {calculators.filter(c => c.category === category.id).length} calculators available
                    </p>
                  </div>

                  {/* Mobile Ad */}
                  <MobileAd />

                  {/* Subcategory Tabs */}
                  <div className="flex flex-wrap justify-center gap-2 mb-6">
                    <Button
                      variant={!selectedSubcategory ? "default" : "outline"}
                      onClick={() => setSelectedSubcategory(null)}
                      className="mb-2"
                      data-testid={`all-${category.id}`}
                    >
                      All {category.name}
                    </Button>
                    {subcategories[category.id as keyof typeof subcategories]?.map(subcategory => {
                      const subcategoryCount = calculators.filter(c => 
                        c.category === category.id && c.subcategory === subcategory.id
                      ).length;
                      
                      return (
                        <Button
                          key={subcategory.id}
                          variant={selectedSubcategory === subcategory.id ? "default" : "outline"}
                          onClick={() => handleSubcategorySelect(category.id, subcategory.id)}
                          className="mb-2 relative"
                          data-testid={`subcategory-${category.id}-${subcategory.id}`}
                        >
                          {getSubcategoryIcon(subcategory.icon, "mr-2 h-4 w-4")}
                          {subcategory.name}
                          <span className="ml-2 text-xs bg-muted px-2 py-1 rounded-full">
                            {subcategoryCount}
                          </span>
                        </Button>
                      );
                    })}
                  </div>

                  {/* Content Ad */}
                  <ContentAd />
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      {/* Featured Calculators Grid */}
      <section id="calculators" className="py-16">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Main Content */}
            <div className="flex-1">
              <h2 className="text-3xl font-bold text-center mb-12">
                {selectedCategory === "all" 
                  ? "Popular Calculators" 
                  : selectedSubcategory 
                    ? `${subcategories[selectedCategory as keyof typeof subcategories]?.find(s => s.id === selectedSubcategory)?.name} Calculators`
                    : `${calculatorCategories.find(c => c.id === selectedCategory)?.name} Calculators`
                }
              </h2>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-48 bg-muted rounded-lg animate-pulse"></div>
              ))}
            </div>
          ) : selectedCategory === "all" ? (
            // Show all categories with grouping
            Object.entries(groupedCalculators).map(([category, categoryCalculators]) => (
              <div key={category} id={category} className="mb-16">
                <h3 className="text-2xl font-semibold mb-8 flex items-center">
                  {getCategoryIcon(calculatorCategories.find(c => c.id === category)?.icon || 'calculator', `mr-3 h-6 w-6 text-${getCategoryColor(category)}`)}
                  {calculatorCategories.find(c => c.id === category)?.name} Calculators
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {categoryCalculators.slice(0, 8).map(calculator => (
                    <CalculatorCard
                      key={calculator.id}
                      calculator={calculator}
                      onClick={handleCalculatorClick}
                    />
                  ))}
                </div>
                {categoryCalculators.length > 8 && (
                  <div className="text-center mt-6">
                    <Button variant="outline" asChild>
                      <Link href={`/category/${category}`}>
                        View All {calculatorCategories.find(c => c.id === category)?.name} Calculators
                      </Link>
                    </Button>
                  </div>
                )}
              </div>
            ))
          ) : (
            // Show single category
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredCalculators.map(calculator => (
                <CalculatorCard
                  key={calculator.id}
                  calculator={calculator}
                  onClick={handleCalculatorClick}
                />
              ))}
            </div>
          )}

          {filteredCalculators.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold mb-2">No calculators found</h3>
              <p className="text-muted-foreground">Try adjusting your search or category filter</p>
            </div>
          )}
          </div>

          {/* Sidebar with Ads */}
          <div className="hidden lg:block lg:w-80 space-y-6">
            <SidebarAd />
            <div className="sticky top-24 space-y-6">
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2">Quick Categories</h3>
                  <div className="space-y-2">
                    {calculatorCategories.map(category => (
                      <Button
                        key={category.id}
                        variant="ghost"
                        size="sm"
                        className="w-full justify-start"
                        onClick={() => handleCategorySelect(category.id)}
                      >
                        {getCategoryIcon(category.icon, "mr-2 h-4 w-4")}
                        {category.name}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>
              <SidebarAd />
            </div>
          </div>
        </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose Our Calculators?</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Professional-grade tools designed for accuracy, ease of use, and educational value
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Step-by-Step Solutions</h3>
              <p className="text-muted-foreground">Detailed explanations for every calculation help you understand the process</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-secondary/10 rounded-full flex items-center justify-center">
                <Smartphone className="h-8 w-8 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Mobile-Friendly</h3>
              <p className="text-muted-foreground">Optimized for all devices with touch-friendly interfaces</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-accent/10 rounded-full flex items-center justify-center">
                <Shield className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Input Validation</h3>
              <p className="text-muted-foreground">Smart error checking ensures accurate results every time</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Educational Focus</h3>
              <p className="text-muted-foreground">Learn concepts while solving problems with built-in explanations</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-secondary/10 rounded-full flex items-center justify-center">
                <Zap className="h-8 w-8 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Lightning Fast</h3>
              <p className="text-muted-foreground">Instant calculations with no waiting time or complex setup</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-accent/10 rounded-full flex items-center justify-center">
                <Users className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Trusted by Millions</h3>
              <p className="text-muted-foreground">Used by students and professionals worldwide</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-muted-foreground">Get answers to common questions about our calculators</p>
          </div>
          
          {/* Content Ad before FAQ */}
          <ContentAd className="mb-8" />
          
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Are the calculators free to use?</h3>
                <p className="text-muted-foreground">Yes, all our calculators are completely free to use. No registration or payment required.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">How accurate are the calculations?</h3>
                <p className="text-muted-foreground">Our calculators use precise mathematical algorithms and are regularly tested for accuracy. Results are reliable for educational and professional use.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Can I use these calculators on my mobile device?</h3>
                <p className="text-muted-foreground">Absolutely! All calculators are optimized for mobile devices with touch-friendly interfaces and responsive design.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Do you show the calculation steps?</h3>
                <p className="text-muted-foreground">Yes, most calculators include detailed step-by-step solutions to help you understand the calculation process.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer Ad */}
      <FooterAd />

      <Footer />
    </div>
  );
}

function getCategoryColor(category: string): string {
  const categoryMap = {
    physics: "primary",
    chemistry: "secondary", 
    math: "accent",
    biology: "primary"
  };
  return categoryMap[category as keyof typeof categoryMap] || "primary";
}
