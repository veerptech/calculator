import { SEOHead } from "@/components/seo-head";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export default function CookiePolicyPage() {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Cookie Policy - Science Calculators Hub"
        description="Cookie Policy for Science Calculators Hub - Learn about how we use cookies and tracking technologies."
        keywords="cookie policy, cookies, tracking, web storage, privacy"
        canonicalUrl={`${window.location.origin}/cookie-policy`}
      />

      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <div className="flex h-16 items-center">
            <Button variant="ghost" asChild>
              <a href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </a>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 lg:px-8 max-w-4xl py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl font-bold">Cookie Policy</CardTitle>
            <p className="text-muted-foreground">Last updated: {new Date().toLocaleDateString()}</p>
          </CardHeader>
          <CardContent className="prose prose-gray max-w-none dark:prose-invert">
            <div className="space-y-6">
              <section>
                <h2 className="text-2xl font-semibold mb-4">What Are Cookies?</h2>
                <p className="mb-4">
                  Cookies are small text files that are stored on your computer or mobile device when you visit a website. 
                  They help the website remember information about your visit, which can make it easier to visit the site 
                  again and make the site more useful to you.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">How We Use Cookies</h2>
                <p className="mb-4">Science Calculators Hub uses cookies for the following purposes:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li><strong>Essential Cookies:</strong> Required for the website to function properly</li>
                  <li><strong>Performance Cookies:</strong> Help us understand how visitors interact with our website</li>
                  <li><strong>Functional Cookies:</strong> Remember your preferences and settings</li>
                  <li><strong>Advertising Cookies:</strong> Used by Google AdSense to show relevant advertisements</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Types of Cookies We Use</h2>
                
                <div className="space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold">Essential Cookies</h3>
                    <p className="text-sm text-muted-foreground">
                      These cookies are necessary for the website to function and cannot be disabled. They include:
                    </p>
                    <ul className="list-disc pl-6 mt-2 space-y-1">
                      <li>Session management cookies</li>
                      <li>Security cookies</li>
                      <li>Load balancing cookies</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold">Analytics Cookies</h3>
                    <p className="text-sm text-muted-foreground">
                      These cookies help us understand how our website is being used:
                    </p>
                    <ul className="list-disc pl-6 mt-2 space-y-1">
                      <li>Google Analytics cookies</li>
                      <li>Page view tracking</li>
                      <li>User behavior analysis</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold">Advertising Cookies</h3>
                    <p className="text-sm text-muted-foreground">
                      These cookies are used to show relevant advertisements:
                    </p>
                    <ul className="list-disc pl-6 mt-2 space-y-1">
                      <li>Google AdSense cookies</li>
                      <li>Personalized advertising</li>
                      <li>Ad performance tracking</li>
                    </ul>
                  </div>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Google AdSense Cookies</h2>
                <p className="mb-4">
                  We use Google AdSense to display advertisements on our website. Google AdSense uses cookies to:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Show ads based on your previous visits to our site</li>
                  <li>Show ads based on your visits to other sites on the web</li>
                  <li>Measure ad performance and effectiveness</li>
                  <li>Prevent you from seeing the same ads repeatedly</li>
                </ul>
                <p className="mt-4">
                  You can opt out of personalized advertising by visiting Google's{" "}
                  <a href="https://www.google.com/settings/ads" className="text-primary hover:underline" target="_blank" rel="noopener">
                    Ads Settings
                  </a>
                  .
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Managing Cookies</h2>
                <p className="mb-4">
                  You can control and/or delete cookies as you wish. You can delete all cookies that are already on 
                  your computer and you can set most browsers to prevent them from being placed. However, if you do 
                  this, you may have to manually adjust some preferences every time you visit our site.
                </p>
                
                <div className="space-y-2">
                  <h3 className="text-lg font-semibold">Browser Settings</h3>
                  <p className="text-sm text-muted-foreground mb-2">
                    Most web browsers allow you to control cookies through their settings:
                  </p>
                  <ul className="list-disc pl-6 space-y-1 text-sm">
                    <li><strong>Chrome:</strong> Settings → Advanced → Privacy and Security → Content Settings → Cookies</li>
                    <li><strong>Firefox:</strong> Options → Privacy & Security → Cookies and Site Data</li>
                    <li><strong>Safari:</strong> Preferences → Privacy → Cookies and Website Data</li>
                    <li><strong>Edge:</strong> Settings → Cookies and Site Permissions</li>
                  </ul>
                </div>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Third-Party Cookies</h2>
                <p className="mb-4">
                  Some cookies on our site are set by third-party services:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li><strong>Google AdSense:</strong> For displaying personalized advertisements</li>
                  <li><strong>Google Analytics:</strong> For website analytics and performance monitoring</li>
                  <li><strong>Content Delivery Networks:</strong> For faster content delivery</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
                <p className="mb-4">
                  If you have any questions about our Cookie Policy, please contact us through our{" "}
                  <a href="/contact" className="text-primary hover:underline">
                    Contact Us
                  </a>{" "}
                  page.
                </p>
              </section>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}