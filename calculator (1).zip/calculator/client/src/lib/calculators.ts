import { Calculator } from "@shared/schema";

export const calculatorCategories = [
  { id: "physics", name: "Physics", icon: "atom", color: "primary" },
  { id: "chemistry", name: "Chemistry", icon: "flask", color: "secondary" },
  { id: "math", name: "Mathematics", icon: "square-root-alt", color: "accent" },
  { id: "biology", name: "Biology", icon: "dna", color: "primary" }
];

export const subcategories = {
  physics: [
    { id: "mechanics", name: "Mechanics", icon: "rocket", description: "Motion, force, energy, and momentum calculations" },
    { id: "gravitation", name: "Gravitation & Astronomy", icon: "globe", description: "Gravitational forces, orbital mechanics, and astronomical calculations" },
    { id: "waves", name: "Waves & Sound", icon: "wave-square", description: "Wave properties, sound waves, and vibrations" },
    { id: "optics", name: "Optics", icon: "eye", description: "Light, lenses, mirrors, and optical phenomena" },
    { id: "electricity", name: "Electricity & Magnetism", icon: "bolt", description: "Electric circuits, magnetic fields, and electromagnetic effects" },
    { id: "modern", name: "Modern Physics", icon: "atom", description: "Quantum mechanics, relativity, and atomic physics" }
  ],
  chemistry: [
    { id: "basic", name: "Basic Chemistry", icon: "flask", description: "Fundamental chemistry calculations and conversions" },
    { id: "gas-laws", name: "Gas Laws", icon: "gas-pump", description: "Ideal gas law, partial pressure, and gas properties" },
    { id: "acid-base", name: "Acid-Base Chemistry", icon: "tint", description: "pH, buffers, titrations, and acid-base equilibria" },
    { id: "thermodynamics", name: "Thermodynamics", icon: "thermometer-half", description: "Heat, enthalpy, entropy, and energy changes" },
    { id: "electrochemistry", name: "Electrochemistry", icon: "battery", description: "Redox reactions, electrochemical cells, and corrosion" },
    { id: "miscellaneous", name: "Miscellaneous", icon: "vial", description: "Solutions, crystallography, and other chemistry tools" }
  ],
  math: [
    { id: "arithmetic", name: "Arithmetic & Algebra", icon: "calculator", description: "Basic arithmetic, algebraic equations, and number theory" },
    { id: "geometry", name: "Geometry & Trigonometry", icon: "shapes", description: "Geometric shapes, angles, trigonometric functions" },
    { id: "advanced", name: "Advanced Algebra", icon: "function", description: "Polynomials, matrices, complex numbers, and advanced topics" },
    { id: "statistics", name: "Statistics & Probability", icon: "chart-line", description: "Data analysis, probability distributions, and statistical tests" },
    { id: "calculus", name: "Calculus & Transforms", icon: "infinity", description: "Derivatives, integrals, differential equations, and transforms" }
  ],
  biology: [
    { id: "health", name: "Human Body & Health", icon: "heartbeat", description: "BMI, body composition, health metrics, and fitness calculations" },
    { id: "molecular", name: "Molecular & Cell Biology", icon: "microscope", description: "Cell biology, biochemistry, and molecular processes" },
    { id: "genetics", name: "Genetics & Evolution", icon: "dna", description: "Heredity, population genetics, and evolutionary calculations" },
    { id: "medical", name: "Medical & Clinical", icon: "stethoscope", description: "Medical dosage, clinical calculations, and healthcare metrics" },
    { id: "ecology", name: "Physiology & Ecology", icon: "seedling", description: "Environmental science, population dynamics, and ecological modeling" }
  ]
};

export function getCategoryColor(category: string): string {
  const categoryMap = {
    physics: "primary",
    chemistry: "secondary", 
    math: "accent",
    biology: "primary"
  };
  return categoryMap[category as keyof typeof categoryMap] || "primary";
}

export function getSubcategoryIcon(subcategory: string): string {
  const iconMap = {
    // Physics
    mechanics: "rocket",
    gravitation: "globe",
    waves: "wave-square",
    optics: "eye",
    electricity: "bolt",
    modern: "atom",
    
    // Chemistry
    basic: "flask",
    "gas-laws": "gas-pump",
    "acid-base": "tint",
    thermodynamics: "thermometer-half",
    electrochemistry: "battery",
    miscellaneous: "vial",
    
    // Math
    arithmetic: "calculator",
    geometry: "shapes",
    advanced: "function",
    statistics: "chart-line",
    calculus: "infinity",
    
    // Biology
    health: "heartbeat",
    molecular: "microscope",
    genetics: "dna",
    medical: "stethoscope",
    ecology: "seedling",
    
    // Legacy support for existing calculators
    solutions: "vial",
    stoichiometry: "balance-scale",
    algebra: "calculator",
    physiology: "heartbeat"
  };
  return iconMap[subcategory as keyof typeof iconMap] || "calculator";
}

export function formatUsageCount(count: number): string {
  if (count >= 1000) {
    return `${(count / 1000).toFixed(1)}k`;
  }
  return count.toString();
}
