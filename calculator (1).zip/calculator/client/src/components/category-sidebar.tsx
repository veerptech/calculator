import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { calculatorCategories, subcategories } from "@/lib/calculators";
import { 
  Calculator, 
  ChevronDown, 
  ChevronRight,
  Atom,
  FlaskConical,
  SquareFunction,
  Dna,
  Rocket,
  Globe,
  Activity,
  Eye,
  Zap as Bolt,
  Fuel,
  Droplet,
  Thermometer,
  Battery,
  TestTube,
  Plus,
  Triangle,
  TrendingUp,
  Infinity,
  Heart,
  Microscope,
  Stethoscope,
  Leaf
} from "lucide-react";
import { Calculator as CalculatorType } from "@shared/schema";
import { CalculatorCard } from "@/components/calculator-card";

// Helper function to get category icons
function getCategoryIcon(iconName: string, className: string = "h-4 w-4") {
  const iconMap: Record<string, React.ReactNode> = {
    atom: <Atom className={className} />,
    flask: <FlaskConical className={className} />,
    "square-root-alt": <SquareFunction className={className} />,
    dna: <Dna className={className} />,
    calculator: <Calculator className={className} />,
  };
  
  return iconMap[iconName] || <Calculator className={className} />;
}

// Helper function to get subcategory icons
function getSubcategoryIcon(iconName: string, className: string = "h-4 w-4") {
  const iconMap: Record<string, React.ReactNode> = {
    rocket: <Rocket className={className} />,
    globe: <Globe className={className} />,
    "wave-square": <Activity className={className} />,
    eye: <Eye className={className} />,
    bolt: <Bolt className={className} />,
    atom: <Atom className={className} />,
    flask: <FlaskConical className={className} />,
    "gas-pump": <Fuel className={className} />,
    tint: <Droplet className={className} />,
    "thermometer-half": <Thermometer className={className} />,
    battery: <Battery className={className} />,
    vial: <TestTube className={className} />,
    calculator: <Calculator className={className} />,
    shapes: <Triangle className={className} />,
    function: <Plus className={className} />,
    "chart-line": <TrendingUp className={className} />,
    infinity: <Infinity className={className} />,
    heartbeat: <Heart className={className} />,
    microscope: <Microscope className={className} />,
    dna: <Dna className={className} />,
    stethoscope: <Stethoscope className={className} />,
    seedling: <Leaf className={className} />,
  };
  
  return iconMap[iconName] || <Calculator className={className} />;
}

interface CategorySidebarProps {
  selectedCategory: string;
  selectedSubcategory: string | null;
  onCategorySelect: (categoryId: string) => void;
  onSubcategorySelect: (categoryId: string, subcategoryId: string) => void;
  onCalculatorClick: (calculator: CalculatorType) => void;
  calculators: CalculatorType[];
  className?: string;
}

export function CategorySidebar({
  selectedCategory,
  selectedSubcategory,
  onCategorySelect,
  onSubcategorySelect,
  onCalculatorClick,
  calculators,
  className = "",
}: CategorySidebarProps) {
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    [selectedCategory]: true,
  });

  const toggleCategoryExpansion = (categoryId: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryId]: !prev[categoryId],
    }));
  };

  const handleCategorySelect = (categoryId: string) => {
    onCategorySelect(categoryId);
    if (categoryId !== "all") {
      setExpandedCategories(prev => ({
        ...prev,
        [categoryId]: true,
      }));
    }
  };

  const filteredCalculators = calculators.filter(calc => {
    if (selectedCategory === "all") return true;
    if (selectedSubcategory) {
      return calc.category === selectedCategory && calc.subcategory === selectedSubcategory;
    }
    return calc.category === selectedCategory;
  });

  return (
    <div className={`flex h-full ${className}`}>
      {/* Left Sidebar - Categories and Subcategories */}
      <div className="w-80 border-r bg-card overflow-y-auto">
        <div className="p-4 border-b">
          <h2 className="text-lg font-semibold mb-4">Categories</h2>
          
          {/* All Calculators Button */}
          <Button
            variant={selectedCategory === "all" ? "default" : "outline"}
            onClick={() => handleCategorySelect("all")}
            className="w-full justify-start mb-4"
            data-testid="sidebar-filter-all"
          >
            <Calculator className="mr-2 h-4 w-4" />
            All Calculators
          </Button>
        </div>

        {/* Categories */}
        <div className="p-4 space-y-2">
          {calculatorCategories.map(category => (
            <Card key={category.id} className="overflow-hidden">
              <Collapsible 
                open={expandedCategories[category.id]} 
                onOpenChange={() => toggleCategoryExpansion(category.id)}
              >
                <CollapsibleTrigger asChild>
                  <div 
                    className={`p-3 cursor-pointer transition-colors hover:bg-muted/50 ${
                      selectedCategory === category.id && !selectedSubcategory 
                        ? 'bg-primary/10 border-l-4 border-primary' 
                        : ''
                    }`}
                    onClick={() => handleCategorySelect(category.id)}
                    data-testid={`sidebar-category-${category.id}`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center bg-${category.color}/10`}>
                          {getCategoryIcon(category.icon, `text-sm text-${category.color}`)}
                        </div>
                        <div>
                          <div className="font-medium text-sm">{category.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {calculators.filter(c => c.category === category.id).length} tools
                          </div>
                        </div>
                      </div>
                      {expandedCategories[category.id] ? (
                        <ChevronDown className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                  </div>
                </CollapsibleTrigger>
                
                <CollapsibleContent>
                  <div className="px-3 pb-3 space-y-1">
                    {subcategories[category.id as keyof typeof subcategories]?.map(subcategory => {
                      const subcategoryCount = calculators.filter(c => 
                        c.category === category.id && c.subcategory === subcategory.id
                      ).length;
                      
                      return (
                        <Button
                          key={subcategory.id}
                          variant={
                            selectedCategory === category.id && selectedSubcategory === subcategory.id 
                              ? "default" 
                              : "ghost"
                          }
                          size="sm"
                          className="w-full justify-start h-auto p-2"
                          onClick={() => onSubcategorySelect(category.id, subcategory.id)}
                          data-testid={`sidebar-subcategory-${category.id}-${subcategory.id}`}
                        >
                          <div className="flex items-center space-x-2 flex-1">
                            <div className={`w-6 h-6 rounded flex items-center justify-center bg-${category.color}/5`}>
                              {getSubcategoryIcon(subcategory.icon, `text-xs text-${category.color}`)}
                            </div>
                            <div className="flex-1 text-left">
                              <div className="text-xs font-medium">{subcategory.name}</div>
                            </div>
                            <div className="text-xs bg-muted px-1.5 py-0.5 rounded">
                              {subcategoryCount}
                            </div>
                          </div>
                        </Button>
                      );
                    })}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            </Card>
          ))}
        </div>
      </div>

      {/* Right Side - Calculator Grid */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-6">
          <div className="mb-6">
            <h1 className="text-2xl font-bold">
              {selectedCategory === "all" 
                ? "All Calculators" 
                : selectedSubcategory 
                  ? `${subcategories[selectedCategory as keyof typeof subcategories]?.find(s => s.id === selectedSubcategory)?.name} Calculators`
                  : `${calculatorCategories.find(c => c.id === selectedCategory)?.name} Calculators`
              }
            </h1>
            <p className="text-muted-foreground">
              {filteredCalculators.length} calculator{filteredCalculators.length !== 1 ? 's' : ''} available
            </p>
          </div>
          
          {filteredCalculators.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredCalculators.map(calculator => (
                <CalculatorCard
                  key={calculator.id}
                  calculator={calculator}
                  onClick={onCalculatorClick}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold mb-2">No calculators found</h3>
              <p className="text-muted-foreground">Try selecting a different category or subcategory</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}