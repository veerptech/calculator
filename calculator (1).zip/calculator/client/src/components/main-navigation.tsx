import { Link } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  NavigationMenu, 
  NavigationMenuContent, 
  NavigationMenuItem, 
  NavigationMenuLink, 
  NavigationMenuList, 
  NavigationMenuTrigger 
} from "@/components/ui/navigation-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { calculatorCategories } from "@/lib/calculators";
import { Calculator, Menu, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";

export function MainNavigation() {
  const [isOpen, setIsOpen] = useState(false);

  const categories = [
    { id: "physics", name: "Physics", color: "text-blue-600", description: "Mechanics, Electricity, Thermodynamics" },
    { id: "chemistry", name: "Chemistry", color: "text-green-600", description: "Stoichiometry, pH, Gas Laws" },
    { id: "biology", name: "Biology", color: "text-red-600", description: "Health, Genetics, Bioinformatics" },
    { id: "math", name: "Mathematics", color: "text-purple-600", description: "Calculus, Statistics, Algebra" }
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 lg:px-8 h-16 flex items-center">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 mr-6">
          <Calculator className="h-6 w-6 text-primary" />
          <span className="font-bold text-xl">Science Calculators Hub</span>
        </Link>

        {/* Desktop Navigation */}
        <NavigationMenu className="hidden md:flex">
          <NavigationMenuList>
            <NavigationMenuItem>
              <NavigationMenuTrigger>Categories</NavigationMenuTrigger>
              <NavigationMenuContent>
                <div className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                  {categories.map((category) => (
                    <Link key={category.id} href={`/category/${category.id}`}>
                      <div className={cn(
                        "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                      )}>
                        <div className={cn("text-sm font-medium leading-none", category.color)}>
                          {category.name}
                        </div>
                        <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                          {category.description}
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
              </NavigationMenuContent>
            </NavigationMenuItem>
            
            <NavigationMenuItem>
              <NavigationMenuLink asChild>
                <Link 
                  href="/about" 
                  className={cn(
                    "group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50"
                  )}
                >
                  About
                </Link>
              </NavigationMenuLink>
            </NavigationMenuItem>

            <NavigationMenuItem>
              <NavigationMenuLink asChild>
                <Link 
                  href="/contact" 
                  className={cn(
                    "group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50"
                  )}
                >
                  Contact
                </Link>
              </NavigationMenuLink>
            </NavigationMenuItem>
          </NavigationMenuList>
        </NavigationMenu>

        <div className="flex-1" />

        {/* Mobile Menu */}
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" className="md:hidden">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Open menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[300px] sm:w-[400px]">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="flex items-center gap-2 py-2">
                <Calculator className="h-5 w-5 text-primary" />
                <span className="font-semibold">Home</span>
              </Link>
              
              <div className="py-2">
                <h4 className="font-semibold mb-3 text-sm text-muted-foreground uppercase tracking-wider">Categories</h4>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <Link 
                      key={category.id}
                      href={`/category/${category.id}`}
                      className="block py-2 px-3 rounded-md hover:bg-accent"
                      onClick={() => setIsOpen(false)}
                    >
                      <div className={cn("font-medium", category.color)}>
                        {category.name}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {category.description}
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
              
              <div className="border-t pt-4 space-y-2">
                <Link 
                  href="/about" 
                  className="block py-2 px-3 rounded-md hover:bg-accent"
                  onClick={() => setIsOpen(false)}
                >
                  About Us
                </Link>
                <Link 
                  href="/contact" 
                  className="block py-2 px-3 rounded-md hover:bg-accent"
                  onClick={() => setIsOpen(false)}
                >
                  Contact Us
                </Link>
              </div>
            </nav>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}