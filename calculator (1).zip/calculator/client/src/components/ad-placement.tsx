import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface AdPlacementProps {
  slot: string;
  size?: "banner" | "sidebar" | "large-banner" | "mobile-banner" | "square";
  className?: string;
  label?: string;
}

export function AdPlacement({ slot, size = "banner", className, label }: AdPlacementProps) {
  const sizeClasses = {
    banner: "h-24 md:h-32", // 728x90 or responsive
    "large-banner": "h-32 md:h-48", // 970x250
    sidebar: "h-64 w-full max-w-xs", // 300x250
    "mobile-banner": "h-20 md:h-24", // 320x50
    square: "h-64 w-64", // 300x300
  };

  return (
    <div className={cn("ad-placement", className)} data-ad-slot={slot}>
      <Card className={cn("border-dashed border-2 border-muted", sizeClasses[size])}>
        <CardContent className="flex items-center justify-center h-full">
          <div className="text-center text-muted-foreground">
            <div className="text-xs opacity-60 mb-1">
              {label || "Advertisement"}
            </div>
            <div className="text-xs opacity-40">
              Google AdSense Slot: {slot}
            </div>
            {/* 
            Replace this placeholder with actual Google AdSense code:
            <ins className="adsbygoogle"
                 style={{display: "block"}}
                 data-ad-client="ca-pub-XXXXXXXXXX"
                 data-ad-slot={slot}
                 data-ad-format="auto"
                 data-full-width-responsive="true"></ins>
            */}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Pre-configured ad components for common placements
export function HeaderAd({ className }: { className?: string }) {
  return (
    <AdPlacement 
      slot="header-banner" 
      size="banner" 
      label="Header Advertisement"
      className={className}
    />
  );
}

export function SidebarAd({ className }: { className?: string }) {
  return (
    <AdPlacement 
      slot="sidebar-square" 
      size="sidebar" 
      label="Sidebar Advertisement"
      className={className}
    />
  );
}

export function FooterAd({ className }: { className?: string }) {
  return (
    <AdPlacement 
      slot="footer-banner" 
      size="large-banner" 
      label="Footer Advertisement"
      className={className}
    />
  );
}

export function MobileAd({ className }: { className?: string }) {
  return (
    <AdPlacement 
      slot="mobile-banner" 
      size="mobile-banner" 
      label="Mobile Advertisement"
      className={cn("md:hidden", className)}
    />
  );
}

export function ContentAd({ className }: { className?: string }) {
  return (
    <AdPlacement 
      slot="content-banner" 
      size="banner" 
      label="Content Advertisement"
      className={className}
    />
  );
}