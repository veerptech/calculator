import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  useExplainCalculation, 
  useSolveProblem, 
  useSuggestCalculators, 
  useStudyTip 
} from "@/hooks/use-ai";
import { 
  BookOpen, 
  Brain, 
  Lightbulb, 
  Calculator,
  Loader2,
  AlertCircle,
  Sparkles
} from "lucide-react";

interface AIExplanationPanelProps {
  calculatorType: string;
  formula: string;
  inputs: Record<string, any>;
  result: any;
}

interface AIProblemSolverProps {
  category: string;
  subcategory: string;
}

interface AIRelatedCalculatorsProps {
  currentCalculator: string;
  category: string;
  inputs?: Record<string, any>;
}

interface AIStudyTipProps {
  calculatorType: string;
  category: string;
}

export function AIExplanationPanel({ calculatorType, formula, inputs, result }: AIExplanationPanelProps) {
  const explainMutation = useExplainCalculation();
  const [isExpanded, setIsExpanded] = useState(false);

  const handleExplain = () => {
    explainMutation.mutate({ calculatorType, formula, inputs, result });
    setIsExpanded(true);
  };

  const explanation = explainMutation.data?.explanation;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          AI Step-by-Step Explanation
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!isExpanded ? (
          <Button 
            onClick={handleExplain} 
            disabled={explainMutation.isPending}
            className="w-full"
          >
            {explainMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating explanation...
              </>
            ) : (
              <>
                <BookOpen className="mr-2 h-4 w-4" />
                Get AI Explanation
              </>
            )}
          </Button>
        ) : (
          <div className="space-y-4">
            {explainMutation.isError ? (
              <div className="flex items-center gap-2 text-destructive">
                <AlertCircle className="h-4 w-4" />
                Unable to generate explanation. Please try again.
              </div>
            ) : explanation ? (
              <>
                <div>
                  <h4 className="font-semibold mb-2">Concept:</h4>
                  <p className="text-sm text-muted-foreground">{explanation.concept}</p>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="font-semibold mb-2">Formula:</h4>
                  <code className="text-sm bg-muted p-2 rounded block">{explanation.formula}</code>
                </div>
                
                <Separator />
                
                <div>
                  <h4 className="font-semibold mb-2">Steps:</h4>
                  <ol className="list-decimal list-inside space-y-1">
                    {explanation.steps.map((step, index) => (
                      <li key={index} className="text-sm">{step}</li>
                    ))}
                  </ol>
                </div>
                
                {explanation.tips.length > 0 && (
                  <>
                    <Separator />
                    <div>
                      <h4 className="font-semibold mb-2">Tips:</h4>
                      <ul className="list-disc list-inside space-y-1">
                        {explanation.tips.map((tip, index) => (
                          <li key={index} className="text-sm text-muted-foreground">{tip}</li>
                        ))}
                      </ul>
                    </div>
                  </>
                )}
              </>
            ) : null}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function AIProblemSolver({ category, subcategory }: AIProblemSolverProps) {
  const [problem, setProblem] = useState("");
  const solveMutation = useSolveProblem();

  const handleSolve = () => {
    if (problem.trim()) {
      solveMutation.mutate({ problem: problem.trim(), category, subcategory });
    }
  };

  const solution = solveMutation.data?.solution;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-secondary" />
          AI Problem Solver
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Textarea
            placeholder={`Describe a ${category} problem you need help with...`}
            value={problem}
            onChange={(e) => setProblem(e.target.value)}
            rows={3}
          />
        </div>
        
        <Button 
          onClick={handleSolve} 
          disabled={!problem.trim() || solveMutation.isPending}
          className="w-full"
        >
          {solveMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Solving problem...
            </>
          ) : (
            <>
              <Brain className="mr-2 h-4 w-4" />
              Solve Problem
            </>
          )}
        </Button>

        {solveMutation.isError ? (
          <div className="flex items-center gap-2 text-destructive">
            <AlertCircle className="h-4 w-4" />
            Unable to solve problem. Please try again.
          </div>
        ) : solution ? (
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Solution:</h4>
              <p className="text-sm font-medium">{solution.solution}</p>
            </div>
            
            <Separator />
            
            <div>
              <h4 className="font-semibold mb-2">Explanation:</h4>
              <p className="text-sm text-muted-foreground">{solution.explanation}</p>
            </div>
            
            <Separator />
            
            <div>
              <h4 className="font-semibold mb-2">Steps:</h4>
              <ol className="list-decimal list-inside space-y-1">
                {solution.steps.map((step, index) => (
                  <li key={index} className="text-sm">{step}</li>
                ))}
              </ol>
            </div>
            
            {solution.relatedConcepts.length > 0 && (
              <>
                <Separator />
                <div>
                  <h4 className="font-semibold mb-2">Related Concepts:</h4>
                  <div className="flex flex-wrap gap-2">
                    {solution.relatedConcepts.map((concept, index) => (
                      <Badge key={index} variant="secondary">{concept}</Badge>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}

export function AIRelatedCalculators({ currentCalculator, category, inputs }: AIRelatedCalculatorsProps) {
  const suggestMutation = useSuggestCalculators();
  const [isExpanded, setIsExpanded] = useState(false);

  const handleSuggest = () => {
    suggestMutation.mutate({ currentCalculator, category, inputs });
    setIsExpanded(true);
  };

  const suggestions = suggestMutation.data?.suggestions;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5 text-accent" />
          Related Calculators
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!isExpanded ? (
          <Button 
            onClick={handleSuggest} 
            disabled={suggestMutation.isPending}
            variant="outline"
            className="w-full"
          >
            {suggestMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Finding related calculators...
              </>
            ) : (
              <>
                <Calculator className="mr-2 h-4 w-4" />
                Suggest Related Tools
              </>
            )}
          </Button>
        ) : (
          <div className="space-y-2">
            {suggestMutation.isError ? (
              <div className="flex items-center gap-2 text-destructive">
                <AlertCircle className="h-4 w-4" />
                Unable to find suggestions. Please try again.
              </div>
            ) : suggestions && suggestions.length > 0 ? (
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground mb-3">
                  Based on your current calculation, you might also find these useful:
                </p>
                <ul className="space-y-1">
                  {suggestions.map((suggestion, index) => (
                    <li key={index} className="text-sm">
                      • {suggestion}
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No related calculators found.</p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function AIStudyTip({ calculatorType, category }: AIStudyTipProps) {
  const tipMutation = useStudyTip();
  const [isExpanded, setIsExpanded] = useState(false);

  const handleGetTip = () => {
    tipMutation.mutate({ calculatorType, category });
    setIsExpanded(true);
  };

  const tip = tipMutation.data?.tip;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="h-5 w-5 text-yellow-500" />
          Study Tip
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!isExpanded ? (
          <Button 
            onClick={handleGetTip} 
            disabled={tipMutation.isPending}
            variant="outline"
            size="sm"
          >
            {tipMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Getting tip...
              </>
            ) : (
              <>
                <Lightbulb className="mr-2 h-4 w-4" />
                Get Study Tip
              </>
            )}
          </Button>
        ) : (
          <div>
            {tipMutation.isError ? (
              <div className="flex items-center gap-2 text-destructive">
                <AlertCircle className="h-4 w-4" />
                Unable to get tip. Please try again.
              </div>
            ) : tip ? (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <p className="text-sm text-yellow-800">{tip}</p>
              </div>
            ) : null}
          </div>
        )}
      </CardContent>
    </Card>
  );
}