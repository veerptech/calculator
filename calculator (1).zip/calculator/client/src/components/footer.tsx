import { Link } from "wouter";
import { Calculator, Mail, FileText, Shield, Cookie, AlertTriangle, Info, MessageSquare } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  const legalLinks = [
    { href: "/privacy-policy", label: "Privacy Policy", icon: Shield },
    { href: "/terms-of-service", label: "Terms of Service", icon: FileText },
    { href: "/cookie-policy", label: "Cookie Policy", icon: Cookie },
    { href: "/disclaimer", label: "Disclaimer", icon: AlertTriangle },
  ];

  const companyLinks = [
    { href: "/about", label: "About Us", icon: Info },
    { href: "/contact", label: "Contact Us", icon: MessageSquare },
  ];

  return (
    <footer className="bg-muted/50 border-t border-border mt-16">
      <div className="container mx-auto px-4 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Calculator className="h-6 w-6 text-primary" />
              <span className="font-bold text-lg">Science Calculators Hub</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Your comprehensive platform for scientific calculations with AI assistance and educational support.
            </p>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-semibold mb-4">Categories</h3>
            <div className="space-y-2">
              <Link href="/category/physics" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">
                Physics Calculators
              </Link>
              <Link href="/category/chemistry" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">
                Chemistry Calculators
              </Link>
              <Link href="/category/biology" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">
                Biology Calculators
              </Link>
              <Link href="/category/math" className="block text-sm text-muted-foreground hover:text-foreground transition-colors">
                Math Calculators
              </Link>
            </div>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold mb-4">Company</h3>
            <div className="space-y-2">
              {companyLinks.map((link) => {
                const IconComponent = link.icon;
                return (
                  <Link 
                    key={link.href} 
                    href={link.href} 
                    className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <IconComponent className="h-3 w-3" />
                    {link.label}
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-semibold mb-4">Legal</h3>
            <div className="space-y-2">
              {legalLinks.map((link) => {
                const IconComponent = link.icon;
                return (
                  <Link 
                    key={link.href} 
                    href={link.href} 
                    className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <IconComponent className="h-3 w-3" />
                    {link.label}
                  </Link>
                );
              })}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border mt-8 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {currentYear} Science Calculators Hub. All rights reserved.
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span>Made with ❤️ for students and researchers</span>
          </div>
        </div>
      </div>
    </footer>
  );
}