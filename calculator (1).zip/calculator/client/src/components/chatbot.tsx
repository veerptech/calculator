import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  MessageCircle, 
  Send, 
  Trash2, 
  Bot, 
  User, 
  Calculator,
  ExternalLink,
  Loader2
} from "lucide-react";
import { useChatbot } from "@/hooks/use-chatbot";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";

interface ChatMessageProps {
  message: {
    id: string;
    type: 'user' | 'bot';
    message: string;
    timestamp: Date;
    calculatorLink?: string;
    alternatives?: string[];
  };
}

function ChatMessage({ message }: ChatMessageProps) {
  const [, navigate] = useLocation();
  
  const handleCalculatorClick = (link: string) => {
    navigate(link);
  };

  return (
    <div className={cn(
      "flex gap-3 mb-4",
      message.type === 'user' ? "justify-end" : "justify-start"
    )}>
      {message.type === 'bot' && (
        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
          <Bot className="h-4 w-4 text-primary-foreground" />
        </div>
      )}
      
      <div className={cn(
        "max-w-[80%] rounded-lg px-3 py-2",
        message.type === 'user' 
          ? "bg-primary text-primary-foreground" 
          : "bg-muted text-foreground"
      )}>
        <p className="text-sm">{message.message}</p>
        
        {message.calculatorLink && (
          <div className="mt-2 pt-2 border-t border-current/20">
            <Button
              onClick={() => handleCalculatorClick(message.calculatorLink!)}
              size="sm"
              variant={message.type === 'user' ? "secondary" : "default"}
              className="text-xs"
            >
              <Calculator className="h-3 w-3 mr-1" />
              Open Calculator
              <ExternalLink className="h-3 w-3 ml-1" />
            </Button>
          </div>
        )}
        
        {message.alternatives && message.alternatives.length > 0 && (
          <div className="mt-2 pt-2 border-t border-current/20">
            <p className="text-xs opacity-75 mb-1">You might also like:</p>
            <div className="flex flex-wrap gap-1">
              {message.alternatives.map((alt, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {alt}
                </Badge>
              ))}
            </div>
          </div>
        )}
        
        <div className="text-xs opacity-50 mt-1">
          {message.timestamp.toLocaleTimeString([], { 
            hour: '2-digit', 
            minute: '2-digit' 
          })}
        </div>
      </div>
      
      {message.type === 'user' && (
        <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
          <User className="h-4 w-4 text-secondary-foreground" />
        </div>
      )}
    </div>
  );
}

export function ChatbotWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [inputMessage, setInputMessage] = useState("");
  const { messages, sendMessage, clearChat, isLoading, error } = useChatbot();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = () => {
    if (inputMessage.trim() && !isLoading) {
      sendMessage(inputMessage);
      setInputMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const quickActions = [
    "Calculate BMI",
    "Physics calculations", 
    "Chemistry formulas",
    "Math equations"
  ];

  return (
    <>
      {/* Floating Chat Button */}
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button 
            size="lg"
            className="fixed bottom-6 right-6 h-14 w-14 rounded-full shadow-lg hover:shadow-xl z-50"
            data-testid="chatbot-trigger"
          >
            <MessageCircle className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        
        <SheetContent side="right" className="w-full sm:w-96 p-0 flex flex-col">
          <SheetHeader className="p-4 border-b">
            <div className="flex items-center justify-between">
              <div>
                <SheetTitle className="flex items-center gap-2">
                  <Bot className="h-5 w-5 text-primary" />
                  Calculator Assistant
                </SheetTitle>
                <SheetDescription>
                  Get help finding the right calculator for your needs
                </SheetDescription>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={clearChat}
                title="Clear chat"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </SheetHeader>
          
          {/* Chat Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 1 && (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Try asking about:
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {quickActions.map((action, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      className="text-xs h-8"
                      onClick={() => {
                        setInputMessage(action);
                        sendMessage(action);
                      }}
                    >
                      {action}
                    </Button>
                  ))}
                </div>
                <Separator className="my-4" />
              </div>
            )}
            
            {messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}
            
            {isLoading && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                  <Bot className="h-4 w-4 text-primary-foreground" />
                </div>
                <div className="bg-muted rounded-lg px-3 py-2">
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
            
            {error && (
              <div className="text-center text-destructive text-sm">
                Sorry, I encountered an error. Please try again.
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
          
          {/* Message Input */}
          <div className="border-t p-4">
            <div className="flex gap-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask about any calculator..."
                disabled={isLoading}
                className="flex-1"
                data-testid="chatbot-input"
              />
              <Button 
                onClick={handleSendMessage}
                disabled={!inputMessage.trim() || isLoading}
                size="icon"
                data-testid="chatbot-send"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Ask me to find any calculator or help solve problems!
            </p>
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}