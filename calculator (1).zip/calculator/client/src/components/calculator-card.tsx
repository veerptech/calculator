import { Calculator } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatUsageCount, getCategoryColor, getSubcategoryIcon } from "@/lib/calculators";
import { cn } from "@/lib/utils";

interface CalculatorCardProps {
  calculator: Calculator;
  onClick: (calculator: Calculator) => void;
  className?: string;
}

export function CalculatorCard({ calculator, onClick, className }: CalculatorCardProps) {
  const categoryColor = getCategoryColor(calculator.category);
  const subcategoryIcon = getSubcategoryIcon(calculator.subcategory);

  return (
    <Card 
      className={cn(
        "calculator-card cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-1",
        className
      )}
      onClick={() => onClick(calculator)}
      data-testid={`calculator-card-${calculator.id}`}
      data-category={calculator.category}
    >
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${categoryColor}/10`}>
            <i className={`fas fa-${subcategoryIcon} text-2xl text-${categoryColor}`}></i>
          </div>
          <Badge 
            variant="secondary" 
            className={`text-xs bg-${categoryColor}/10 text-${categoryColor} border-${categoryColor}/20`}
          >
            {calculator.subcategory}
          </Badge>
        </div>

        <h4 className="text-lg font-semibold mb-2 text-card-foreground line-clamp-2">
          {calculator.title}
        </h4>
        
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
          {calculator.description}
        </p>

        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            {formatUsageCount(calculator.usageCount || 0)} uses
          </span>
          <Button 
            variant="ghost" 
            size="sm"
            className={`text-${categoryColor} hover:text-${categoryColor}/80 text-sm font-medium p-0 h-auto`}
            data-testid={`calculate-button-${calculator.id}`}
          >
            Calculate →
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
