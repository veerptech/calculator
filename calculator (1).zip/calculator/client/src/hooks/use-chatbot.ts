import { useMutation } from "@tanstack/react-query";
import { useState } from "react";

interface ChatMessage {
  id: string;
  type: 'user' | 'bot';
  message: string;
  timestamp: Date;
  calculatorLink?: string;
  alternatives?: string[];
}

interface ChatbotResponse {
  message: string;
  calculatorLink?: string;
  alternatives?: string[];
  needsClarification?: boolean;
}

export function useChatbot() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'bot',
      message: "Hi! I'm your calculator assistant 🤖 What would you like to calculate today?",
      timestamp: new Date()
    }
  ]);

  const sendMessageMutation = useMutation({
    mutationFn: async (message: string): Promise<ChatbotResponse> => {
      const response = await fetch("/api/chatbot/message", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message }),
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      // Debug log to see the actual response
      console.log("Chatbot API response:", data);
      
      if (!data.success) {
        throw new Error(data.error || "Failed to send message");
      }
      
      return data.response;
    },
    onSuccess: (response, userMessage) => {
      // Add user message
      const userMsg: ChatMessage = {
        id: Date.now().toString(),
        type: 'user',
        message: userMessage,
        timestamp: new Date()
      };
      
      // Add bot response
      const botMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        message: response.message,
        timestamp: new Date(),
        calculatorLink: response.calculatorLink,
        alternatives: response.alternatives
      };
      
      setMessages(prev => [...prev, userMsg, botMsg]);
    }
  });

  const sendMessage = (message: string) => {
    if (message.trim()) {
      sendMessageMutation.mutate(message.trim());
    }
  };

  const clearChat = () => {
    setMessages([
      {
        id: '1',
        type: 'bot',
        message: "Hi! I'm your calculator assistant 🤖 What would you like to calculate today?",
        timestamp: new Date()
      }
    ]);
  };

  return {
    messages,
    sendMessage,
    clearChat,
    isLoading: sendMessageMutation.isPending,
    error: sendMessageMutation.error?.message
  };
}