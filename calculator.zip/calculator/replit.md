# Overview

ScienceCalcHub is a comprehensive full-stack scientific calculator web application that provides specialized calculators for physics, chemistry, mathematics, and biology. Built with React, TypeScript, and Express, the application offers interactive calculators with step-by-step solutions, formula explanations, and organized categorization. The platform is designed to be educational, providing not just calculations but detailed explanations of the underlying mathematical and scientific principles.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development patterns
- **Build System**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing without unnecessary complexity
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Framework**: Shadcn/UI components built on Radix UI primitives with Tailwind CSS for consistent styling
- **Form Management**: React Hook Form with Zod validation for type-safe form handling
- **Mobile-First Design**: Responsive layout with mobile detection hooks and optimized touch interactions

## Backend Architecture
- **Server**: Express.js with TypeScript for type-safe server-side development
- **API Design**: RESTful endpoints for calculator operations, search functionality, and usage tracking
- **Request Logging**: Custom middleware for API request logging and performance monitoring
- **Error Handling**: Centralized error handling with proper HTTP status codes and meaningful error messages
- **Development**: Hot reloading with Vite integration for seamless full-stack development experience

## Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations and migrations
- **Schema Management**: Shared TypeScript schemas between client and server using Zod for validation
- **Migration System**: Drizzle Kit for database schema migrations and version control
- **Connection**: Neon Database serverless PostgreSQL for scalability and managed hosting
- **Fallback Storage**: In-memory storage implementation for development, testing, and offline scenarios

## Database Schema Design
- **Calculators Table**: Stores calculator metadata including formulas, variables, categories, usage statistics, and configuration
- **Calculator Results Table**: Persists calculation history with inputs, results, and step-by-step solution breakdowns
- **Users Table**: Basic user management system with username/password authentication
- **Flexible JSON Storage**: Uses JSONB columns for dynamic calculator configurations, input field definitions, and calculation data
- **Category Organization**: Hierarchical structure with categories (physics, chemistry, math, biology) and subcategories for intuitive navigation

## Authentication and Authorization
- **Session Management**: Connect-pg-simple for PostgreSQL-backed session storage with secure session handling
- **User System**: Basic username/password authentication with secure password handling and validation
- **Session Security**: HTTP-only cookies with proper session configuration and CSRF protection

## Calculation Engine
- **Math.js Integration**: Advanced mathematical expression evaluation and computation with support for complex calculations
- **Multi-Domain Support**: Specialized calculation modules for physics, chemistry, mathematics, and biology with domain-specific formulas
- **Step-by-Step Solutions**: Detailed solution breakdowns with formula explanations and educational content
- **Input Validation**: Type-safe input validation using Zod schemas with proper error handling and user feedback
- **Formula Library**: Extensive collection of scientific formulas organized by category and difficulty level

## UI/UX Design System
- **Component Library**: Shadcn/UI providing consistent, accessible components built on Radix UI primitives
- **Design Tokens**: CSS custom properties for colors, spacing, typography, and shadows
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts and touch-optimized interactions
- **Search Functionality**: Real-time search with suggestions and intelligent filtering across calculator categories
- **Category Navigation**: Collapsible category sections with visual indicators and smooth animations

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL database for production data storage with automatic scaling
- **Drizzle ORM**: Type-safe database toolkit for schema management, migrations, and query building

## UI and Styling
- **Tailwind CSS**: Utility-first CSS framework for rapid styling and consistent design
- **Radix UI**: Low-level UI primitives for building accessible and customizable components
- **Lucide React**: Icon library providing consistent iconography throughout the application
- **Class Variance Authority**: Utility for creating component variants with conditional styling

## Development and Build Tools
- **Vite**: Fast build tool and development server with hot module replacement
- **TypeScript**: Static type checking for improved code quality and developer experience
- **PostCSS**: CSS processing with autoprefixer for cross-browser compatibility

## Mathematical Computing
- **Math.js**: Comprehensive math library for expression parsing, evaluation, and mathematical functions
- **Date-fns**: Date manipulation and formatting utilities for timestamp handling

## Form Management
- **React Hook Form**: Performant forms library with minimal re-renders and validation
- **Hookform/Resolvers**: Integration between React Hook Form and validation libraries

## State Management
- **TanStack Query**: Server state management with caching, synchronization, and background updates
- **Embla Carousel**: Touch-friendly carousel component for showcasing calculator categories