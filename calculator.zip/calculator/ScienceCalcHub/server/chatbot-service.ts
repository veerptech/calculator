interface CalculatorMapping {
  [subject: string]: {
    [keyword: string]: string;
  };
}

interface ChatbotResponse {
  message: string;
  calculatorLink?: string;
  alternatives?: string[];
  needsClarification?: boolean;
}

export class ChatbotService {
  // Exact system prompt from user's specification
  private static readonly SYSTEM_PROMPT = `You are a smart assistant that helps users find the right scientific calculator.  
Your job is to:  
1. Understand the user's question.  
2. Identify the subject area: Physics, Chemistry, Biology, or Math.  
3. Match the question to the correct calculator using the dictionary provided.  
4. Reply with a short, friendly response and provide the calculator link.  
5. If multiple calculators are relevant, suggest the most common one and list alternatives.  
6. If unclear, ask the user: "Do you mean a Physics, Chemistry, Biology, or Math calculation?"
7. Always keep responses concise and helpful.`;

  // Dictionary mapping with VERIFIED calculator IDs from actual database
  private static calculatorMapping: CalculatorMapping = {
    "physics": {
      "projectile motion": "/calculator/projectile-motion",
      "kinematics": "/calculator/kinematic-equations", 
      "force": "/calculator/newtons-laws",
      "momentum": "/calculator/momentum-calculator",
      "energy": "/calculator/work-energy",
      "torque": "/calculator/torque-calculator",
      "circular motion": "/calculator/circular-motion",
      "pendulum": "/calculator/pendulum-calculator",
      "hookes law": "/calculator/hookes-law",
      "harmonic motion": "/calculator/simple-harmonic-motion",
      "gravity": "/calculator/gravitational-force",
      "escape velocity": "/calculator/escape-velocity",
      "orbital": "/calculator/orbital-period",
      "keplers": "/calculator/keplers-laws",
      "relativity": "/calculator/relativity-calculator",
      "wave speed": "/calculator/wave-speed",
      "doppler": "/calculator/doppler-effect",
      "sound": "/calculator/sound-intensity",
      "resonance": "/calculator/resonance-calculator",
      "lens formula": "/calculator/lens-formula"
    },
    "chemistry": {
      "molarity": "/calculator/molarity-calculator",
      "ph": "/calculator/ph-calculator",
      "molecular weight": "/calculator/molecular-weight-calculator",
      "gas laws": "/calculator/ideal-gas-law",
      "boyles law": "/calculator/boyles-law-calculator",
      "equilibrium": "/calculator/equilibrium-constant"
    },
    "biology": {
      "bmi": "/calculator/bmi-calculator",
      "bmr": "/calculator/bmr-calculator", 
      "body fat": "/calculator/body-fat-calculator",
      "calorie": "/calculator/calorie-calculator",
      "heart rate": "/calculator/heart-rate-calculator",
      "drug dosage": "/calculator/drug-dosage-calculator"
    },
    "math": {
      "quadratic equation": "/calculator/quadratic-equation-solver",
      "arithmetic": "/calculator/basic-arithmetic",
      "percentage": "/calculator/percentage-calculator",
      "trigonometry": "/calculator/trigonometry-calculator",
      "statistics": "/calculator/statistical-calculator",
      "factorial": "/calculator/factorial-calculator"
    }
  };

  private static subjectKeywords: { [key: string]: string[] } = {
    "physics": ["physics", "force", "motion", "energy", "wave", "optics", "electricity", "mechanics", "nuclear"],
    "chemistry": ["chemistry", "molecular", "reaction", "compound", "solution", "acid", "base", "chemical"],
    "biology": ["biology", "health", "medical", "body", "dna", "genetic", "clinical", "biological"],
    "math": ["math", "mathematics", "equation", "calculate", "formula", "algebra", "calculus", "statistics"]
  };

  public static processMessage(userMessage: string): ChatbotResponse {
    const message = userMessage.toLowerCase().trim();
    
    // Apply the exact prompt logic from user specification
    // First, try to find exact calculator matches
    const exactMatch = this.findExactCalculatorMatch(message);
    if (exactMatch) {
      // Use exact response format from examples
      return {
        message: `Sure! That's a ${exactMatch.subject.charAt(0).toUpperCase() + exactMatch.subject.slice(1)} calculation. Use our ${exactMatch.calculatorName} ✅`,
        calculatorLink: exactMatch.link
      };
    }

    // Try to find partial matches and suggest alternatives
    const partialMatches = this.findPartialMatches(message);
    if (partialMatches.length > 0) {
      const primary = partialMatches[0];
      const alternatives = partialMatches.slice(1, 3).map(match => match.calculatorName);
      
      return {
        message: `Got it ✅ That's a ${primary.subject.charAt(0).toUpperCase() + primary.subject.slice(1)} problem. Try our ${primary.calculatorName}.${alternatives.length > 0 ? ` You might also like: ${alternatives.join(', ')}` : ''}`,
        calculatorLink: primary.link,
        alternatives: alternatives
      };
    }

    // Try to identify subject area for clarification (following prompt step 6)
    const detectedSubject = this.detectSubjectArea(message);
    if (detectedSubject) {
      const subjectCalculators = Object.keys(this.calculatorMapping[detectedSubject]).slice(0, 3);
      return {
        message: `That's a ${detectedSubject.charAt(0).toUpperCase() + detectedSubject.slice(1)} question. Use our ${this.formatCalculatorName(subjectCalculators[0])}.`,
        needsClarification: true
      };
    }

    // No clear match - ask for clarification (following prompt step 6)
    return {
      message: `Do you mean a Physics, Chemistry, Biology, or Math calculation?`,
      needsClarification: true
    };
  }

  private static findExactCalculatorMatch(message: string): { subject: string; calculatorName: string; link: string } | null {
    for (const [subject, calculators] of Object.entries(this.calculatorMapping)) {
      for (const [keyword, link] of Object.entries(calculators)) {
        if (message.includes(keyword.toLowerCase()) || 
            this.fuzzyMatch(message, keyword.toLowerCase())) {
          return {
            subject,
            calculatorName: this.formatCalculatorName(keyword),
            link
          };
        }
      }
    }
    return null;
  }

  private static findPartialMatches(message: string): { subject: string; calculatorName: string; link: string }[] {
    const matches: { subject: string; calculatorName: string; link: string; score: number }[] = [];
    
    for (const [subject, calculators] of Object.entries(this.calculatorMapping)) {
      for (const [keyword, link] of Object.entries(calculators)) {
        const score = this.calculateRelevanceScore(message, keyword.toLowerCase());
        if (score > 0.3) {
          matches.push({
            subject,
            calculatorName: this.formatCalculatorName(keyword),
            link,
            score
          });
        }
      }
    }
    
    return matches
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  }

  private static detectSubjectArea(message: string): string | null {
    let maxScore = 0;
    let detectedSubject: string | null = null;

    for (const [subject, keywords] of Object.entries(this.subjectKeywords)) {
      let score = 0;
      for (const keyword of keywords) {
        if (message.includes(keyword)) {
          score += 1;
        }
      }
      if (score > maxScore) {
        maxScore = score;
        detectedSubject = subject;
      }
    }

    return maxScore > 0 ? detectedSubject : null;
  }

  private static fuzzyMatch(text: string, pattern: string): boolean {
    const words = pattern.split(' ');
    return words.every(word => text.includes(word));
  }

  private static calculateRelevanceScore(message: string, keyword: string): number {
    const words = keyword.split(' ');
    let matchCount = 0;
    
    for (const word of words) {
      if (message.includes(word)) {
        matchCount++;
      }
    }
    
    return matchCount / words.length;
  }

  private static formatCalculatorName(keyword: string): string {
    return keyword
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ') + ' Calculator';
  }
}