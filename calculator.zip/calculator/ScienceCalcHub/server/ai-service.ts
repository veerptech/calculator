import OpenAI from "openai";

// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export interface CalculationExplanation {
  steps: string[];
  formula: string;
  concept: string;
  tips: string[];
}

export interface ProblemSolution {
  solution: string;
  explanation: string;
  steps: string[];
  relatedConcepts: string[];
}

export class AICalculatorService {
  /**
   * Generate step-by-step explanation for a calculation
   */
  async explainCalculation(
    calculatorType: string,
    formula: string,
    inputs: Record<string, any>,
    result: any
  ): Promise<CalculationExplanation> {
    try {
      const prompt = `
You are a mathematics and science tutor. Explain this calculation step-by-step in simple terms.

Calculator: ${calculatorType}
Formula: ${formula}
Inputs: ${JSON.stringify(inputs)}
Result: ${JSON.stringify(result)}

Provide a detailed explanation in JSON format with:
- steps: Array of step-by-step explanation strings
- formula: The mathematical formula used
- concept: The underlying concept/principle
- tips: Array of helpful tips for understanding

Keep explanations clear and educational for students.
`;

      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are an expert mathematics and science tutor. Always respond with valid JSON.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        response_format: { type: "json_object" },
        max_tokens: 1000,
      });

      return JSON.parse(response.choices[0].message.content || "{}");
    } catch (error) {
      console.error("AI explanation error:", error);
      return {
        steps: ["Unable to generate AI explanation at this time."],
        formula: formula || "",
        concept: "Basic calculation",
        tips: ["Double-check your inputs for accuracy."],
      };
    }
  }

  /**
   * Solve a word problem related to the calculator domain
   */
  async solveProblem(
    problem: string,
    category: string,
    subcategory: string
  ): Promise<ProblemSolution> {
    try {
      const prompt = `
You are a problem-solving assistant for ${category} - ${subcategory}.

Problem: ${problem}

Solve this problem step-by-step and provide:
- solution: The final numerical answer
- explanation: Clear explanation of the approach
- steps: Array of solution steps
- relatedConcepts: Array of related concepts/formulas

Respond in JSON format. Be educational and thorough.
`;

      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are an expert problem solver in mathematics and science. Always respond with valid JSON.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        response_format: { type: "json_object" },
        max_tokens: 1200,
      });

      return JSON.parse(response.choices[0].message.content || "{}");
    } catch (error) {
      console.error("AI problem solving error:", error);
      return {
        solution: "Unable to solve automatically",
        explanation: "Please try breaking down the problem into smaller parts.",
        steps: ["Review the given information", "Identify what needs to be found", "Apply appropriate formulas"],
        relatedConcepts: ["Problem decomposition", "Formula application"],
      };
    }
  }

  /**
   * Suggest related calculators based on current context
   */
  async suggestRelatedCalculators(
    currentCalculator: string,
    category: string,
    inputs?: Record<string, any>
  ): Promise<string[]> {
    try {
      const prompt = `
Current calculator: ${currentCalculator}
Category: ${category}
Recent inputs: ${JSON.stringify(inputs || {})}

Suggest 5 related calculator names that would be useful for someone using this calculator.
Focus on calculators within the same field or complementary calculations.

Respond with JSON format: {"suggestions": ["calculator1", "calculator2", ...]}
`;

      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are a calculator recommendation system. Always respond with valid JSON.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        response_format: { type: "json_object" },
        max_tokens: 300,
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      return result.suggestions || [];
    } catch (error) {
      console.error("AI suggestion error:", error);
      return [];
    }
  }

  /**
   * Generate a helpful study tip related to the calculation
   */
  async generateStudyTip(
    calculatorType: string,
    category: string
  ): Promise<string> {
    try {
      const prompt = `
Generate a concise, helpful study tip for students learning about ${calculatorType} in ${category}.
The tip should be practical and memorable. Keep it under 100 words.
Respond with just the tip text, no JSON formatting needed.
`;

      const response = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          {
            role: "system",
            content: "You are a study coach providing helpful learning tips.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        max_tokens: 150,
      });

      return response.choices[0].message.content || "Practice regularly to improve your understanding!";
    } catch (error) {
      console.error("AI study tip error:", error);
      return "Practice regularly and break complex problems into smaller steps!";
    }
  }
}

export const aiService = new AICalculatorService();