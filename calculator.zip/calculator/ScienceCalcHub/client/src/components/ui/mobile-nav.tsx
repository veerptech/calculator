import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { calculatorCategories, subcategories } from "@/lib/calculators";
import { Calculator, Menu, ChevronDown, ChevronRight } from "lucide-react";
import { Calculator as CalculatorType } from "@shared/schema";

interface MobileNavProps {
  selectedCategory: string;
  selectedSubcategory: string | null;
  onCategorySelect: (categoryId: string) => void;
  onSubcategorySelect: (categoryId: string, subcategoryId: string) => void;
  calculators: CalculatorType[];
}

export function MobileNav({
  selectedCategory,
  selectedSubcategory,
  onCategorySelect,
  onSubcategorySelect,
  calculators,
}: MobileNavProps) {
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [open, setOpen] = useState(false);

  const toggleCategoryExpansion = (categoryId: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryId]: !prev[categoryId],
    }));
  };

  const handleCategorySelect = (categoryId: string) => {
    onCategorySelect(categoryId);
    if (categoryId !== "all") {
      setExpandedCategories(prev => ({
        ...prev,
        [categoryId]: true,
      }));
    }
  };

  const handleSubcategorySelect = (categoryId: string, subcategoryId: string) => {
    onSubcategorySelect(categoryId, subcategoryId);
    setOpen(false); // Close mobile menu after selection
  };

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="sm" className="md:hidden" data-testid="mobile-menu-trigger">
          <Menu className="h-5 w-5" />
          <span className="sr-only">Open navigation menu</span>
        </Button>
      </SheetTrigger>
      
      <SheetContent side="left" className="w-80 p-0">
        <SheetHeader className="p-6 border-b">
          <SheetTitle className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-primary" />
            Science Calculators
          </SheetTitle>
        </SheetHeader>
        
        <div className="flex flex-col h-[calc(100vh-5rem)] overflow-y-auto">
          {/* All Calculators Button */}
          <div className="p-4 border-b">
            <Button
              variant={selectedCategory === "all" ? "default" : "outline"}
              onClick={() => {
                handleCategorySelect("all");
                setOpen(false);
              }}
              className="w-full justify-start"
              data-testid="mobile-filter-all"
            >
              <Calculator className="mr-2 h-4 w-4" />
              All Calculators
            </Button>
          </div>

          {/* Categories */}
          <div className="flex-1 p-4 space-y-2">
            {calculatorCategories.map(category => (
              <div key={category.id} className="border rounded-lg overflow-hidden">
                <Collapsible 
                  open={expandedCategories[category.id]} 
                  onOpenChange={() => toggleCategoryExpansion(category.id)}
                >
                  <CollapsibleTrigger asChild>
                    <Button
                      variant="ghost"
                      className={`w-full justify-between h-auto p-3 ${
                        selectedCategory === category.id && !selectedSubcategory 
                          ? 'bg-primary/10 text-primary' 
                          : ''
                      }`}
                      onClick={() => handleCategorySelect(category.id)}
                      data-testid={`mobile-category-${category.id}`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center bg-${category.color}/10`}>
                          <i className={`fas fa-${category.icon} text-sm text-${category.color}`}></i>
                        </div>
                        <div className="text-left">
                          <div className="font-medium text-sm">{category.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {calculators.filter(c => c.category === category.id).length} tools
                          </div>
                        </div>
                      </div>
                      {expandedCategories[category.id] ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                    </Button>
                  </CollapsibleTrigger>
                  
                  <CollapsibleContent>
                    <div className="px-3 pb-3 space-y-1">
                      {subcategories[category.id as keyof typeof subcategories]?.map(subcategory => {
                        const subcategoryCount = calculators.filter(c => 
                          c.category === category.id && c.subcategory === subcategory.id
                        ).length;
                        
                        return (
                          <Button
                            key={subcategory.id}
                            variant={
                              selectedCategory === category.id && selectedSubcategory === subcategory.id 
                                ? "default" 
                                : "ghost"
                            }
                            size="sm"
                            className="w-full justify-start h-auto p-2"
                            onClick={() => handleSubcategorySelect(category.id, subcategory.id)}
                            data-testid={`mobile-subcategory-${category.id}-${subcategory.id}`}
                          >
                            <div className="flex items-center gap-2 flex-1">
                              <div className={`w-6 h-6 rounded flex items-center justify-center bg-${category.color}/5`}>
                                <i className={`fas fa-${subcategory.icon} text-xs text-${category.color}`}></i>
                              </div>
                              <div className="flex-1 text-left">
                                <div className="text-xs font-medium">{subcategory.name}</div>
                              </div>
                              <div className="text-xs bg-muted px-1.5 py-0.5 rounded">
                                {subcategoryCount}
                              </div>
                            </div>
                          </Button>
                        );
                      })}
                    </div>
                  </CollapsibleContent>
                </Collapsible>
              </div>
            ))}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}