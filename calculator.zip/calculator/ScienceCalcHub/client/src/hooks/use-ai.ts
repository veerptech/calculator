import { useMutation } from "@tanstack/react-query";

interface ExplanationResponse {
  success: boolean;
  explanation?: {
    steps: string[];
    formula: string;
    concept: string;
    tips: string[];
  };
  error?: string;
}

interface ProblemSolutionResponse {
  success: boolean;
  solution?: {
    solution: string;
    explanation: string;
    steps: string[];
    relatedConcepts: string[];
  };
  error?: string;
}

interface SuggestionsResponse {
  success: boolean;
  suggestions?: string[];
  error?: string;
}

interface StudyTipResponse {
  success: boolean;
  tip?: string;
  error?: string;
}

export function useExplainCalculation() {
  return useMutation({
    mutationFn: async (data: {
      calculatorType: string;
      formula: string;
      inputs: Record<string, any>;
      result: any;
    }): Promise<ExplanationResponse> => {
      const response = await fetch("/api/ai/explain-calculation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      return response.json();
    },
  });
}

export function useSolveProblem() {
  return useMutation({
    mutationFn: async (data: {
      problem: string;
      category: string;
      subcategory: string;
    }): Promise<ProblemSolutionResponse> => {
      const response = await fetch("/api/ai/solve-problem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      return response.json();
    },
  });
}

export function useSuggestCalculators() {
  return useMutation({
    mutationFn: async (data: {
      currentCalculator: string;
      category: string;
      inputs?: Record<string, any>;
    }): Promise<SuggestionsResponse> => {
      const response = await fetch("/api/ai/suggest-calculators", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      return response.json();
    },
  });
}

export function useStudyTip() {
  return useMutation({
    mutationFn: async (data: {
      calculatorType: string;
      category: string;
    }): Promise<StudyTipResponse> => {
      const response = await fetch("/api/ai/study-tip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      return response.json();
    },
  });
}