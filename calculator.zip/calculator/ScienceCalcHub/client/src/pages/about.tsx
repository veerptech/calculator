import { SEOHead } from "@/components/seo-head";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Calculator, Users, BookOpen, Zap, Shield, Target } from "lucide-react";

export default function AboutPage() {
  const features = [
    {
      icon: Calculator,
      title: "Scientific Calculators",
      description: "Comprehensive collection of calculators for physics, chemistry, biology, and mathematics"
    },
    {
      icon: BookOpen,
      title: "Step-by-Step Solutions", 
      description: "Detailed explanations and educational content to help you learn"
    },
    {
      icon: Zap,
      title: "AI-Powered Assistance",
      description: "Intelligent chatbot to help you find the right calculator and solve problems"
    },
    {
      icon: Shield,
      title: "Free & Secure",
      description: "Always free to use with privacy and security as our top priorities"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="About Us - Science Calculators Hub"
        description="Learn about Science Calculators Hub - your trusted source for scientific calculators with AI assistance and educational content."
        keywords="about us, scientific calculators, education, mathematics, physics, chemistry, biology"
        canonicalUrl={`${window.location.origin}/about`}
      />

      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <div className="flex h-16 items-center">
            <Button variant="ghost" asChild>
              <a href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </a>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 lg:px-8 max-w-4xl py-8 space-y-8">
        {/* Hero Section */}
        <Card>
          <CardHeader className="text-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <Calculator className="h-8 w-8 text-primary" />
            </div>
            <CardTitle className="text-3xl font-bold">About Science Calculators Hub</CardTitle>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Your comprehensive, AI-powered platform for scientific calculations and educational support
            </p>
          </CardHeader>
        </Card>

        {/* Mission Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-6 w-6 text-primary" />
              Our Mission
            </CardTitle>
          </CardHeader>
          <CardContent className="prose prose-gray max-w-none dark:prose-invert">
            <p className="text-lg">
              Science Calculators Hub was created to democratize access to high-quality scientific calculation tools. 
              We believe that every student, researcher, and professional should have access to accurate, easy-to-use 
              calculators with educational explanations.
            </p>
            <p>
              Our platform combines the power of traditional scientific calculators with modern AI assistance, 
              providing not just answers but understanding. We're committed to making complex scientific calculations 
              accessible to everyone, from high school students to PhD researchers.
            </p>
          </CardContent>
        </Card>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <IconComponent className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle className="text-lg">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* What We Offer */}
        <Card>
          <CardHeader>
            <CardTitle>What We Offer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="text-center">
                <Badge variant="secondary" className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                  Physics
                </Badge>
                <p className="text-sm text-muted-foreground mt-2">
                  Mechanics, thermodynamics, electromagnetism, optics, and modern physics
                </p>
              </div>
              <div className="text-center">
                <Badge variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                  Chemistry
                </Badge>
                <p className="text-sm text-muted-foreground mt-2">
                  Stoichiometry, thermochemistry, equilibrium, and molecular calculations
                </p>
              </div>
              <div className="text-center">
                <Badge variant="secondary" className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                  Biology
                </Badge>
                <p className="text-sm text-muted-foreground mt-2">
                  Health metrics, genetics, molecular biology, and bioinformatics
                </p>
              </div>
              <div className="text-center">
                <Badge variant="secondary" className="bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200">
                  Mathematics
                </Badge>
                <p className="text-sm text-muted-foreground mt-2">
                  Algebra, calculus, statistics, and advanced mathematical functions
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Team & Values */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-6 w-6 text-primary" />
              Our Values
            </CardTitle>
          </CardHeader>
          <CardContent className="prose prose-gray max-w-none dark:prose-invert">
            <div className="grid md:grid-cols-3 gap-6">
              <div>
                <h3 className="font-semibold mb-2">Accuracy</h3>
                <p className="text-sm text-muted-foreground">
                  Every calculator is thoroughly tested and validated to ensure reliable results.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Education</h3>
                <p className="text-sm text-muted-foreground">
                  We provide detailed explanations to help users understand the underlying concepts.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Accessibility</h3>
                <p className="text-sm text-muted-foreground">
                  Our tools are designed to be user-friendly and accessible to everyone.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact CTA */}
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="pt-6 text-center">
            <h3 className="text-xl font-semibold mb-2">Have Questions or Suggestions?</h3>
            <p className="text-muted-foreground mb-4">
              We'd love to hear from you! Contact us with feedback, feature requests, or any questions.
            </p>
            <Button asChild>
              <a href="/contact">Get in Touch</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}