import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Calculator } from "@shared/schema";
import { SEOHead } from "@/components/seo-head";
import { SearchBar } from "@/components/search-bar";
import { CalculatorCard } from "@/components/calculator-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { calculatorCategories, subcategories } from "@/lib/calculators";
import { MainNavigation } from "@/components/main-navigation";
import { Footer } from "@/components/footer";
import { Calculator as CalculatorIcon, Users, BookOpen, Zap, Shield, Smartphone, ChevronDown, ChevronRight } from "lucide-react";

export default function Home() {
  const [, navigate] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  const { data: calculators = [], isLoading } = useQuery<Calculator[]>({
    queryKey: ["/api/calculators"],
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const filteredCalculators = useMemo(() => {
    let filtered = calculators;

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter(calc => calc.category === selectedCategory);
    }

    // Filter by subcategory
    if (selectedSubcategory) {
      filtered = filtered.filter(calc => calc.subcategory === selectedSubcategory);
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(calc => 
        calc.title.toLowerCase().includes(query) ||
        calc.description.toLowerCase().includes(query) ||
        calc.keywords?.some(keyword => keyword.toLowerCase().includes(query))
      );
    }

    return filtered;
  }, [calculators, selectedCategory, selectedSubcategory, searchQuery]);

  const groupedCalculators = useMemo(() => {
    const grouped: Record<string, Calculator[]> = {};
    
    filteredCalculators.forEach(calc => {
      if (!grouped[calc.category]) {
        grouped[calc.category] = [];
      }
      grouped[calc.category].push(calc);
    });

    return grouped;
  }, [filteredCalculators]);

  const handleCalculatorClick = (calculator: Calculator) => {
    // Navigate to calculator page using SPA routing
    navigate(`/calculator/${calculator.id}`);
  };

  const toggleCategoryExpansion = (categoryId: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryId]: !prev[categoryId]
    }));
  };

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setSelectedSubcategory(null);
    if (categoryId !== "all") {
      setExpandedCategories(prev => ({
        ...prev,
        [categoryId]: true
      }));
    }
  };

  const handleSubcategorySelect = (categoryId: string, subcategoryId: string) => {
    setSelectedCategory(categoryId);
    setSelectedSubcategory(subcategoryId);
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    "name": "Science Calculators Hub",
    "applicationCategory": "EducationalApplication",
    "description": "Free online calculators for physics, chemistry, mathematics, and biology with step-by-step solutions",
    "url": window.location.origin,
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.8",
      "reviewCount": "15000"
    }
  };

  const stats = {
    physicsCalculators: calculators.filter(c => c.category === "physics").length,
    chemistryCalculators: calculators.filter(c => c.category === "chemistry").length,
    mathCalculators: calculators.filter(c => c.category === "math").length,
    biologyCalculators: calculators.filter(c => c.category === "biology").length,
  };

  return (
    <div className="min-h-screen bg-background">
      <MainNavigation />
      <SEOHead
        title="Science Calculators Hub - Physics, Chemistry, Math & Biology Calculators | Free Online Tools"
        description="Free online calculators for physics, chemistry, mathematics, and biology. Calculate molarity, solve physics problems, perform statistical analysis, and more. Step-by-step solutions included."
        keywords="physics calculator, chemistry calculator, math calculator, biology calculator, molarity calculator, pH calculator, kinematic equations, stoichiometry, calculus calculator, statistics calculator, genetics calculator"
        canonicalUrl={window.location.origin}
        structuredData={structuredData}
      />


      {/* Hero Section */}
      <section className="py-12 lg:py-20 bg-gradient-to-br from-primary/5 via-background to-secondary/5">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl lg:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Free Scientific Calculators
            </h1>
            <p className="text-xl lg:text-2xl text-muted-foreground mb-8 leading-relaxed">
              Comprehensive collection of physics, chemistry, mathematics, and biology calculators with step-by-step solutions. Perfect for students, teachers, and professionals.
            </p>
            
            {/* Search Bar */}
            <SearchBar
              onSearch={setSearchQuery}
              onSelectCalculator={handleCalculatorClick}
              className="mb-8"
            />

            {/* Quick Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary" data-testid="physics-count">
                  {stats.physicsCalculators}+
                </div>
                <div className="text-sm text-muted-foreground">Physics Calculators</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-secondary" data-testid="chemistry-count">
                  {stats.chemistryCalculators}+
                </div>
                <div className="text-sm text-muted-foreground">Chemistry Tools</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent" data-testid="math-count">
                  {stats.mathCalculators}+
                </div>
                <div className="text-sm text-muted-foreground">Math Calculators</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary" data-testid="biology-count">
                  {stats.biologyCalculators}+
                </div>
                <div className="text-sm text-muted-foreground">Biology Tools</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Category & Subcategory Navigation */}
      <section className="py-8 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="max-w-5xl mx-auto">
            {/* All Calculators Button */}
            <div className="mb-6 text-center">
              <Button
                variant={selectedCategory === "all" ? "default" : "outline"}
                onClick={() => handleCategorySelect("all")}
                className="px-8 py-3 text-lg"
                data-testid="filter-all"
              >
                <CalculatorIcon className="mr-2 h-5 w-5" />
                All Calculators
              </Button>
            </div>

            {/* Expandable Category Sections */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {calculatorCategories.map(category => (
                <Card key={category.id} className="overflow-hidden">
                  <Collapsible 
                    open={expandedCategories[category.id]} 
                    onOpenChange={() => toggleCategoryExpansion(category.id)}
                  >
                    <CollapsibleTrigger asChild>
                      <div 
                        className={`p-4 cursor-pointer transition-colors hover:bg-muted/50 ${
                          selectedCategory === category.id && !selectedSubcategory ? 'bg-primary/10 border-l-4 border-primary' : ''
                        }`}
                        onClick={() => {
                          handleCategorySelect(category.id);
                          // Navigate to category page for better mobile experience
                          if (window.innerWidth < 768) {
                            navigate(`/category/${category.id}`);
                          }
                        }}
                        data-testid={`category-${category.id}`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center bg-${category.color}/10`}>
                              <i className={`fas fa-${category.icon} text-xl text-${category.color}`}></i>
                            </div>
                            <div>
                              <h3 className="text-lg font-semibold text-foreground">{category.name}</h3>
                              <p className="text-sm text-muted-foreground">
                                {subcategories[category.id as keyof typeof subcategories]?.length || 0} subcategories
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <span className="text-xs bg-muted px-2 py-1 rounded-full">
                              {calculators.filter(c => c.category === category.id).length} tools
                            </span>
                            {expandedCategories[category.id] ? (
                              <ChevronDown className="h-5 w-5 text-muted-foreground" />
                            ) : (
                              <ChevronRight className="h-5 w-5 text-muted-foreground" />
                            )}
                          </div>
                        </div>
                      </div>
                    </CollapsibleTrigger>
                    
                    <CollapsibleContent>
                      <div className="px-4 pb-4 space-y-2">
                        {subcategories[category.id as keyof typeof subcategories]?.map(subcategory => {
                          const subcategoryCount = calculators.filter(c => 
                            c.category === category.id && c.subcategory === subcategory.id
                          ).length;
                          
                          return (
                            <Button
                              key={subcategory.id}
                              variant={
                                selectedCategory === category.id && selectedSubcategory === subcategory.id 
                                  ? "default" 
                                  : "ghost"
                              }
                              className="w-full justify-start text-left h-auto p-3"
                              onClick={() => handleSubcategorySelect(category.id, subcategory.id)}
                              data-testid={`subcategory-${category.id}-${subcategory.id}`}
                            >
                              <div className="flex items-center space-x-3 flex-1">
                                <div className={`w-8 h-8 rounded-lg flex items-center justify-center bg-${category.color}/5`}>
                                  <i className={`fas fa-${subcategory.icon} text-sm text-${category.color}`}></i>
                                </div>
                                <div className="flex-1 min-w-0">
                                  <div className="font-medium text-sm">{subcategory.name}</div>
                                  <div className="text-xs text-muted-foreground line-clamp-1">
                                    {subcategory.description}
                                  </div>
                                </div>
                                <div className="text-xs bg-muted px-2 py-1 rounded-full shrink-0">
                                  {subcategoryCount}
                                </div>
                              </div>
                            </Button>
                          );
                        })}
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Calculators Grid */}
      <section id="calculators" className="py-16">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <h2 className="text-3xl font-bold text-center mb-12">
            {selectedCategory === "all" 
              ? "Popular Calculators" 
              : selectedSubcategory 
                ? `${subcategories[selectedCategory as keyof typeof subcategories]?.find(s => s.id === selectedSubcategory)?.name} Calculators`
                : `${calculatorCategories.find(c => c.id === selectedCategory)?.name} Calculators`
            }
          </h2>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-48 bg-muted rounded-lg animate-pulse"></div>
              ))}
            </div>
          ) : selectedCategory === "all" ? (
            // Show all categories with grouping
            Object.entries(groupedCalculators).map(([category, categoryCalculators]) => (
              <div key={category} id={category} className="mb-16">
                <h3 className="text-2xl font-semibold mb-8 flex items-center">
                  <i className={`fas fa-${calculatorCategories.find(c => c.id === category)?.icon} text-${getCategoryColor(category)} mr-3`}></i>
                  {calculatorCategories.find(c => c.id === category)?.name} Calculators
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {categoryCalculators.slice(0, 8).map(calculator => (
                    <CalculatorCard
                      key={calculator.id}
                      calculator={calculator}
                      onClick={handleCalculatorClick}
                    />
                  ))}
                </div>
                {categoryCalculators.length > 8 && (
                  <div className="text-center mt-6">
                    <Button variant="outline" asChild>
                      <a href={`/category/${category}`}>
                        View All {calculatorCategories.find(c => c.id === category)?.name} Calculators
                      </a>
                    </Button>
                  </div>
                )}
              </div>
            ))
          ) : (
            // Show single category
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredCalculators.map(calculator => (
                <CalculatorCard
                  key={calculator.id}
                  calculator={calculator}
                  onClick={handleCalculatorClick}
                />
              ))}
            </div>
          )}

          {filteredCalculators.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold mb-2">No calculators found</h3>
              <p className="text-muted-foreground">Try adjusting your search or category filter</p>
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4 lg:px-8 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose Our Calculators?</h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Professional-grade tools designed for accuracy, ease of use, and educational value
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Step-by-Step Solutions</h3>
              <p className="text-muted-foreground">Detailed explanations for every calculation help you understand the process</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-secondary/10 rounded-full flex items-center justify-center">
                <Smartphone className="h-8 w-8 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Mobile-Friendly</h3>
              <p className="text-muted-foreground">Optimized for all devices with touch-friendly interfaces</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-accent/10 rounded-full flex items-center justify-center">
                <Shield className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Input Validation</h3>
              <p className="text-muted-foreground">Smart error checking ensures accurate results every time</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Educational Focus</h3>
              <p className="text-muted-foreground">Learn concepts while solving problems with built-in explanations</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-secondary/10 rounded-full flex items-center justify-center">
                <Zap className="h-8 w-8 text-secondary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Lightning Fast</h3>
              <p className="text-muted-foreground">Instant calculations with no waiting time or complex setup</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-accent/10 rounded-full flex items-center justify-center">
                <Users className="h-8 w-8 text-accent" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Trusted by Millions</h3>
              <p className="text-muted-foreground">Used by students and professionals worldwide</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-muted-foreground">Get answers to common questions about our calculators</p>
          </div>
          
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Are the calculators free to use?</h3>
                <p className="text-muted-foreground">Yes, all our calculators are completely free to use. No registration or payment required.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">How accurate are the calculations?</h3>
                <p className="text-muted-foreground">Our calculators use precise mathematical algorithms and are regularly tested for accuracy. Results are reliable for educational and professional use.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Can I use these calculators on my mobile device?</h3>
                <p className="text-muted-foreground">Absolutely! All calculators are optimized for mobile devices with touch-friendly interfaces and responsive design.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-2">Do you show the calculation steps?</h3>
                <p className="text-muted-foreground">Yes, most calculators include detailed step-by-step solutions to help you understand the calculation process.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function getCategoryColor(category: string): string {
  const categoryMap = {
    physics: "primary",
    chemistry: "secondary", 
    math: "accent",
    biology: "primary"
  };
  return categoryMap[category as keyof typeof categoryMap] || "primary";
}
