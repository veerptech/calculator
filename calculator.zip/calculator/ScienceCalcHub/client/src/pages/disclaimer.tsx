import { SEOHead } from "@/components/seo-head";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export default function DisclaimerPage() {
  return (
    <div className="min-h-screen bg-background">
      <SEOHead
        title="Disclaimer - Science Calculators Hub"
        description="Disclaimer for Science Calculators Hub - Important information about the use of our calculators and services."
        keywords="disclaimer, limitation of liability, calculator accuracy, educational use"
        canonicalUrl={`${window.location.origin}/disclaimer`}
      />

      {/* Header */}
      <header className="border-b border-border bg-background/95 backdrop-blur">
        <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
          <div className="flex h-16 items-center">
            <Button variant="ghost" asChild>
              <a href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Home
              </a>
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 lg:px-8 max-w-4xl py-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl font-bold">Disclaimer</CardTitle>
            <p className="text-muted-foreground">Last updated: {new Date().toLocaleDateString()}</p>
          </CardHeader>
          <CardContent className="prose prose-gray max-w-none dark:prose-invert">
            <div className="space-y-6">
              <section>
                <h2 className="text-2xl font-semibold mb-4">General Disclaimer</h2>
                <p className="mb-4">
                  The information and calculators provided on Science Calculators Hub are for educational and 
                  informational purposes only. While we strive to provide accurate and up-to-date information, 
                  we make no representations or warranties of any kind, express or implied, about the completeness, 
                  accuracy, reliability, suitability, or availability of the calculators or the information contained 
                  on the website.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Accuracy of Calculations</h2>
                <p className="mb-4">
                  While our calculators are designed to provide accurate results based on established scientific 
                  formulas and principles, we cannot guarantee the accuracy of all calculations. Factors that may 
                  affect accuracy include:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Rounding errors in computational processes</li>
                  <li>Limitations of numerical methods</li>
                  <li>Assumptions made in simplified models</li>
                  <li>User input errors</li>
                  <li>Software bugs or technical issues</li>
                </ul>
                <p className="mt-4">
                  <strong>Important:</strong> Always verify critical calculations independently and consult with 
                  qualified professionals when necessary.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Educational Use Only</h2>
                <p className="mb-4">
                  Our calculators are intended for educational, research, and general informational purposes. 
                  They should not be used as the sole basis for:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Professional engineering calculations</li>
                  <li>Medical diagnoses or treatment decisions</li>
                  <li>Financial investment decisions</li>
                  <li>Safety-critical applications</li>
                  <li>Legal or regulatory compliance</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Limitation of Liability</h2>
                <p className="mb-4">
                  In no event will Science Calculators Hub, its operators, or contributors be liable for any 
                  damages including, without limitation, direct, indirect, incidental, special, consequential, 
                  or punitive damages arising out of or in connection with:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Use or inability to use our calculators</li>
                  <li>Errors or inaccuracies in calculations</li>
                  <li>Loss of data or business interruption</li>
                  <li>Decisions made based on calculator results</li>
                  <li>Third-party content or services</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Third-Party Content</h2>
                <p className="mb-4">
                  Our website may contain links to third-party websites or services. We do not endorse or 
                  assume responsibility for the content, privacy policies, or practices of third-party sites. 
                  Users access third-party content at their own risk.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Professional Advice</h2>
                <p className="mb-4">
                  The information provided by our calculators should not be considered as professional advice. 
                  For specific questions related to your field of study or work, please consult with qualified 
                  professionals such as:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Licensed engineers for engineering calculations</li>
                  <li>Medical professionals for health-related calculations</li>
                  <li>Financial advisors for financial calculations</li>
                  <li>Academic experts for research applications</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Software and Technical Issues</h2>
                <p className="mb-4">
                  While we make every effort to ensure our website and calculators function properly, 
                  technical issues may occur. We are not responsible for:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Temporary unavailability of services</li>
                  <li>Browser compatibility issues</li>
                  <li>Network connectivity problems</li>
                  <li>Device-specific display issues</li>
                  <li>Data loss during use</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">User Responsibility</h2>
                <p className="mb-4">
                  By using our calculators, you acknowledge that:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>You understand the limitations of our tools</li>
                  <li>You will verify important calculations independently</li>
                  <li>You will not rely solely on our calculators for critical decisions</li>
                  <li>You will use the tools responsibly and ethically</li>
                  <li>You accept full responsibility for any decisions based on our calculations</li>
                </ul>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Updates and Changes</h2>
                <p className="mb-4">
                  We reserve the right to modify, update, or discontinue any calculator or service without 
                  notice. This disclaimer may also be updated from time to time, and your continued use 
                  constitutes acceptance of any changes.
                </p>
              </section>

              <section>
                <h2 className="text-2xl font-semibold mb-4">Contact Information</h2>
                <p className="mb-4">
                  If you have questions about this disclaimer or need clarification about the appropriate 
                  use of our calculators, please contact us through our 
                  <a href="/contact" className="text-primary hover:underline"> Contact Us</a> page.
                </p>
              </section>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}