# Overview

This is a full-stack scientific calculator web application built with React, TypeScript, and Express. The application provides a comprehensive suite of calculators for physics, chemistry, mathematics, and biology, featuring step-by-step solutions and a modern, responsive user interface.

The application follows a monorepo structure with separate client and server directories, shared schemas, and a PostgreSQL database for persistence. It's designed to be educational, providing not just calculation results but detailed solution steps to help users understand the underlying concepts.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Shadcn/UI components built on Radix UI primitives with Tailwind CSS styling
- **Form Management**: React Hook Form with Zod validation for type-safe form handling
- **Mobile-First Design**: Responsive layout with mobile detection hooks

## Backend Architecture
- **Server**: Express.js with TypeScript
- **API Design**: RESTful endpoints for calculator operations and data retrieval
- **Request Logging**: Custom middleware for API request logging and performance monitoring
- **Error Handling**: Centralized error handling with proper HTTP status codes
- **Development**: Hot reloading with Vite integration for seamless development experience

## Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Management**: Shared TypeScript schemas between client and server using Zod
- **Migration System**: Drizzle Kit for database migrations and schema updates
- **Connection**: Neon Database serverless PostgreSQL for scalability
- **In-Memory Fallback**: Memory storage implementation for development and testing

## Database Schema Design
- **Calculators Table**: Stores calculator metadata including formulas, variables, categories, and usage statistics
- **Calculator Results Table**: Persists calculation history with inputs, results, and step-by-step solutions
- **Users Table**: Basic user management with username/password authentication
- **Flexible JSON Storage**: Uses JSONB columns for dynamic calculator configurations and calculation data

## Authentication and Authorization
- **Session Management**: Connect-pg-simple for PostgreSQL-backed session storage
- **User System**: Basic username/password authentication with secure password handling
- **Session Security**: HTTP-only cookies with proper session configuration

## Calculation Engine
- **Math.js Integration**: Advanced mathematical expression evaluation and computation
- **Multi-Domain Support**: Specialized calculation modules for physics, chemistry, mathematics, and biology
- **Step-by-Step Solutions**: Detailed solution breakdowns with formula explanations
- **Input Validation**: Type-safe input validation using Zod schemas
- **Error Handling**: Graceful error handling for invalid calculations

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, and React development tools
- **Build Tools**: Vite for fast development and optimized production builds
- **TypeScript**: Full TypeScript support with strict type checking

### Database and ORM
- **Drizzle ORM**: Type-safe PostgreSQL ORM with schema management
- **Neon Database**: Serverless PostgreSQL provider for cloud deployment
- **Connection Pooling**: Optimized database connections for performance

### UI and Styling
- **Tailwind CSS**: Utility-first CSS framework with custom design system
- **Radix UI**: Accessible UI primitives for complex components
- **Shadcn/UI**: Pre-built component library with consistent design patterns
- **Lucide React**: Modern icon library for consistent iconography

### State Management and Data Fetching
- **TanStack Query**: Powerful data synchronization and caching
- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: Runtime type validation and schema parsing

### Mathematical Computations
- **Math.js**: Comprehensive mathematics library for complex calculations
- **Date-fns**: Date manipulation and formatting utilities

### Development and Deployment
- **ESBuild**: Fast JavaScript bundler for production builds
- **PostCSS**: CSS processing with Autoprefixer for browser compatibility
- **Replit Integration**: Development environment optimizations for Replit platform

### Session and Security
- **Express Session**: Session management middleware
- **Connect-pg-simple**: PostgreSQL session store for scalable session management
- **Crypto**: Built-in Node.js cryptographic functionality for secure operations